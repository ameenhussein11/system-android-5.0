// Rewrites modern CSS (Tailwind 4 output) so it also works on old browsers such as Chrome 95
// (Android 5 tablets, old iPads): flattens @layer, converts oklch()/color-mix() to plain colours,
// range media queries to min/max-width, and individual transform properties to `transform`.
// Used only by the "web for old devices" build (see vite.config.ts: LEGACY_BROWSERS=1).

// ---------- @layer ----------
function skipString(css, i) {
  const q = css[i];
  i++;
  while (i < css.length && css[i] !== q) i += css[i] === '\\' ? 2 : 1;
  return i;
}
function matchBrace(css, open) {
  let depth = 0;
  for (let i = open; i < css.length; i++) {
    const c = css[i];
    if (c === '"' || c === "'") i = skipString(css, i);
    else if (c === '/' && css[i + 1] === '*') i = css.indexOf('*/', i + 2) + 1;
    else if (c === '{') depth++;
    else if (c === '}') {
      depth--;
      if (depth === 0) return i;
    }
  }
  return -1;
}
export function unwrapLayers(css) {
  let guard = 0;
  for (;;) {
    const at = css.search(/@layer[\s{]|@layer\b[^{;]*[;{]/);
    if (at === -1 || guard++ > 5000) return css;
    let i = at + 6;
    while (i < css.length && css[i] !== '{' && css[i] !== ';') i++;
    if (css[i] === ';') {
      css = css.slice(0, at) + css.slice(i + 1); // "@layer a, b, c;"
    } else {
      const end = matchBrace(css, i);
      if (end === -1) return css;
      css = css.slice(0, at) + css.slice(i + 1, end) + css.slice(end + 1); // "@layer x { ... }"
    }
  }
}

// ---------- colours ----------
const clamp01 = (x) => Math.min(1, Math.max(0, x));
const gamma = (x) => (x <= 0.0031308 ? 12.92 * x : 1.055 * Math.pow(x, 1 / 2.4) - 0.055);
export function oklchToRgb(L, C, H) {
  const a = C * Math.cos((H * Math.PI) / 180);
  const b = C * Math.sin((H * Math.PI) / 180);
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
  const s_ = L - 0.0894841775 * a - 1.291485548 * b;
  const l = l_ ** 3, m = m_ ** 3, s = s_ ** 3;
  const r = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s;
  const g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s;
  const bl = -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s;
  return [r, g, bl].map((v) => Math.round(clamp01(gamma(v)) * 255));
}
export function oklabToRgb(L, a, b) {
  const l_ = L + 0.3963377774 * a + 0.2158037573 * b;
  const m_ = L - 0.1055613458 * a - 0.0638541728 * b;
  const s_ = L - 0.0894841775 * a - 1.291485548 * b;
  const l = l_ ** 3, m = m_ ** 3, s = s_ ** 3;
  return [
    4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s,
    -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s,
    -0.0041960863 * l - 0.7034186147 * m + 1.707614701 * s,
  ].map((v) => Math.round(clamp01(gamma(v)) * 255));
}
const hex = (n) => n.toString(16).padStart(2, '0');
const num = (v) => (v.endsWith('%') ? parseFloat(v) / 100 : parseFloat(v));
function convertOklch(_, inner) {
  const [main, alphaStr] = inner.split('/').map((x) => x.trim());
  const p = main.split(/\s+/);
  if (p.length < 3 || p.some((x) => x === 'none' || x.startsWith('var(') || x === 'from')) return _;
  const [r, g, b] = oklchToRgb(num(p[0]), parseFloat(p[1]) * (p[1].endsWith('%') ? 0.004 : 1), parseFloat(p[2]));
  if (alphaStr === undefined) return `#${hex(r)}${hex(g)}${hex(b)}`;
  const a = Math.round(num(alphaStr) * 1000) / 1000;
  return `rgba(${r},${g},${b},${a})`;
}
function convertOklab(_, inner) {
  const [main, alphaStr] = inner.split('/').map((x) => x.trim());
  const p = main.split(/\s+/);
  if (p.length < 3 || p.some((x) => x === 'none' || x.startsWith('var(') || x === 'from')) return _;
  const [r, g, b] = oklabToRgb(num(p[0]), parseFloat(p[1]), parseFloat(p[2]));
  if (alphaStr === undefined) return `#${hex(r)}${hex(g)}${hex(b)}`;
  return `rgba(${r},${g},${b},${Math.round(num(alphaStr) * 1000) / 1000})`;
}
function parseStatic(c) {
  let m = /^#([0-9a-f]{6})$/i.exec(c);
  if (m) return [parseInt(m[1].slice(0, 2), 16), parseInt(m[1].slice(2, 4), 16), parseInt(m[1].slice(4, 6), 16), 1];
  m = /^#([0-9a-f]{3})$/i.exec(c);
  if (m) return [...m[1]].map((x) => parseInt(x + x, 16)).concat(1);
  m = /^#([0-9a-f]{8})$/i.exec(c);
  if (m) return [0, 2, 4].map((i) => parseInt(m[1].slice(i, i + 2), 16)).concat(parseInt(m[1].slice(6, 8), 16) / 255);
  m = /^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+%?))?\s*\)$/i.exec(c);
  if (m) return [+m[1], +m[2], +m[3], m[4] === undefined ? 1 : num(m[4])];
  return null;
}
function convertColorMix(whole, color, pct) {
  const rgba = parseStatic(color.trim());
  if (!rgba) return whole;
  const a = Math.round(rgba[3] * (parseFloat(pct) / 100) * 1000) / 1000;
  return `rgba(${Math.round(rgba[0])},${Math.round(rgba[1])},${Math.round(rgba[2])},${a})`;
}

// ---------- media queries & transforms ----------
const TRANSFORM =
  'transform:translate(var(--tw-translate-x),var(--tw-translate-y)) scale(var(--tw-scale-x),var(--tw-scale-y)) rotate(var(--tw-rot,0deg))';
const dec = (n) => String(Math.round(n * 10000) / 10000);

export function legacyCss(input) {
  let css = unwrapLayers(input);

  css = css.replace(/oklch\(\s*([^()]+?)\s*\)/g, convertOklch);
  css = css.replace(/oklab\(\s*([^()]+?)\s*\)/g, convertOklab);
  // static colour first, e.g. color-mix(in srgb, #fde68a 50%, transparent)
  css = css.replace(/color-mix\(\s*in\s+(?:srgb|oklab|lab|oklch|srgb-linear|hsl)\s*,\s*(#[0-9a-fA-F]{3,8}|rgba?\([^()]*\))\s+([\d.]+)%\s*,\s*transparent\s*\)/g, (w, c, p) => convertColorMix(w, c, p));

  // (width >= 40rem) -> (min-width:40rem) ; (width < 40rem) -> (max-width:39.99rem)
  css = css.replace(/\(\s*width\s*>=\s*([\d.]+)(rem|em|px)\s*\)/g, '(min-width:$1$2)');
  css = css.replace(/\(\s*width\s*<=\s*([\d.]+)(rem|em|px)\s*\)/g, '(max-width:$1$2)');
  css = css.replace(/\(\s*width\s*>\s*([\d.]+)(rem|em|px)\s*\)/g, (_, n, u) => `(min-width:${dec(+n + (u === 'px' ? 0.02 : 0.001))}${u})`);
  css = css.replace(/\(\s*width\s*<\s*([\d.]+)(rem|em|px)\s*\)/g, (_, n, u) => `(max-width:${dec(+n - (u === 'px' ? 0.02 : 0.001))}${u})`);

  // scale percentages -> numbers (scale(95%) is not understood by old browsers)
  css = css.replace(/(--tw-scale-[xyz])\s*:\s*([\d.]+)%/g, (_, p, v) => `${p}:${dec(parseFloat(v) / 100)}`);
  // individual transform properties -> one combined transform driven by the same variables
  const P = '(^|[{;\\s])';
  css = css.replace(new RegExp(P + 'translate\\s*:\\s*var\\(--tw-translate-x\\)\\s*var\\(--tw-translate-y\\)(?:\\s*var\\(--tw-translate-z\\))?\\s*(?=[;}])', 'g'), `$1${TRANSFORM}`);
  css = css.replace(new RegExp(P + 'scale\\s*:\\s*var\\(--tw-scale-x\\)\\s*var\\(--tw-scale-y\\)(?:\\s*var\\(--tw-scale-z\\))?\\s*(?=[;}])', 'g'), `$1${TRANSFORM}`);
  css = css.replace(new RegExp(P + 'scale\\s*:\\s*([\\d.]+)(%?)\\s*(?=[;}])', 'g'), (_, pre, n, pc) => {
    const v = dec(pc ? parseFloat(n) / 100 : parseFloat(n));
    return `${pre}--tw-scale-x:${v};--tw-scale-y:${v};${TRANSFORM}`;
  });
  css = css.replace(new RegExp(P + 'rotate\\s*:\\s*(-?[\\d.]+(?:deg|turn|rad))\\s*(?=[;}])', 'g'), (_, pre, v) => `${pre}--tw-rot:${v};${TRANSFORM}`);
  return css;
}

/** Constructs an old browser still cannot parse (reported as build warnings). */
export function findLeftovers(css) {
  const test = (re) => (css.match(re) || []).length;
  const noGuard = css.replace(/@supports\s*\(\s*color\s*:\s*color-mix\([^)]*\)[^)]*\)/g, '');
  return {
    '@layer': test(/@layer/g),
    'oklch()/oklab()/lab()': test(/\b(?:oklch|oklab|lab|lch)\(/g),
    'range media queries': test(/\(\s*width\s*[<>]=?/g),
    'standalone translate/scale/rotate': test(/[;{\s]-?(?:translate|scale|rotate)\s*:/g),
    ':has()': test(/:has\(/g),
    'color-mix() outside @supports guards (static colours only)': (noGuard.match(/color-mix\([^;}]*\)/g) || []).filter((x) => !x.includes('var(') && !/currentcolor/i.test(x)).length,
  };
}
