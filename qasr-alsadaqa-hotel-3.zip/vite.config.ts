import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';
// @ts-ignore - plain JS helper, no type declarations
import {legacyCss, findLeftovers} from './scripts/legacyCss.mjs';

// `npm run build:web` sets LEGACY_BROWSERS=1: makes the web/iPad version work on old browsers
// (Chrome 95 on Android 5 tablets, older iPads). The APK build is not affected.
const legacy = process.env.LEGACY_BROWSERS === '1';

const legacyCssPlugin = () => ({
  name: 'qasr-legacy-css',
  enforce: 'post' as const,
  generateBundle(_options: unknown, bundle: Record<string, any>) {
    for (const file of Object.values(bundle)) {
      if (file.type !== 'asset' || !String(file.fileName).endsWith('.css')) continue;
      const src = typeof file.source === 'string' ? file.source : new TextDecoder().decode(file.source);
      const out = legacyCss(src);
      const left = findLeftovers(out) as Record<string, number>;
      const problems = Object.entries(left).filter(([, n]) => n > 0);
      console.log(`[legacy-css] ${file.fileName}: ${src.length} -> ${out.length} bytes` + (problems.length ? ` | leftovers: ${JSON.stringify(Object.fromEntries(problems))}` : ' | clean'));
      file.source = out;
    }
  },
});

export default defineConfig(() => {
  return {
    base: './',
    plugins: [react(), tailwindcss(), ...(legacy ? [legacyCssPlugin()] : [])],
    build: legacy ? {target: 'chrome90', cssTarget: 'chrome90'} : undefined,
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
