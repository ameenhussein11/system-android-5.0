import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';
// @ts-ignore - plain JS helper, no type declarations
import {legacyCss, findLeftovers} from './scripts/legacyCss.mjs';

// Every build is made compatible with old browsers (Chrome 95 on Android 5 tablets, older iPads/WebViews).
const legacy = process.env.MODERN_BROWSERS !== '1'; // on by default: output also works on old browsers (set MODERN_BROWSERS=1 to opt out)

const legacyCssPlugin = () => ({
  name: 'qasr-legacy-css',
  enforce: 'post' as const,
  generateBundle(_options: unknown, bundle: Record<string, any>) {
    for (const file of Object.values(bundle)) {
      if (file.type !== 'asset' || !String(file.fileName).endsWith('.css')) continue;
      const src = typeof file.source === 'string' ? file.source : new TextDecoder().decode(file.source);
      const out = legacyCss(src);
      const left = findLeftovers(out) as Record<string, number>;
      const problems = Object.entries(left).filter(([, n]) => n > 0);
      console.log(`[legacy-css] ${file.fileName}: ${src.length} -> ${out.length} bytes` + (problems.length ? ` | leftovers: ${JSON.stringify(Object.fromEntries(problems))}` : ' | clean'));
      file.source = out;
    }
  },
});

export default defineConfig(() => {
  return {
    base: './',
    // optimize:false skips Tailwind's own LightningCSS step; Vite's esbuild (cssTarget) then lowers CSS nesting for old browsers
    plugins: [react(), tailwindcss(legacy ? {optimize: false} : undefined), ...(legacy ? [legacyCssPlugin()] : [])],
    build: legacy ? {target: 'chrome90', cssTarget: 'chrome90'} : undefined,
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
