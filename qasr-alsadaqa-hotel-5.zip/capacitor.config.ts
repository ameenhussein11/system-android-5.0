import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.qasralsadaqa.hotel',
  appName: 'قصر الصداقة',
  webDir: 'dist',
  // Everything is bundled inside the APK and data lives on the device,
  // so the app works with no internet connection at all.
  plugins: {
    // native HTTP: lets the app talk to Google's servers without browser CORS limits
    CapacitorHttp: { enabled: true },
  },
  android: {
    allowMixedContent: false,
  },
};

export default config;
