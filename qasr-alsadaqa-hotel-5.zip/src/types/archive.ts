import type { Payment, ExpenseRecord, OtherRevenueRecord, StaffSalaryRecord, ActivityLog, RoomStatus, RoomType } from './hotel';

export type ClosingType = 'daily' | 'weekly' | 'monthly' | 'yearly';

/** Statistics, revenues, expenses and salaries for a date range. */
export interface ClosingFigures {
  days: number;
  roomRevenue: number;
  roomRevenueByMethod: Record<string, number>;
  otherRevenue: number;
  totalRevenue: number;
  expenses: number; // already includes salaries (every salary payment is also logged as an expense)
  expensesByCategory: Record<string, number>;
  salariesPaid: number;
  salariesCount: number;
  net: number;
  checkIns: number;
  checkOuts: number;
  newGuests: number;
  nightsSold: number;
  occupancyPercent: number;
  adr: number; // average room rate per sold night
}

export interface ClosingRecord {
  id: number;
  type: ClosingType;
  key: string;
  label: string;
  from: string;
  to: string;
  closedAt: string;
  closedBy: string;
  figures: ClosingFigures;
}

export interface SnapshotGuestRow {
  id: number;
  name: string;
  phone: string;
  nationalId: string;
  nationality: string;
  visitCount: number;
  isVip: boolean;
  isBlacklisted: boolean;
  roomNumber?: string;
  checkIn?: string;
  hostedNights: number;
  lastStayFrom?: string;
  lastStayTo?: string;
  lastStayRoom?: string;
}

export interface SnapshotBookingRow {
  bookingCode: string;
  roomNumber: string;
  guestName: string;
  checkInDate: string;
  expectedCheckOutDate: string;
  actualCheckOutDate?: string;
  totalAmount: number;
  paidAmount: number;
  isActive: boolean;
}

/** One saved day of the whole hotel system (kept without photos so it stays small). */
export interface DaySnapshot {
  date: string;
  savedAt: string;
  hotelName: string;
  stats: { totalRooms: number; occupied: number; available: number; cleaning: number; maintenance: number; occupancyPercent: number };
  figures: ClosingFigures;
  rooms: { roomNumber: string; type: RoomType; status: RoomStatus; guestName?: string | null; checkOutDate?: string | null; pricePerNight: number }[];
  guests: SnapshotGuestRow[];
  activeBookings: SnapshotBookingRow[];
  dayBookings: SnapshotBookingRow[]; // check-ins / check-outs that happened on this day
  payments: Payment[];
  expenses: ExpenseRecord[];
  otherRevenues: OtherRevenueRecord[];
  salaries: StaffSalaryRecord[];
  logs: ActivityLog[];
}
