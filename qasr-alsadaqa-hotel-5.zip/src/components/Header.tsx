import React from 'react';
import { useHotel } from '../context/HotelContext';
import {
  Menu,
  Bell,
  Database,
  Smartphone,
  Plus,
  Settings,
  Hotel,
  AlertTriangle,
  Sparkles,
  Search,
  Repeat,
  User,
  Calendar,
  UtensilsCrossed,
  ArrowLeftRight,
  BarChart2,
  Users,
  Shield,
  HelpCircle,
  Cloud,
  ArrowRight,
} from 'lucide-react';
import { ThemeToggle } from './ThemeToggle';

export const Header: React.FC = () => {
  const {
    rooms,
    guests,
    settings,
    notifications,
    unreadNotificationCount,
    setIsNotificationsOpen,
    setIsCheckInModalOpen,
    setIsSqlConsoleOpen,
    setIsSettingsOpen,
    isAndroidView,
    setIsAndroidView,
    searchQuery,
    setSearchQuery,
    activeTab,
    setActiveTab,
    roomServiceOrders,
    isDrawerOpen,
    setIsDrawerOpen,
    currentUser,
    setIsAccountModalOpen,
    setIsHelpModalOpen,
    setIsGoogleDriveLinkModalOpen,
    selectedGoogleAccount,
    goBack,
    canGoBack,
  } = useHotel();

  const availableCount = rooms.filter((r) => r.status === 'available').length;
  const occupiedCount = rooms.filter((r) => r.status === 'occupied').length;
  const cleaningCount = rooms.filter((r) => r.status === 'cleaning').length;
  const frequentGuestsCount = guests.filter((g) => g.isFrequent).length;
  const activeRoomServiceOrdersCount = roomServiceOrders.filter(
    (o) => o.status === 'pending' || o.status === 'preparing' || o.status === 'on_the_way'
  ).length;

  const urgentAlert = notifications.find((n) => n.severity === 'danger' || n.severity === 'warning');

  return (
    <header className="bg-linear-to-l from-slate-950 via-slate-900 to-slate-800 text-white border-b-2 border-amber-500/70 sticky top-0 z-30 shadow-lg select-none" dir="rtl">
      {/* Top Ticker Alert if any urgent warning */}
      {urgentAlert && (
        <div className="bg-amber-500/15 border-b border-amber-500/30 px-4 py-1.5 text-xs text-amber-200 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 overflow-hidden text-ellipsis whitespace-nowrap">
            <span className="flex h-2 w-2 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-amber-500"></span>
            </span>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0" />
            <strong className="font-semibold">{urgentAlert.title}:</strong>
            <span className="text-slate-300 truncate">{urgentAlert.message}</span>
          </div>
          <button
            onClick={() => setIsNotificationsOpen(true)}
            className="text-amber-400 hover:text-amber-300 underline font-medium shrink-0 text-[11px] cursor-pointer"
          >
            عرض التنبيهات
          </button>
        </div>
      )}

      {/* Main Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-2.5 flex items-center justify-between gap-3">
        {/* Left Side: Drawer Toggle & Brand */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* Back button: closes the open window or returns to the previous screen */}
          {canGoBack && (
            <button
              onClick={() => goBack()}
              title="رجوع"
              aria-label="رجوع"
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-300 border border-slate-700 transition cursor-pointer active:scale-95 flex items-center gap-1.5 text-xs font-semibold"
            >
              <ArrowRight className="w-5 h-5 stroke-[2.2]" />
              <span className="hidden sm:inline">رجوع</span>
            </button>
          )}

          {/* Drawer Menu Hamburger Button */}
          <button
            onClick={() => setIsDrawerOpen(true)}
            title="فتح القائمة الجانبية (Drawer)"
            className="p-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white transition cursor-pointer shadow-sm active:scale-95 flex items-center gap-1.5 font-semibold text-xs"
          >
            <Menu className="w-5 h-5 stroke-[2.2]" />
            <span className="hidden md:inline">القائمة</span>
          </button>

          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-sky-500 to-sky-700 flex items-center justify-center text-white shadow-md">
              <Hotel className="w-5 h-5 sm:w-6 sm:h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="font-bold text-sm sm:text-base md:text-lg tracking-tight text-white">
                  {settings.hotelName}
                </h1>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-sky-500/20 text-sky-300 font-mono border border-sky-500/30 hidden xs:inline">
                  PMS
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block font-mono">
                {settings.hotelNameEn || 'Qasr Al-Sadaqa Hotel'}
              </p>
            </div>
          </div>
        </div>

        {/* User Capsule: ⇄ admin 👤 */}
        <div className="hidden sm:flex items-center">
          <button
            onClick={() => setIsAccountModalOpen(true)}
            title="الملف الشخصي وتبديل المستخدم"
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-medium transition cursor-pointer active:scale-95"
          >
            <Repeat className="w-3.5 h-3.5 text-sky-400" />
            <span className="font-mono font-bold text-white">{currentUser.username}</span>
            <User className="w-3.5 h-3.5 text-sky-400" />
          </button>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Check-In Action Button */}
          <button
            onClick={() => setIsCheckInModalOpen(true)}
            className="flex items-center gap-1.5 bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs sm:text-sm px-3 sm:px-3.5 py-2 rounded-xl transition shadow-sm cursor-pointer whitespace-nowrap active:scale-95"
          >
            <Plus className="w-4 h-4" />
            <span>حجز / تسكين</span>
          </button>

          <ThemeToggle />

          {/* Google Drive & Cloud Backup */}
          <button
            onClick={() => setIsGoogleDriveLinkModalOpen(true)}
            title={`ربط Google Drive والنسخ السحابي (${selectedGoogleAccount ? selectedGoogleAccount.email : 'تحديد الحساب يدويًا'})`}
            className="p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition cursor-pointer relative group flex items-center gap-1.5"
          >
            <Cloud className="w-4 h-4 text-sky-400 group-hover:scale-110 transition-transform" />
            <span className="hidden xl:inline text-xs text-slate-300">سحابة Drive</span>
            {selectedGoogleAccount && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 absolute -top-0.5 -right-0.5 ring-2 ring-slate-900"></span>
            )}
          </button>

          {/* SQLite Terminal Console */}
          <button
            onClick={() => setIsSqlConsoleOpen(true)}
            title="قاعدة بيانات SQLite ومحرر SQL"
            className="p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition cursor-pointer"
          >
            <Database className="w-4 h-4 text-cyan-400" />
          </button>

          {/* Android Simulator Frame Toggle */}
          <button
            onClick={() => setIsAndroidView(!isAndroidView)}
            title={isAndroidView ? 'التبديل إلى وضع الشاشة الكاملة' : 'معاينة شاشة تطبيق أندرويد'}
            className={`p-2 rounded-xl border transition cursor-pointer hidden md:flex items-center gap-1.5 text-xs ${
              isAndroidView
                ? 'bg-sky-600 text-white border-sky-500 font-semibold shadow-sm'
                : 'text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 border-slate-700'
            }`}
          >
            <Smartphone className="w-4 h-4 text-sky-400" />
            <span className="hidden lg:inline">{isAndroidView ? 'شاشة أندرويد' : 'وضع أندرويد'}</span>
          </button>

          {/* Notifications Trigger */}
          <button
            onClick={() => setIsNotificationsOpen(true)}
            title="الإشعارات والتنبيهات"
            className="p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition cursor-pointer relative"
          >
            <Bell className="w-4 h-4" />
            {unreadNotificationCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-rose-500 text-white text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                {unreadNotificationCount}
              </span>
            )}
          </button>

          {/* Help Trigger */}
          <button
            onClick={() => setIsHelpModalOpen(true)}
            title="تعليمات ودليل الاستخدام"
            className="p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl border border-slate-700 transition cursor-pointer hidden sm:block"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Main Navigation Tabs Row */}
      <div className="bg-slate-950 border-t border-slate-800/80 px-3 sm:px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between overflow-x-auto no-scrollbar py-1.5">
          <nav className="flex items-center gap-1 sm:gap-2">
            {/* 1. الرئيسية / شبكة الغرف */}
            <button
              onClick={() => setActiveTab('rooms')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'rooms'
                  ? 'bg-sky-600/20 text-sky-400 border border-sky-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <span>🏨 شبكة الغرف</span>
              <span className="px-1.5 py-0.2 bg-slate-800 text-[10px] rounded-full text-slate-300 font-mono">
                {rooms.length}
              </span>
            </button>

            {/* 2. الحجز */}
            <button
              onClick={() => setActiveTab('reservations')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'reservations'
                  ? 'bg-sky-600/20 text-sky-400 border border-sky-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Calendar className="w-3.5 h-3.5" />
              <span>الحجز</span>
            </button>

            {/* 3. خدمة الغرف */}
            <button
              onClick={() => setActiveTab('room_service')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'room_service'
                  ? 'bg-sky-600/20 text-sky-400 border border-sky-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <UtensilsCrossed className="w-3.5 h-3.5" />
              <span>خدمة الغرف</span>
              {activeRoomServiceOrdersCount > 0 && (
                <span className="px-1.5 py-0.2 bg-amber-500 text-slate-950 font-bold text-[10px] rounded-full font-mono animate-pulse">
                  {activeRoomServiceOrdersCount}
                </span>
              )}
            </button>

            {/* 4. الإحصائيات والتقارير */}
            <button
              onClick={() => setActiveTab('reports')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'reports'
                  ? 'bg-sky-600/20 text-sky-400 border border-sky-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <BarChart2 className="w-3.5 h-3.5" />
              <span>الإحصائيات</span>
            </button>

            {/* 5. الإيرادات والمصروفات الأخرى (رواتب الموظفين) */}
            <button
              onClick={() => setActiveTab('finance')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'finance'
                  ? 'bg-sky-600/20 text-sky-400 border border-sky-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <ArrowLeftRight className="w-3.5 h-3.5" />
              <span>الإيرادات والمصروفات والرواتب</span>
            </button>

            {/* 6. سجل النزلاء */}
            <button
              onClick={() => setActiveTab('guests')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'guests'
                  ? 'bg-sky-600/20 text-sky-400 border border-sky-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>سجل النزلاء ({guests.length})</span>
            </button>

            {/* 7. الهاوس كيبينج */}
            <button
              onClick={() => setActiveTab('housekeeping')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'housekeeping'
                  ? 'bg-sky-600/20 text-sky-400 border border-sky-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <span>🧹 الهاوس كيبينج</span>
              {cleaningCount > 0 && (
                <span className="px-1.5 py-0.2 bg-amber-500/30 text-amber-300 border border-amber-500/40 text-[10px] rounded-full font-mono">
                  {cleaningCount}
                </span>
              )}
            </button>

            {/* 8. إدارة النظام */}
            <button
              onClick={() => setActiveTab('system_admin')}
              className={`px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition cursor-pointer flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'system_admin'
                  ? 'bg-sky-600/20 text-sky-400 border border-sky-500/40 font-bold'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900'
              }`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span>إدارة النظام</span>
            </button>
          </nav>

          {/* Quick Search Field */}
          <div className="relative shrink-0 hidden md:block w-44 lg:w-56">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث عن غرفة أو نزيل..."
              className="w-full bg-slate-900 border border-slate-800 text-xs rounded-lg pl-3 pr-8 py-1.5 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-sky-500"
            />
            <Search className="w-3.5 h-3.5 text-slate-500 absolute right-2.5 top-2.5" />
          </div>
        </div>
      </div>
    </header>
  );
};
