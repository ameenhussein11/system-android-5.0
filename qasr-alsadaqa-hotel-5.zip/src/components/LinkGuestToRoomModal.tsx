import React, { useState, useEffect } from 'react';
import { useHotel } from '../context/HotelContext';
import { PaymentMethod, Guest, Room } from '../types/hotel';
import {
  X,
  User,
  Bed,
  Phone,
  CreditCard,
  Calendar,
  Sparkles,
  CheckCircle,
  Building,
  Shield,
  FileText,
  BadgePercent,
  Search,
  Plus,
  Coins,
  ArrowLeftRight,
} from 'lucide-react';

export const LinkGuestToRoomModal: React.FC = () => {
  const {
    isLinkGuestModalOpen,
    setIsLinkGuestModalOpen,
    preselectedGuestForLink,
    setPreselectedGuestForLink,
    preselectedRoomForLink,
    setPreselectedRoomForLink,
    guests,
    rooms,
    settings,
    linkGuestToRoom,
    addOrUpdateGuest,
  } = useHotel();

  // Selected entities
  const [selectedGuestId, setSelectedGuestId] = useState<number | null>(null);
  const [selectedRoomId, setSelectedRoomId] = useState<number | null>(null);

  // Search filter for guest dropdown
  const [guestSearch, setGuestSearch] = useState<string>('');
  const [showQuickAddGuest, setShowQuickAddGuest] = useState<boolean>(false);
  const [newGuestName, setNewGuestName] = useState<string>('');
  const [newGuestPhone, setNewGuestPhone] = useState<string>('');
  const [newGuestNationalId, setNewGuestNationalId] = useState<string>('');

  // Booking terms
  const [nights, setNights] = useState<number>(1);
  const [customPrice, setCustomPrice] = useState<number>(0);
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [paidAmount, setPaidAmount] = useState<number>(0);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('card');
  const [notes, setNotes] = useState<string>('');

  const availableRooms = rooms.filter((r) => r.status === 'available');

  // Initialization when modal opens
  useEffect(() => {
    if (isLinkGuestModalOpen) {
      if (preselectedGuestForLink) {
        setSelectedGuestId(preselectedGuestForLink.id);
        if (preselectedGuestForLink.isFrequent) {
          setDiscountPercent(preselectedGuestForLink.loyaltyDiscountPercent || settings.defaultLoyaltyDiscount);
        }
      } else if (guests.length > 0) {
        setSelectedGuestId(guests[0].id);
      }

      if (preselectedRoomForLink && preselectedRoomForLink.status === 'available') {
        setSelectedRoomId(preselectedRoomForLink.id);
        setCustomPrice(preselectedRoomForLink.pricePerNight);
      } else if (availableRooms.length > 0) {
        setSelectedRoomId(availableRooms[0].id);
        setCustomPrice(availableRooms[0].pricePerNight);
      }
    }
  }, [isLinkGuestModalOpen, preselectedGuestForLink, preselectedRoomForLink]);

  const activeGuest = guests.find((g) => g.id === selectedGuestId);
  const activeRoom = rooms.find((r) => r.id === selectedRoomId);

  // Update loyalty discount when guest changes
  useEffect(() => {
    if (activeGuest) {
      if (activeGuest.isFrequent) {
        setDiscountPercent(activeGuest.loyaltyDiscountPercent || settings.defaultLoyaltyDiscount);
      } else {
        setDiscountPercent(0);
      }
    }
  }, [selectedGuestId]);

  // Update default price when room changes
  useEffect(() => {
    if (activeRoom) {
      setCustomPrice(activeRoom.pricePerNight);
    }
  }, [selectedRoomId]);

  // Price calculations
  const pricePerNight = customPrice > 0 ? customPrice : activeRoom ? activeRoom.pricePerNight : 200;
  const rawTotal = pricePerNight * nights;
  const discountAmount = Math.round((rawTotal * discountPercent) / 100);
  const finalTotal = rawTotal - discountAmount;

  // Auto set paid amount initially to final total
  useEffect(() => {
    setPaidAmount(finalTotal);
  }, [finalTotal]);

  if (!isLinkGuestModalOpen) return null;

  const handleClose = () => {
    setIsLinkGuestModalOpen(false);
    setPreselectedGuestForLink(null);
    setPreselectedRoomForLink(null);
    setShowQuickAddGuest(false);
  };

  const handleQuickAddGuest = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGuestName.trim() || !newGuestPhone.trim()) return;

    const created = addOrUpdateGuest({
      name: newGuestName.trim(),
      phone: newGuestPhone.trim(),
      nationalId: newGuestNationalId.trim(),
    });

    setSelectedGuestId(created.id);
    setShowQuickAddGuest(false);
    setNewGuestName('');
    setNewGuestPhone('');
    setNewGuestNationalId('');
  };

  const handleConfirmLink = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedGuestId || !selectedRoomId) return;

    const success = await linkGuestToRoom({
      guestId: selectedGuestId,
      roomId: selectedRoomId,
      nights,
      pricePerNight,
      discountPercent,
      paidAmount,
      paymentMethod,
      notes: notes.trim() || undefined,
    });

    if (success) {
      handleClose();
    }
  };

  // Filtered guests for search
  const filteredGuests = guests.filter(
    (g) =>
      g.name.toLowerCase().includes(guestSearch.toLowerCase()) ||
      g.phone.includes(guestSearch) ||
      g.nationalId.includes(guestSearch)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60 sticky top-0 z-10 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 dark:bg-slate-800 text-white flex items-center justify-center">
              <ArrowLeftRight className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <h2 className="text-base font-bold text-slate-900 dark:text-white">
                ربط عميل بغرفة وتسكين فوري
              </h2>
              <p className="text-xs text-slate-500">
                اختر العميل والغرفة المتاحة لتوليد الحجز وتسكين النزيل
              </p>
            </div>
          </div>

          <button
            onClick={handleClose}
            className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleConfirmLink} className="p-4 sm:p-6 space-y-5">
          {/* Step 1: Select Customer */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
                <User className="w-3.5 h-3.5 text-emerald-600" />
                1. اختيار العميل / النزيل *
              </label>

              <button
                type="button"
                onClick={() => setShowQuickAddGuest(!showQuickAddGuest)}
                className="text-[11px] text-emerald-600 dark:text-emerald-400 hover:underline font-bold flex items-center gap-1 cursor-pointer"
              >
                <Plus className="w-3 h-3" />
                {showQuickAddGuest ? 'إلغاء الإضافة السريعة' : '+ إضافة عميل جديد'}
              </button>
            </div>

            {/* Quick Add Guest Subform */}
            {showQuickAddGuest ? (
              <div className="p-3 bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50 rounded-xl space-y-2.5">
                <span className="text-xs font-bold text-emerald-900 dark:text-emerald-200">
                  إضافة سريعة لعميل جديد في قاعدة البيانات:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    placeholder="اسم العميل *"
                    value={newGuestName}
                    onChange={(e) => setNewGuestName(e.target.value)}
                    className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded text-xs"
                    required
                  />
                  <input
                    type="tel"
                    placeholder="رقم الجوال *"
                    value={newGuestPhone}
                    onChange={(e) => setNewGuestPhone(e.target.value)}
                    className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded text-xs font-mono"
                    required
                  />
                  <input
                    type="text"
                    placeholder="رقم الهوية / الإقامة"
                    value={newGuestNationalId}
                    onChange={(e) => setNewGuestNationalId(e.target.value)}
                    className="px-2.5 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded text-xs font-mono"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleQuickAddGuest}
                  className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-xs font-bold shadow-xs cursor-pointer"
                >
                  حفظ واختيار العميل
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {/* Search box if many guests */}
                {guests.length > 5 && (
                  <div className="relative">
                    <Search className="w-3.5 h-3.5 absolute right-3 top-2.5 text-slate-400" />
                    <input
                      type="text"
                      placeholder="بحث عن عميل بالاسم أو الهاتف..."
                      value={guestSearch}
                      onChange={(e) => setGuestSearch(e.target.value)}
                      className="w-full pl-3 pr-8 py-1.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-lg text-xs"
                    />
                  </div>
                )}

                <select
                  value={selectedGuestId || ''}
                  onChange={(e) => setSelectedGuestId(parseInt(e.target.value))}
                  required
                  className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/60 border border-slate-300 dark:border-slate-700 rounded-xl text-xs font-medium focus:outline-emerald-500"
                >
                  <option value="">-- اختر عميلاً من القائمة --</option>
                  {filteredGuests.map((g) => (
                    <option key={g.id} value={g.id}>
                      {g.name} — {g.phone} {g.isVip ? '👑 (VIP)' : g.isFrequent ? `⭐ (${g.visitCount} إقامات - خصم ${g.loyaltyDiscountPercent}%)` : ''}
                    </option>
                  ))}
                </select>

                {/* Active Guest Badge */}
                {activeGuest && (
                  <div className="p-2.5 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60 rounded-xl flex items-center justify-between text-xs">
                    <div className="flex items-center gap-2">
                      <div className="w-7 h-7 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 flex items-center justify-center font-bold text-xs">
                        {activeGuest.name[0]}
                      </div>
                      <div>
                        <span className="font-bold text-slate-800 dark:text-slate-200">{activeGuest.name}</span>
                        <span className="text-slate-400 text-[11px] block">{activeGuest.phone}</span>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5">
                      {activeGuest.isVip && (
                        <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-600 text-[10px] font-bold border border-amber-500/30 flex items-center gap-0.5">
                          <Sparkles className="w-2.5 h-2.5" /> VIP
                        </span>
                      )}
                      {activeGuest.isFrequent && (
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 text-[10px] font-bold">
                          خصم دائم {activeGuest.loyaltyDiscountPercent}%
                        </span>
                      )}
                      <span className="text-[11px] text-slate-500 font-mono">
                        {activeGuest.visitCount} إقامات سابقة
                      </span>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Step 2: Select Room */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <Bed className="w-3.5 h-3.5 text-blue-600" />
              2. اختيار الغرفة المتاحة *
            </label>

            {availableRooms.length === 0 ? (
              <div className="p-3 bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 rounded-xl text-xs text-rose-700 dark:text-rose-300">
                لا توجد غرف متاحة حالياً. جميع الغرف مشغولة أو تحت التنظيف.
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {availableRooms.map((r) => (
                  <div
                    key={r.id}
                    onClick={() => setSelectedRoomId(r.id)}
                    className={`p-3 rounded-xl border cursor-pointer transition flex flex-col justify-between ${
                      selectedRoomId === r.id
                        ? 'border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/30 ring-2 ring-emerald-500/30'
                        : 'border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 hover:border-slate-300'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-bold text-sm text-slate-900 dark:text-white">
                          #{r.roomNumber}
                        </span>
                        <span className="text-[10px] text-slate-400 font-mono">ط {r.floor}</span>
                      </div>
                      <p className="text-[11px] text-slate-500 mt-0.5">{r.type}</p>
                    </div>

                    <div className="mt-2 pt-1 border-t border-slate-200/60 dark:border-slate-700/60 flex items-center justify-between text-[11px]">
                      <span className="font-bold text-emerald-600 dark:text-emerald-400">
                        {r.pricePerNight} {settings.currencySymbol}
                      </span>
                      <span className="text-[10px] text-slate-400">{r.capacity} أفراد</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Step 3: Financial & Booking Parameters */}
          <div className="p-4 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60 rounded-xl space-y-3">
            <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block border-b border-slate-200 dark:border-slate-700/60 pb-2">
              3. شروط الإقامة والحساب المالي
            </span>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {/* Nights */}
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                  عدد الليالي *
                </label>
                <input
                  type="number"
                  min="1"
                  max="365"
                  value={nights}
                  onChange={(e) => setNights(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs font-bold"
                  required
                />
              </div>

              {/* Price per night */}
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                  سعر الليلة ({settings.currencySymbol})
                </label>
                <input
                  type="number"
                  min="1"
                  value={customPrice}
                  onChange={(e) => setCustomPrice(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs font-bold"
                  required
                />
              </div>

              {/* Discount Percent */}
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1 flex items-center justify-between">
                  <span>نسبة الخصم %</span>
                  {activeGuest?.isFrequent && (
                    <span className="text-[9px] text-emerald-600 font-bold">خصم عميل دائم</span>
                  )}
                </label>
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={discountPercent}
                  onChange={(e) => setDiscountPercent(Math.min(100, Math.max(0, parseFloat(e.target.value) || 0)))}
                  className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs font-bold text-amber-600"
                />
              </div>

              {/* Advance Paid Amount */}
              <div>
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                  المبلغ المدفوع مقدماً ({settings.currencySymbol})
                </label>
                <input
                  type="number"
                  min="0"
                  max={finalTotal}
                  value={paidAmount}
                  onChange={(e) => setPaidAmount(parseFloat(e.target.value) || 0)}
                  className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs font-bold text-emerald-600"
                />
              </div>

              {/* Payment Method */}
              <div className="col-span-2">
                <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                  طريقة الدفع
                </label>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('card')}
                    className={`py-1.5 text-xs rounded-lg border font-medium transition cursor-pointer ${
                      paymentMethod === 'card'
                        ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-bold'
                        : 'border-slate-300 dark:border-slate-700 text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    بطاقة / مدى
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('cash')}
                    className={`py-1.5 text-xs rounded-lg border font-medium transition cursor-pointer ${
                      paymentMethod === 'cash'
                        ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-bold'
                        : 'border-slate-300 dark:border-slate-700 text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    نقداً كاش
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('transfer')}
                    className={`py-1.5 text-xs rounded-lg border font-medium transition cursor-pointer ${
                      paymentMethod === 'transfer'
                        ? 'border-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-bold'
                        : 'border-slate-300 dark:border-slate-700 text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800'
                    }`}
                  >
                    تحويل بنكي
                  </button>
                </div>
              </div>
            </div>

            {/* Notes */}
            <div>
              <label className="text-[11px] font-semibold text-slate-600 dark:text-slate-400 block mb-1">
                ملاحظات خاصة بالتسكين
              </label>
              <input
                type="text"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="سرير إضافي، تسجيل وصول متأخر..."
                className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs"
              />
            </div>

            {/* Summary Box */}
            <div className="p-3 bg-white dark:bg-slate-900 rounded-lg border border-slate-200 dark:border-slate-700/60 flex items-center justify-between text-xs">
              <div className="space-y-0.5">
                <span className="text-slate-500">إجمالي الحساب:</span>
                <div className="font-bold text-base text-slate-900 dark:text-white">
                  {finalTotal} {settings.currencySymbol}{' '}
                  {discountAmount > 0 && (
                    <span className="text-xs text-emerald-600 line-through text-[11px]">
                      {rawTotal} {settings.currencySymbol}
                    </span>
                  )}
                </div>
              </div>

              <div className="text-left space-y-0.5">
                <span className="text-slate-500">المتبقي عند الخروج:</span>
                <div
                  className={`font-bold text-sm ${
                    finalTotal - paidAmount > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-emerald-600'
                  }`}
                >
                  {Math.max(0, finalTotal - paidAmount)} {settings.currencySymbol}
                </div>
              </div>
            </div>
          </div>

          {/* Submit Actions */}
          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            <button
              type="button"
              onClick={handleClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition cursor-pointer"
            >
              إلغاء
            </button>

            <button
              type="submit"
              disabled={!selectedGuestId || !selectedRoomId || availableRooms.length === 0}
              className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-xs font-bold rounded-lg transition flex items-center gap-1.5 shadow-md shadow-emerald-600/20 cursor-pointer"
            >
              <CheckCircle className="w-4 h-4" />
              <span>تأكيد ربط وتسكين العميل في الغرفة</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
