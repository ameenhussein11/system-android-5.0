import React, { useCallback, useEffect, useRef } from 'react';
import { useHotel } from '../context/HotelContext';
import { buildDaySnapshot } from '../utils/closing';
import { putDay } from '../utils/archiveStore';
import { localDate } from '../utils/dates';

export const ARCHIVE_SAVED_EVENT = 'qasr-archive-saved';
export const ARCHIVE_SAVE_NOW_EVENT = 'qasr-archive-save-now';

/** Headless component: saves today's snapshot of the whole system (incl. the guest register) automatically. */
export const DailyArchiver: React.FC = () => {
  const h = useHotel();
  const ref = useRef(h);
  ref.current = h;
  const timer = useRef<number | undefined>(undefined);
  const lastDay = useRef(localDate());

  const save = useCallback(async () => {
    const d = ref.current;
    try {
      const date = localDate();
      const snap = buildDaySnapshot(date, {
        rooms: d.rooms,
        bookings: d.bookings,
        guests: d.guests,
        payments: d.payments,
        expenses: d.expenses,
        otherRevenues: d.otherRevenues,
        staffSalaries: d.staffSalaries,
        logs: d.logs,
        hotelName: d.settings.hotelName,
      });
      await putDay(snap);
      window.dispatchEvent(new CustomEvent(ARCHIVE_SAVED_EVENT, { detail: date }));
    } catch (err) {
      console.error('Daily archive failed', err);
    }
  }, []);

  // after any data change: save 4s later (one write per burst of edits)
  useEffect(() => {
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(save, 4000);
    return () => window.clearTimeout(timer.current);
  }, [h.rooms, h.guests, h.bookings, h.payments, h.expenses, h.otherRevenues, h.staffSalaries, h.logs, save]);

  useEffect(() => {
    const onHide = () => {
      if (document.visibilityState === 'hidden') save();
    };
    const onNow = () => save();
    document.addEventListener('visibilitychange', onHide);
    window.addEventListener('pagehide', onNow);
    window.addEventListener(ARCHIVE_SAVE_NOW_EVENT, onNow);
    // day rollover while the app stays open: start the new day's snapshot
    const iv = window.setInterval(() => {
      const today = localDate();
      if (today !== lastDay.current) {
        lastDay.current = today;
        save();
      }
    }, 60000);
    return () => {
      document.removeEventListener('visibilitychange', onHide);
      window.removeEventListener('pagehide', onNow);
      window.removeEventListener(ARCHIVE_SAVE_NOW_EVENT, onNow);
      window.clearInterval(iv);
    };
  }, [save]);

  return null;
};
