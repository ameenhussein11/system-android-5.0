import React, { useState, useMemo, useEffect } from 'react';
import { useHotel } from '../context/HotelContext';
import { HousekeepingTask, CleaningPriority, CleaningStatus, Room, RoomStatus, StaffMember } from '../types/hotel';
import {
  Sparkles,
  CheckCircle2,
  Clock,
  AlertCircle,
  User,
  CheckSquare,
  Square,
  Filter,
  ShieldCheck,
  Building,
  ListTodo,
  Layers,
  Wrench,
  BedDouble,
  ArrowRight,
  Zap,
  CalendarCheck,
  UserCheck,
  RotateCcw,
  Sparkle,
  Users,
  Shuffle,
  ChevronDown,
  Phone,
  Briefcase,
  SlidersHorizontal,
  Check,
  Share2,
  Printer,
  BadgeCheck,
} from 'lucide-react';

interface DailyQueueItem {
  id: string;
  roomId: number;
  roomNumber: string;
  floor: number;
  roomType: string;
  currentStatus: RoomStatus;
  guestName?: string | null;
  checkOutDate?: string | null;
  taskType: 'checkout_deep_clean' | 'stayover_service' | 'maintenance_inspection' | 'quick_refresh';
  taskTitle: string;
  priority: CleaningPriority;
  suggestedDurationMins: number;
  assignedStaff: string;
  assignedStaffId?: number;
  isCompleted: boolean;
  notes?: string;
}

export const HousekeepingView: React.FC = () => {
  const {
    rooms,
    housekeeping,
    staffMembers,
    completeHousekeeping,
    updateHousekeepingStatus,
    toggleHousekeepingChecklist,
    assignHousekeeper,
    updateRoomStatus,
  } = useHotel();

  const [activeSubTab, setActiveSubTab] = useState<'queue' | 'active_tasks' | 'staff_distribution'>('queue');
  const [selectedStaffFilter, setSelectedStaffFilter] = useState<string>('all');
  const [priorityFilter, setPriorityFilter] = useState<string>('all');
  const [floorFilter, setFloorFilter] = useState<string>('all');
  const [taskTypeFilter, setTaskTypeFilter] = useState<string>('all');
  const [assignmentFeedback, setAssignmentFeedback] = useState<string | null>(null);

  // Local state for queue room staff assignments (persists across view switches)
  const [roomAssignments, setRoomAssignments] = useState<Record<number, string>>(() => {
    const saved = localStorage.getItem('qasr_room_staff_assignments');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return {};
      }
    }
    return {};
  });

  // Save assignments to localStorage
  useEffect(() => {
    localStorage.setItem('qasr_room_staff_assignments', JSON.stringify(roomAssignments));
  }, [roomAssignments]);

  // Active staff members filtered from stored employees list
  const activeEmployees = useMemo(() => {
    const active = staffMembers.filter((s) => s.status === 'active');
    if (active.length > 0) return active;
    // Fallback if none configured
    return staffMembers;
  }, [staffMembers]);

  // Housekeeping & maintenance specific employees
  const housekeepingTeam = useMemo(() => {
    const team = activeEmployees.filter(
      (s) => s.role === 'housekeeper' || s.role === 'maintenance' || s.role === 'manager'
    );
    return team.length > 0 ? team : activeEmployees;
  }, [activeEmployees]);

  // Dynamic Daily Task Queue based on current room states & staff assignments
  const dailyQueueItems: DailyQueueItem[] = useMemo(() => {
    return rooms.map((room) => {
      const activeTask = housekeeping.find((h) => h.roomId === room.id);
      let taskType: DailyQueueItem['taskType'] = 'quick_refresh';
      let taskTitle = 'فحص جاهزية وتجهيز يومي';
      let priority: CleaningPriority = 'low';
      let suggestedDurationMins = 15;
      let isCompleted = false;

      // Determine staff assignment (Active task > Manual local assignment > Fallback team round-robin)
      let assignedStaffName = activeTask?.assignedTo || roomAssignments[room.id];
      if (!assignedStaffName) {
        const defaultMember = housekeepingTeam[room.floor % (housekeepingTeam.length || 1)];
        assignedStaffName = defaultMember ? defaultMember.name : 'فريق النظافة';
      }

      const assignedEmployee = activeEmployees.find((e) => e.name === assignedStaffName);

      if (room.status === 'cleaning') {
        taskType = 'checkout_deep_clean';
        taskTitle = 'تعقيم وتنظيف شامل بعد المغادرة (Deep Clean)';
        priority = activeTask?.priority || 'urgent';
        suggestedDurationMins = 35;
        isCompleted = activeTask?.status === 'clean';
      } else if (room.status === 'occupied') {
        taskType = 'stayover_service';
        taskTitle = 'خدمة وترتيب الغرفة اليومية أثناء الإقامة (Stayover)';
        priority = 'normal';
        suggestedDurationMins = 20;
      } else if (room.status === 'maintenance') {
        taskType = 'maintenance_inspection';
        taskTitle = 'متابعة الصيانة وإعادة الفحص والتعقيم';
        priority = 'urgent';
        suggestedDurationMins = 45;
      } else {
        // Available
        taskType = 'quick_refresh';
        taskTitle = 'تفقّد اللمسات الأخيرة والتعطير قبل وصول النزيل';
        priority = 'low';
        suggestedDurationMins = 10;
        isCompleted = true;
      }

      return {
        id: `queue-${room.id}`,
        roomId: room.id,
        roomNumber: room.roomNumber,
        floor: room.floor,
        roomType: room.type,
        currentStatus: room.status,
        guestName: room.currentGuestName,
        checkOutDate: room.checkOutDate,
        taskType,
        taskTitle,
        priority,
        suggestedDurationMins,
        assignedStaff: assignedStaffName,
        assignedStaffId: assignedEmployee?.id,
        isCompleted,
        notes: room.notes,
      };
    });
  }, [rooms, housekeeping, roomAssignments, housekeepingTeam, activeEmployees]);

  // Handle staff assignment for a single room
  const handleAssignStaffToRoom = (roomId: number, staffName: string) => {
    // 1. Update local state
    setRoomAssignments((prev) => ({
      ...prev,
      [roomId]: staffName,
    }));

    // 2. If there is an active housekeeping task in context, update it as well
    const activeTask = housekeeping.find((h) => h.roomId === roomId);
    if (activeTask) {
      assignHousekeeper(activeTask.id, staffName);
    }

    const room = rooms.find((r) => r.id === roomId);
    setAssignmentFeedback(`تم تعيين الموظف (${staffName}) للغرفة #${room?.roomNumber || roomId}`);
    setTimeout(() => setAssignmentFeedback(null), 3500);
  };

  // Bulk: Auto-distribute tasks equally across all active housekeeping team members
  const handleAutoDistributeEvenly = () => {
    if (housekeepingTeam.length === 0) return;
    const newAssignments: Record<number, string> = { ...roomAssignments };
    
    // Distribute rooms needing attention first (cleaning, occupied)
    const prioritizedRooms = [...rooms].sort((a, b) => {
      const score = (r: Room) => (r.status === 'cleaning' ? 3 : r.status === 'occupied' ? 2 : 1);
      return score(b) - score(a);
    });

    prioritizedRooms.forEach((room, index) => {
      const assignedEmployee = housekeepingTeam[index % housekeepingTeam.length];
      newAssignments[room.id] = assignedEmployee.name;

      const activeTask = housekeeping.find((h) => h.roomId === room.id);
      if (activeTask) {
        assignHousekeeper(activeTask.id, assignedEmployee.name);
      }
    });

    setRoomAssignments(newAssignments);
    setAssignmentFeedback(`تم توزيع جميع غرف الفندق بالتساوي على ${housekeepingTeam.length} موظفين بنجاح!`);
    setTimeout(() => setAssignmentFeedback(null), 4000);
  };

  // Bulk: Assign an entire floor to a specific employee
  const handleAssignFloorToStaff = (floorNumber: number, staffName: string) => {
    if (!staffName) return;
    const newAssignments: Record<number, string> = { ...roomAssignments };
    let count = 0;

    rooms.forEach((room) => {
      if (room.floor === floorNumber) {
        newAssignments[room.id] = staffName;
        count++;

        const activeTask = housekeeping.find((h) => h.roomId === room.id);
        if (activeTask) {
          assignHousekeeper(activeTask.id, staffName);
        }
      }
    });

    setRoomAssignments(newAssignments);
    setAssignmentFeedback(`تم إسناد الطابق ${floorNumber} بالكامل (${count} غرف) إلى الموظف: ${staffName}`);
    setTimeout(() => setAssignmentFeedback(null), 4000);
  };

  // Workload summary per employee
  const staffWorkloads = useMemo(() => {
    return activeEmployees.map((staff) => {
      const assignedItems = dailyQueueItems.filter((item) => item.assignedStaff === staff.name);
      const cleaningCount = assignedItems.filter((i) => i.currentStatus === 'cleaning').length;
      const stayoverCount = assignedItems.filter((i) => i.currentStatus === 'occupied').length;
      const readyCount = assignedItems.filter((i) => i.currentStatus === 'available').length;
      const totalMinutes = assignedItems.reduce((acc, curr) => acc + curr.suggestedDurationMins, 0);

      return {
        staff,
        totalAssigned: assignedItems.length,
        cleaningCount,
        stayoverCount,
        readyCount,
        totalMinutes,
        estimatedHours: (totalMinutes / 60).toFixed(1),
        assignedRooms: assignedItems.map((i) => i.roomNumber),
      };
    });
  }, [activeEmployees, dailyQueueItems]);

  // Overall queue counts and stats
  const queueStats = useMemo(() => {
    const total = dailyQueueItems.length;
    const cleaningNeeded = dailyQueueItems.filter((q) => q.currentStatus === 'cleaning').length;
    const stayover = dailyQueueItems.filter((q) => q.currentStatus === 'occupied').length;
    const maintenance = dailyQueueItems.filter((q) => q.currentStatus === 'maintenance').length;
    const ready = dailyQueueItems.filter((q) => q.currentStatus === 'available').length;
    const totalMins = dailyQueueItems
      .filter((q) => q.currentStatus === 'cleaning' || q.currentStatus === 'occupied')
      .reduce((sum, q) => sum + q.suggestedDurationMins, 0);

    return { total, cleaningNeeded, stayover, maintenance, ready, totalEstimatedHours: (totalMins / 60).toFixed(1) };
  }, [dailyQueueItems]);

  // Filtered Queue Items
  const filteredQueue = useMemo(() => {
    return dailyQueueItems.filter((item) => {
      if (floorFilter !== 'all' && item.floor.toString() !== floorFilter) return false;
      if (priorityFilter !== 'all' && item.priority !== priorityFilter) return false;
      if (taskTypeFilter !== 'all' && item.taskType !== taskTypeFilter) return false;
      if (selectedStaffFilter !== 'all' && item.assignedStaff !== selectedStaffFilter) return false;
      return true;
    });
  }, [dailyQueueItems, floorFilter, priorityFilter, taskTypeFilter, selectedStaffFilter]);

  // Active Housekeeping Tasks from Context
  const filteredTasks = housekeeping.filter((task) => {
    if (selectedStaffFilter !== 'all' && task.assignedTo !== selectedStaffFilter) return false;
    if (priorityFilter !== 'all' && task.priority !== priorityFilter) return false;
    return true;
  });

  const getPriorityBadge = (p: CleaningPriority) => {
    switch (p) {
      case 'urgent':
        return 'bg-rose-500/15 text-rose-600 dark:text-rose-400 border-rose-500/30';
      case 'normal':
        return 'bg-amber-500/15 text-amber-600 dark:text-amber-400 border-amber-500/30';
      case 'low':
        return 'bg-slate-500/15 text-slate-600 dark:text-slate-400 border-slate-500/30';
    }
  };

  const getStatusBadge = (s: CleaningStatus) => {
    switch (s) {
      case 'dirty':
        return { label: 'بانتظار البدء', color: 'bg-rose-500 text-white' };
      case 'in_progress':
        return { label: 'جاري التنظيف', color: 'bg-amber-500 text-white' };
      case 'inspected':
        return { label: 'تم الفحص', color: 'bg-indigo-500 text-white' };
      case 'clean':
        return { label: 'مكتملة وجاهزة', color: 'bg-emerald-500 text-white' };
    }
  };

  const getTaskTypeInfo = (type: DailyQueueItem['taskType']) => {
    switch (type) {
      case 'checkout_deep_clean':
        return {
          label: 'تنظيف عميق (مغادرة)',
          badge: 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800',
          icon: Sparkles,
        };
      case 'stayover_service':
        return {
          label: 'ترتيب يومي (نزيل مقيم)',
          badge: 'bg-sky-50 dark:bg-sky-950/40 text-sky-700 dark:text-sky-300 border-sky-200 dark:border-sky-800',
          icon: BedDouble,
        };
      case 'maintenance_inspection':
        return {
          label: 'صيانة وفحص فني',
          badge: 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800',
          icon: Wrench,
        };
      case 'quick_refresh':
        return {
          label: 'جاهزة / لمسات سريعة',
          badge: 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
          icon: ShieldCheck,
        };
    }
  };

  // Quick action: send room to cleaning list
  const triggerCleaning = (roomId: number) => {
    updateRoomStatus(roomId, 'cleaning', 'تم تحويل الغرفة للتنظيف والتعقيم الفوري عبر قائمة المهام اليومية');
  };

  return (
    <div className="space-y-4">
      {/* Toast Feedback for Assignments */}
      {assignmentFeedback && (
        <div className="bg-emerald-600 text-white px-4 py-2.5 rounded-xl shadow-lg flex items-center justify-between text-xs font-bold animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>{assignmentFeedback}</span>
          </div>
          <button onClick={() => setAssignmentFeedback(null)} className="text-white/80 hover:text-white">
            ✕
          </button>
        </div>
      )}

      {/* Top Banner & Navigation Header */}
      <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h2 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-500" />
            إدارة الهاوس كيبينج وتوزيع المهام على الموظفين
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            إسناد وتوزيع مهام تنظيف وتعقيم الغرف على الموظفين المسجلين في النظام ومتابعة أحمال العمل
          </p>
        </div>

        {/* View Toggle Tabs */}
        <div className="flex flex-wrap items-center gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
          <button
            onClick={() => setActiveSubTab('queue')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeSubTab === 'queue'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <ListTodo className="w-4 h-4" />
            <span>قائمة المهام اليومية (Daily Queue)</span>
            <span className="text-[10px] bg-slate-900/15 dark:bg-black/30 px-1.5 py-0.2 rounded-full font-mono">
              {queueStats.total}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('staff_distribution')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeSubTab === 'staff_distribution'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>أحمال الموظفين وتوزيع الطوابق</span>
            <span className="text-[10px] bg-sky-500 text-white px-1.5 py-0.2 rounded-full font-mono">
              {activeEmployees.length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('active_tasks')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition cursor-pointer ${
              activeSubTab === 'active_tasks'
                ? 'bg-amber-500 text-slate-950 shadow-sm'
                : 'text-slate-600 dark:text-slate-300 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>بطاقات التنظيف النشطة</span>
            {housekeeping.length > 0 && (
              <span className="text-[10px] bg-rose-500 text-white px-1.5 py-0.2 rounded-full font-mono">
                {housekeeping.length}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* KPI Overview Summary */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3">
        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-rose-200 dark:border-rose-900/40 shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-rose-50 dark:bg-rose-950/50 flex items-center justify-center text-rose-500 shrink-0">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-rose-600 dark:text-rose-400 font-mono">
              {queueStats.cleaningNeeded}
            </div>
            <div className="text-[11px] text-slate-500 font-medium">بحاجة لتنظيف عميق</div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-sky-200 dark:border-sky-900/40 shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-sky-50 dark:bg-sky-950/50 flex items-center justify-center text-sky-500 shrink-0">
            <BedDouble className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-sky-600 dark:text-sky-400 font-mono">
              {queueStats.stayover}
            </div>
            <div className="text-[11px] text-slate-500 font-medium">ترتيب يومي (نزيل مقيم)</div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-amber-200 dark:border-amber-900/40 shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-50 dark:bg-amber-950/50 flex items-center justify-center text-amber-500 shrink-0">
            <Wrench className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-amber-600 dark:text-amber-400 font-mono">
              {queueStats.maintenance}
            </div>
            <div className="text-[11px] text-slate-500 font-medium">غرف قيد الصيانة</div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-emerald-200 dark:border-emerald-900/40 shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 dark:bg-emerald-950/50 flex items-center justify-center text-emerald-500 shrink-0">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-emerald-600 dark:text-emerald-400 font-mono">
              {queueStats.ready}
            </div>
            <div className="text-[11px] text-slate-500 font-medium">غرف جاهزة ومعقمة</div>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm flex items-center gap-3 col-span-2 sm:col-span-1">
          <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-600 dark:text-slate-300 shrink-0">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xl font-bold text-slate-900 dark:text-white font-mono">
              {queueStats.totalEstimatedHours} <span className="text-xs font-normal">ساعة</span>
            </div>
            <div className="text-[11px] text-slate-500 font-medium">تقدير وقت إنجاز الوردية</div>
          </div>
        </div>
      </div>

      {/* SUBTAB 1: DAILY TASK QUEUE (قائمة المهام اليومية مع إسناد الموظفين المباشر) */}
      {activeSubTab === 'queue' && (
        <div className="space-y-3">
          {/* Quick Bulk Distribution Toolbar */}
          <div className="bg-amber-50 dark:bg-slate-800/80 border border-amber-200 dark:border-amber-900/40 p-3 rounded-xl flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400 shrink-0" />
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">
                أدوات التوزيع السريع لمهام الوردية:
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Auto distribute equally */}
              <button
                onClick={handleAutoDistributeEvenly}
                className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-lg text-xs transition flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Shuffle className="w-3.5 h-3.5" />
                <span>توزيع المهام بالتساوي على طاقم النظافة ({housekeepingTeam.length} موظفين)</span>
              </button>

              {/* Assign floor shortcut */}
              <div className="flex items-center gap-1 bg-white dark:bg-slate-900 p-1 rounded-lg border border-slate-200 dark:border-slate-700">
                <span className="text-[11px] text-slate-500 px-1 font-medium">إسناد طابق:</span>
                <select
                  id="bulkFloorSelect"
                  className="bg-transparent text-xs text-slate-700 dark:text-slate-300 font-semibold focus:outline-none"
                  defaultValue="1"
                >
                  <option value="1">الطابق 1</option>
                  <option value="2">الطابق 2</option>
                  <option value="3">الطابق 3</option>
                  <option value="4">الطابق 4</option>
                </select>
                <span className="text-slate-400 text-xs">←</span>
                <select
                  id="bulkStaffSelect"
                  className="bg-transparent text-xs text-slate-700 dark:text-slate-300 font-semibold focus:outline-none max-w-[130px] truncate"
                  defaultValue=""
                >
                  <option value="" disabled>
                    اختر الموظف
                  </option>
                  {activeEmployees.map((staff) => (
                    <option key={staff.id} value={staff.name}>
                      {staff.name} ({staff.roleTitleAr})
                    </option>
                  ))}
                </select>
                <button
                  onClick={() => {
                    const floorSelect = document.getElementById('bulkFloorSelect') as HTMLSelectElement;
                    const staffSelect = document.getElementById('bulkStaffSelect') as HTMLSelectElement;
                    if (floorSelect && staffSelect && staffSelect.value) {
                      handleAssignFloorToStaff(parseInt(floorSelect.value, 10), staffSelect.value);
                    }
                  }}
                  className="px-2 py-1 bg-slate-800 dark:bg-slate-700 hover:bg-slate-700 text-white rounded text-[11px] font-bold cursor-pointer transition"
                >
                  تطبيق
                </button>
              </div>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-slate-500 font-bold flex items-center gap-1">
                <Filter className="w-3.5 h-3.5" />
                تصفية القائمة:
              </span>

              {/* Task Type Filter */}
              <select
                value={taskTypeFilter}
                onChange={(e) => setTaskTypeFilter(e.target.value)}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs rounded-lg px-2.5 py-1.5 text-slate-700 dark:text-slate-300 focus:outline-none"
              >
                <option value="all">كل أنواع المهام</option>
                <option value="checkout_deep_clean">تنظيف مغادرة (Deep Clean)</option>
                <option value="stayover_service">ترتيب يومي (Stayover)</option>
                <option value="maintenance_inspection">صيانة وفحص</option>
                <option value="quick_refresh">جاهزة / تفقّد سريع</option>
              </select>

              {/* Floor Filter */}
              <select
                value={floorFilter}
                onChange={(e) => setFloorFilter(e.target.value)}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs rounded-lg px-2.5 py-1.5 text-slate-700 dark:text-slate-300 focus:outline-none"
              >
                <option value="all">جميع الطوابق</option>
                <option value="1">الطابق الأول</option>
                <option value="2">الطابق الثاني</option>
                <option value="3">الطابق الثالث</option>
                <option value="4">الطابق الرابع</option>
              </select>

              {/* Priority Filter */}
              <select
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value)}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs rounded-lg px-2.5 py-1.5 text-slate-700 dark:text-slate-300 focus:outline-none"
              >
                <option value="all">كل الأولويات</option>
                <option value="urgent">عاجل جداً 🔥</option>
                <option value="normal">عادي</option>
                <option value="low">منخفض</option>
              </select>

              {/* Staff Filter */}
              <select
                value={selectedStaffFilter}
                onChange={(e) => setSelectedStaffFilter(e.target.value)}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs rounded-lg px-2.5 py-1.5 text-slate-700 dark:text-slate-300 focus:outline-none"
              >
                <option value="all">جميع الموظفين ({activeEmployees.length})</option>
                {activeEmployees.map((staff) => (
                  <option key={staff.id} value={staff.name}>
                    {staff.name} — {staff.roleTitleAr}
                  </option>
                ))}
              </select>
            </div>

            <div className="text-xs text-slate-400 font-mono">
              عرض {filteredQueue.length} من أصل {dailyQueueItems.length} غرفة
            </div>
          </div>

          {/* Daily Task Queue Table / List with Employee Selector */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm">
            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/60 text-slate-500 font-bold border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="p-3">الغرفة</th>
                    <th className="p-3">حالة الغرفة الحالية</th>
                    <th className="p-3">المهمة الموكلة</th>
                    <th className="p-3">الأولوية</th>
                    <th className="p-3">النزيل المقيم / الملاحظات</th>
                    <th className="p-3">الموظف المسؤول (تخصيص مباشر)</th>
                    <th className="p-3">الوقت المقدر</th>
                    <th className="p-3 text-center">الإجراء المباشر</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                  {filteredQueue.map((item) => {
                    const taskInfo = getTaskTypeInfo(item.taskType);
                    const TaskIcon = taskInfo.icon;
                    const assignedEmp = activeEmployees.find((e) => e.name === item.assignedStaff);

                    return (
                      <tr
                        key={item.id}
                        className={`hover:bg-slate-50/70 dark:hover:bg-slate-800/40 transition ${
                          item.currentStatus === 'cleaning'
                            ? 'bg-rose-50/30 dark:bg-rose-950/10'
                            : item.currentStatus === 'occupied'
                            ? 'bg-sky-50/20 dark:bg-sky-950/10'
                            : ''
                        }`}
                      >
                        {/* Room Number & Floor */}
                        <td className="p-3">
                          <div className="flex items-center gap-2">
                            <div
                              className={`w-9 h-9 rounded-lg font-bold flex items-center justify-center text-xs font-mono border ${
                                item.currentStatus === 'cleaning'
                                  ? 'bg-rose-100 dark:bg-rose-900/30 text-rose-600 border-rose-300 dark:border-rose-800'
                                  : item.currentStatus === 'occupied'
                                  ? 'bg-sky-100 dark:bg-sky-900/30 text-sky-600 border-sky-300 dark:border-sky-800'
                                  : item.currentStatus === 'maintenance'
                                  ? 'bg-amber-100 dark:bg-amber-900/30 text-amber-600 border-amber-300 dark:border-amber-800'
                                  : 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 border-emerald-300 dark:border-emerald-800'
                              }`}
                            >
                              #{item.roomNumber}
                            </div>
                            <div>
                              <div className="font-bold text-slate-900 dark:text-white">
                                غرفة {item.roomNumber}
                              </div>
                              <div className="text-[10px] text-slate-400">
                                الطابق {item.floor} • {item.roomType}
                              </div>
                            </div>
                          </div>
                        </td>

                        {/* Room Current Status */}
                        <td className="p-3">
                          {item.currentStatus === 'cleaning' && (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-rose-500 text-white">
                              <Sparkles className="w-3 h-3" />
                              بحاجة تنظيف
                            </span>
                          )}
                          {item.currentStatus === 'occupied' && (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-sky-500 text-white">
                              <BedDouble className="w-3 h-3" />
                              مشغولة بنزيل
                            </span>
                          )}
                          {item.currentStatus === 'maintenance' && (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-amber-500 text-white">
                              <Wrench className="w-3 h-3" />
                              تحت الصيانة
                            </span>
                          )}
                          {item.currentStatus === 'available' && (
                            <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-500 text-white">
                              <CheckCircle2 className="w-3 h-3" />
                              متاحة ونظيفة
                            </span>
                          )}
                        </td>

                        {/* Assigned Task Title */}
                        <td className="p-3">
                          <div className="flex items-center gap-1.5">
                            <span
                              className={`inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-md border ${taskInfo.badge}`}
                            >
                              <TaskIcon className="w-3 h-3 shrink-0" />
                              {taskInfo.label}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400 mt-0.5">{item.taskTitle}</p>
                        </td>

                        {/* Priority */}
                        <td className="p-3">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getPriorityBadge(
                              item.priority
                            )}`}
                          >
                            {item.priority === 'urgent'
                              ? '🔥 عاجل'
                              : item.priority === 'normal'
                              ? 'عادي'
                              : 'منخفض'}
                          </span>
                        </td>

                        {/* Guest / Context Info */}
                        <td className="p-3">
                          {item.guestName ? (
                            <div>
                              <div className="font-semibold text-slate-800 dark:text-slate-200">
                                {item.guestName}
                              </div>
                              {item.checkOutDate && (
                                <div className="text-[10px] text-slate-400">
                                  مغادرة: {item.checkOutDate}
                                </div>
                              )}
                            </div>
                          ) : (
                            <span className="text-slate-400 text-[11px]">
                              {item.notes || 'لا توجد ملاحظات خاصة'}
                            </span>
                          )}
                        </td>

                        {/* Individual Staff Assignment Dropdown (Based on Stored Employees) */}
                        <td className="p-3">
                          <div className="flex items-center gap-1.5">
                            <div className="w-6 h-6 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500 shrink-0">
                              <User className="w-3.5 h-3.5" />
                            </div>
                            <select
                              value={item.assignedStaff}
                              onChange={(e) => handleAssignStaffToRoom(item.roomId, e.target.value)}
                              className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs rounded-lg px-2 py-1 text-slate-800 dark:text-slate-200 font-semibold focus:outline-none focus:ring-1 focus:ring-amber-500 shadow-2xs max-w-[170px]"
                            >
                              <optgroup label="طاقم الهاوس كيبينج المعتمد">
                                {housekeepingTeam.map((emp) => (
                                  <option key={emp.id} value={emp.name}>
                                    {emp.name} ({emp.roleTitleAr})
                                  </option>
                                ))}
                              </optgroup>
                              {activeEmployees.length > housekeepingTeam.length && (
                                <optgroup label="باقي موظفي الفندق">
                                  {activeEmployees
                                    .filter((emp) => !housekeepingTeam.some((h) => h.id === emp.id))
                                    .map((emp) => (
                                      <option key={emp.id} value={emp.name}>
                                        {emp.name} ({emp.roleTitleAr})
                                      </option>
                                    ))}
                                </optgroup>
                              )}
                            </select>
                          </div>
                        </td>

                        {/* Estimated Duration */}
                        <td className="p-3 font-mono text-slate-600 dark:text-slate-300">
                          <div className="flex items-center gap-1">
                            <Clock className="w-3 h-3 text-slate-400" />
                            <span>{item.suggestedDurationMins} دقيقة</span>
                          </div>
                        </td>

                        {/* Action Buttons */}
                        <td className="p-3 text-center">
                          {item.currentStatus === 'cleaning' ? (
                            <button
                              onClick={() => completeHousekeeping(item.roomId)}
                              className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition inline-flex items-center gap-1 cursor-pointer shadow-sm"
                            >
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>إتمام وجعلها متاحة</span>
                            </button>
                          ) : item.currentStatus === 'occupied' ? (
                            <button
                              onClick={() => triggerCleaning(item.roomId)}
                              title="إرسال طلب ترتيب وتنظيف فوري للغرفة"
                              className="px-2.5 py-1 bg-sky-50 dark:bg-sky-950/50 hover:bg-sky-100 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800 rounded-lg text-xs font-semibold transition inline-flex items-center gap-1 cursor-pointer"
                            >
                              <Sparkle className="w-3 h-3" />
                              <span>طلب ترتيب الغرفة</span>
                            </button>
                          ) : item.currentStatus === 'maintenance' ? (
                            <button
                              onClick={() =>
                                updateRoomStatus(item.roomId, 'cleaning', 'تم انتهاء الصيانة وجاهزة للتعقيم')
                              }
                              className="px-2.5 py-1 bg-amber-50 dark:bg-amber-950/50 hover:bg-amber-100 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 rounded-lg text-xs font-semibold transition inline-flex items-center gap-1 cursor-pointer"
                            >
                              <Zap className="w-3 h-3" />
                              <span>إنهاء الصيانة والبدء بالتنظيف</span>
                            </button>
                          ) : (
                            <button
                              onClick={() => triggerCleaning(item.roomId)}
                              className="px-2 py-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-[11px] rounded transition inline-flex items-center gap-1 cursor-pointer"
                            >
                              <RotateCcw className="w-3 h-3" />
                              <span>إعادة فحص وتعقيم</span>
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: STAFF WORKLOAD & FLOOR DISTRIBUTION (لوحة توزيع أحمال الموظفين) */}
      {activeSubTab === 'staff_distribution' && (
        <div className="space-y-4">
          <div className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-slate-200 dark:border-slate-800 flex items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-2">
                <Users className="w-4 h-4 text-sky-500" />
                توزيع الغرف وأحمال العمل حسب قائمة الموظفين المسجلين ({staffWorkloads.length} موظف)
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                يمكنك النقر على أي موظف لمشاهدة الغرف المسندة إليه فقط في قائمة المهام
              </p>
            </div>

            <button
              onClick={handleAutoDistributeEvenly}
              className="px-3.5 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs transition flex items-center gap-2 shadow-sm cursor-pointer"
            >
              <Shuffle className="w-4 h-4" />
              <span>إعادة موازنة المهام بالتساوي</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {staffWorkloads.map(({ staff, totalAssigned, cleaningCount, stayoverCount, readyCount, estimatedHours, assignedRooms }) => (
              <div
                key={staff.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm hover:border-amber-400 dark:hover:border-amber-500/50 transition space-y-3 flex flex-col justify-between"
              >
                <div>
                  {/* Header: Employee Info */}
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div className="w-11 h-11 rounded-xl bg-sky-50 dark:bg-sky-950/60 border border-sky-200 dark:border-sky-800/60 text-sky-600 dark:text-sky-400 font-bold flex items-center justify-center text-base">
                        {staff.name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 dark:text-white text-sm flex items-center gap-1.5">
                          {staff.name}
                          {staff.role === 'housekeeper' && (
                            <BadgeCheck className="w-3.5 h-3.5 text-emerald-500" />
                          )}
                        </h4>
                        <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
                          <span className="font-medium">{staff.roleTitleAr}</span>
                          {staff.phone && (
                            <span className="text-[10px] text-slate-400 font-mono flex items-center gap-0.5">
                              <Phone className="w-2.5 h-2.5" />
                              {staff.phone}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="text-left">
                      <span className="text-xs font-mono font-bold text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/40 px-2 py-0.5 rounded-full border border-amber-200 dark:border-amber-900/40">
                        {totalAssigned} غرف
                      </span>
                    </div>
                  </div>

                  {/* Workload Stats Metrics */}
                  <div className="grid grid-cols-3 gap-2 mt-3 text-center text-xs">
                    <div className="bg-rose-50 dark:bg-rose-950/30 p-2 rounded-xl border border-rose-100 dark:border-rose-900/30">
                      <div className="font-bold text-rose-600 dark:text-rose-400 font-mono text-sm">
                        {cleaningCount}
                      </div>
                      <div className="text-[10px] text-slate-500">تنظيف عميق</div>
                    </div>

                    <div className="bg-sky-50 dark:bg-sky-950/30 p-2 rounded-xl border border-sky-100 dark:border-sky-900/30">
                      <div className="font-bold text-sky-600 dark:text-sky-400 font-mono text-sm">
                        {stayoverCount}
                      </div>
                      <div className="text-[10px] text-slate-500">ترتيب مقيم</div>
                    </div>

                    <div className="bg-slate-50 dark:bg-slate-800/50 p-2 rounded-xl border border-slate-200 dark:border-slate-700">
                      <div className="font-bold text-slate-800 dark:text-slate-200 font-mono text-sm">
                        {estimatedHours} س
                      </div>
                      <div className="text-[10px] text-slate-500">وقت متوقع</div>
                    </div>
                  </div>

                  {/* Assigned Room Badges */}
                  <div className="mt-3">
                    <span className="text-[11px] text-slate-400 font-medium block mb-1.5">
                      الغرف المسندة لهذا الموظف:
                    </span>
                    <div className="flex flex-wrap gap-1">
                      {assignedRooms.length > 0 ? (
                        assignedRooms.map((num) => (
                          <span
                            key={num}
                            className="bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 text-[11px] font-mono font-bold px-2 py-0.5 rounded-md border border-slate-200 dark:border-slate-700"
                          >
                            #{num}
                          </span>
                        ))
                      ) : (
                        <span className="text-xs text-slate-400 italic">لا توجد غرف مسندة حالياً</span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Card Footer Actions */}
                <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-2">
                  <button
                    onClick={() => {
                      setSelectedStaffFilter(staff.name);
                      setActiveSubTab('queue');
                    }}
                    className="flex-1 py-1.5 bg-slate-100 dark:bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-700 dark:text-slate-300 font-bold rounded-lg text-xs transition flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <span>عرض مهام {staff.name.split(' ')[0]}</span>
                    <ArrowRight className="w-3.5 h-3.5 rotate-180" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SUBTAB 3: ACTIVE TASKS & DETAILED CHECKLISTS */}
      {activeSubTab === 'active_tasks' && (
        <div className="space-y-4">
          {/* Filters for Active Tasks */}
          <div className="flex items-center justify-between gap-2 bg-white dark:bg-slate-900 p-3 rounded-xl border border-slate-200 dark:border-slate-800">
            <div className="flex items-center gap-2">
              <select
                value={priorityFilter}
                onChange={(e) => setPriorityFilter(e.target.value)}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs rounded-lg px-2.5 py-1.5 text-slate-700 dark:text-slate-300 focus:outline-none"
              >
                <option value="all">كل الأولويات</option>
                <option value="urgent">عاجل جداً 🔥</option>
                <option value="normal">عادي</option>
                <option value="low">منخفض</option>
              </select>

              <select
                value={selectedStaffFilter}
                onChange={(e) => setSelectedStaffFilter(e.target.value)}
                className="bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs rounded-lg px-2.5 py-1.5 text-slate-700 dark:text-slate-300 focus:outline-none"
              >
                <option value="all">كل الموظفين</option>
                {activeEmployees.map((s) => (
                  <option key={s.id} value={s.name}>
                    {s.name} ({s.roleTitleAr})
                  </option>
                ))}
              </select>
            </div>

            <span className="text-xs text-slate-400 font-mono">
              {filteredTasks.length} مهام نشطة
            </span>
          </div>

          {/* Housekeeping Tasks Cards */}
          {filteredTasks.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-dashed border-slate-300 dark:border-slate-800 rounded-xl p-12 text-center space-y-2">
              <ShieldCheck className="w-10 h-10 text-emerald-500 mx-auto" />
              <h3 className="font-semibold text-slate-800 dark:text-slate-200 text-sm">
                لا توجد مهام هاوس كيبينج معلقة حالياً!
              </h3>
              <p className="text-xs text-slate-500">
                كافة الغرف نظيفة ومتاحة للحجز، ويمكنك استعراض 'قائمة المهام اليومية' لتوزيع العمل الروتيني على الموظفين.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredTasks.map((task) => {
                const statusInfo = getStatusBadge(task.status);
                const checklistCount = Object.values(task.checklist).filter(Boolean).length;

                return (
                  <div
                    key={task.id}
                    className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-4 shadow-sm hover:shadow-md transition space-y-3.5 flex flex-col justify-between"
                  >
                    <div>
                      {/* Top Row: Room Number, Priority, Status */}
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-600 dark:text-amber-400 font-bold flex items-center justify-center text-sm font-mono">
                            #{task.roomNumber}
                          </div>
                          <div>
                            <h3 className="font-bold text-slate-900 dark:text-white text-sm">
                              غرفة {task.roomNumber}
                            </h3>
                            <span className="text-[11px] text-slate-400">
                              وقت الإبلاغ: {task.reportedAt}
                            </span>
                          </div>
                        </div>

                        <div className="flex flex-col items-end gap-1">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getPriorityBadge(
                              task.priority
                            )}`}
                          >
                            {task.priority === 'urgent'
                              ? '🔥 أولوية عاجلة'
                              : task.priority === 'normal'
                              ? 'أولوية عادية'
                              : 'أولوية منخفضة'}
                          </span>
                          <span className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${statusInfo.color}`}>
                            {statusInfo.label}
                          </span>
                        </div>
                      </div>

                      {/* Staff Assignment Selector from Stored Employees List */}
                      <div className="mt-3 flex items-center justify-between text-xs bg-slate-50 dark:bg-slate-800/40 p-2 rounded-xl border border-slate-100 dark:border-slate-800">
                        <span className="text-slate-500 flex items-center gap-1.5">
                          <User className="w-3.5 h-3.5 text-slate-400" />
                          المسؤول:
                        </span>
                        <select
                          value={task.assignedTo}
                          onChange={(e) => assignHousekeeper(task.id, e.target.value)}
                          className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-xs rounded px-2 py-0.5 text-slate-800 dark:text-slate-200 text-right font-semibold focus:outline-none"
                        >
                          {activeEmployees.map((emp) => (
                            <option key={emp.id} value={emp.name}>
                              {emp.name} ({emp.roleTitleAr})
                            </option>
                          ))}
                        </select>
                      </div>

                      {/* Cleaning Checklist Interactive */}
                      <div className="mt-3 space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-slate-700 dark:text-slate-300">
                            قائمة فحص النظافة والتعقيم:
                          </span>
                          <span className="text-[11px] font-mono text-emerald-600 dark:text-emerald-400 font-bold">
                            {checklistCount} / 5
                          </span>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full bg-slate-100 dark:bg-slate-800 h-1.5 rounded-full overflow-hidden">
                          <div
                            className="bg-emerald-500 h-full transition-all duration-300"
                            style={{ width: `${(checklistCount / 5) * 100}%` }}
                          />
                        </div>

                        <div className="space-y-1.5 pt-1 text-xs text-slate-700 dark:text-slate-300">
                          <label
                            onClick={() => toggleHousekeepingChecklist(task.id, 'linensChanged')}
                            className="flex items-center gap-2 cursor-pointer select-none hover:text-emerald-600"
                          >
                            {task.checklist.linensChanged ? (
                              <CheckSquare className="w-4 h-4 text-emerald-500 shrink-0" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-400 shrink-0" />
                            )}
                            <span>تغيير المفارش والشراشف والوسائد</span>
                          </label>

                          <label
                            onClick={() => toggleHousekeepingChecklist(task.id, 'bathroomCleaned')}
                            className="flex items-center gap-2 cursor-pointer select-none hover:text-emerald-600"
                          >
                            {task.checklist.bathroomCleaned ? (
                              <CheckSquare className="w-4 h-4 text-emerald-500 shrink-0" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-400 shrink-0" />
                            )}
                            <span>تنظيف وتطهير الحمام وتجهيز المناشف</span>
                          </label>

                          <label
                            onClick={() => toggleHousekeepingChecklist(task.id, 'roomDisinfected')}
                            className="flex items-center gap-2 cursor-pointer select-none hover:text-emerald-600"
                          >
                            {task.checklist.roomDisinfected ? (
                              <CheckSquare className="w-4 h-4 text-emerald-500 shrink-0" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-400 shrink-0" />
                            )}
                            <span>تعقيم الأسطح والمقابض ورش المعطر</span>
                          </label>

                          <label
                            onClick={() => toggleHousekeepingChecklist(task.id, 'amenitiesRestocked')}
                            className="flex items-center gap-2 cursor-pointer select-none hover:text-emerald-600"
                          >
                            {task.checklist.amenitiesRestocked ? (
                              <CheckSquare className="w-4 h-4 text-emerald-500 shrink-0" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-400 shrink-0" />
                            )}
                            <span>إعادة تعبئة الميني بار والشاي والماء</span>
                          </label>

                          <label
                            onClick={() => toggleHousekeepingChecklist(task.id, 'floorCleaned')}
                            className="flex items-center gap-2 cursor-pointer select-none hover:text-emerald-600"
                          >
                            {task.checklist.floorCleaned ? (
                              <CheckSquare className="w-4 h-4 text-emerald-500 shrink-0" />
                            ) : (
                              <Square className="w-4 h-4 text-slate-400 shrink-0" />
                            )}
                            <span>كنس ومسح الأرضيات والسجاد</span>
                          </label>
                        </div>
                      </div>

                      {/* Notes */}
                      {task.notes && (
                        <div className="mt-2 text-[11px] text-slate-500 italic bg-amber-50/50 dark:bg-amber-950/20 p-2 rounded-lg border border-amber-200/50 dark:border-amber-900/30">
                          💬 {task.notes}
                        </div>
                      )}
                    </div>

                    {/* Bottom Action Button */}
                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
                      <button
                        onClick={() => completeHousekeeping(task.roomId)}
                        className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 shadow-sm cursor-pointer"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>تم اكتمال التنظيف (إعادة الغرفة للمتاح 🟢)</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
