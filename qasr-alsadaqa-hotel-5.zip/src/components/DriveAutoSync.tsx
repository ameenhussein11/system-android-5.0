import React, { useCallback, useEffect, useRef } from 'react';
import { useHotel } from '../context/HotelContext';
import { isDriveLinked, loadDriveConfig, saveDriveConfig, syncToDrive } from '../utils/googleDrive';
import { localDateTimeSec } from '../utils/dates';

const DEBOUNCE_MS = 90_000; // wait for 90s of quiet after the last change
export const DRIVE_SYNC_NOW_EVENT = 'qasr-drive-sync-now';

/** Headless component: keeps Google Drive up to date automatically while the app is open. */
export const DriveAutoSync: React.FC = () => {
  const h = useHotel();
  const hRef = useRef(h);
  hRef.current = h;
  const running = useRef(false);
  const timer = useRef<number | undefined>(undefined);

  const run = useCallback(async () => {
    const cfg = loadDriveConfig();
    if (running.current || !isDriveLinked(cfg) || !navigator.onLine) return;
    running.current = true;
    window.dispatchEvent(new CustomEvent('qasr-drive-busy', { detail: true }));
    try {
      const d = hRef.current;
      const data = {
        meta: { app: 'qasr-alsadaqa', hotel: d.settings.hotelName, exportedAt: localDateTimeSec() },
        settings: d.settings,
        rooms: d.rooms,
        guests: d.guests,
        bookings: d.bookings,
        housekeeping: d.housekeeping,
        payments: d.payments,
        logs: d.logs,
        roomServiceMenu: d.roomServiceMenu,
        roomServiceOrders: d.roomServiceOrders,
        extras: {
          staffMembers: d.staffMembers,
          staffSalaries: d.staffSalaries,
          expenses: d.expenses,
          otherRevenues: d.otherRevenues,
          reservations: d.reservations,
          closings: d.closings,
        },
      };
      const q = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
      const logsCsv =
        '\uFEFF' +
        ['الوقت,الإجراء,التفاصيل,التصنيف', ...d.logs.map((l) => [l.timestamp, l.action, l.details, l.category].map(q).join(','))].join('\n');
      await syncToDrive(JSON.stringify(data), logsCsv);
    } catch (err) {
      saveDriveConfig({ lastError: err instanceof Error ? err.message : 'فشلت المزامنة.' });
    } finally {
      running.current = false;
      window.dispatchEvent(new CustomEvent('qasr-drive-busy', { detail: false }));
    }
  }, []);

  // manual "sync now" and reconnect events
  useEffect(() => {
    const onNow = () => run();
    window.addEventListener(DRIVE_SYNC_NOW_EVENT, onNow);
    window.addEventListener('online', onNow);
    const first = window.setTimeout(() => {
      if (loadDriveConfig().autoSync) run();
    }, 8000);
    return () => {
      window.removeEventListener(DRIVE_SYNC_NOW_EVENT, onNow);
      window.removeEventListener('online', onNow);
      window.clearTimeout(first);
    };
  }, [run]);

  // debounce: sync shortly after the data stops changing
  useEffect(() => {
    if (!loadDriveConfig().autoSync || !isDriveLinked()) return;
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => run(), DEBOUNCE_MS);
    return () => window.clearTimeout(timer.current);
  }, [
    h.rooms, h.guests, h.bookings, h.housekeeping, h.payments, h.logs, h.settings,
    h.roomServiceMenu, h.roomServiceOrders, h.staffMembers, h.staffSalaries,
    h.expenses, h.otherRevenues, h.reservations, run,
  ]);

  return null;
};
