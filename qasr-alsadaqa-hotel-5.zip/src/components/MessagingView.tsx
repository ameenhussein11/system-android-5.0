import React, { useEffect, useMemo, useState } from 'react';
import { MessageSquare, Search, Send, SkipForward, Trash2, History, Users, CheckCircle2 } from 'lucide-react';
import { useHotel } from '../context/HotelContext';
import { SMS_TEMPLATES, fillTemplate, openSms, cleanPhone } from '../utils/sms';
import { Card, inputCls } from './archive/shared';
import type { Guest } from '../types/hotel';

type Filter = 'all' | 'in_house' | 'owing' | 'vip';
const FILTERS: { id: Filter; label: string }[] = [
  { id: 'all', label: 'الكل' },
  { id: 'in_house', label: 'مقيمون الآن' },
  { id: 'owing', label: 'عليهم رصيد' },
  { id: 'vip', label: 'VIP' },
];

/** SMS list: pick customers, pick/edit a template, then the phone's SMS app opens with the text ready. */
export const MessagingView: React.FC = () => {
  const { guests, bookings, settings, smsLog, logSms, clearSmsLog, smsDraft, setSmsDraft } = useHotel();
  const [tab, setTab] = useState<'compose' | 'history'>('compose');
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [selected, setSelected] = useState<number[]>([]);
  const [templateId, setTemplateId] = useState('payment_reminder');
  const [text, setText] = useState(SMS_TEMPLATES[0].text);
  const [extraVars, setExtraVars] = useState<Record<string, string>>({});
  const [queue, setQueue] = useState<Guest[]>([]);
  const [qi, setQi] = useState(0);

  const info = useMemo(() => {
    const map = new Map<number, { room?: string; owing: number }>();
    for (const g of guests) map.set(g.id, { owing: 0 });
    for (const b of bookings) {
      const row = map.get(b.guestId);
      if (!row) continue;
      if (b.isActive) {
        row.room = b.roomNumber;
        row.owing += Math.max(0, b.totalAmount - b.paidAmount);
      }
    }
    return map;
  }, [guests, bookings]);

  // a draft sent from another screen (room, guest card, custody…)
  useEffect(() => {
    if (!smsDraft) return;
    if (smsDraft.guestId) setSelected([smsDraft.guestId]);
    const t = SMS_TEMPLATES.find((x) => x.id === smsDraft.templateId);
    if (t) setTemplateId(t.id);
    setText(smsDraft.text ?? t?.text ?? '');
    setExtraVars(smsDraft.vars || {});
    setTab('compose');
    setSmsDraft(null);
  }, [smsDraft, setSmsDraft]);

  const list = useMemo(() => {
    const term = q.trim();
    return guests
      .filter((g) => !!cleanPhone(g.phone))
      .filter((g) => (term ? g.name.includes(term) || g.phone.includes(term) : true))
      .filter((g) => {
        const i = info.get(g.id);
        if (filter === 'in_house') return !!i?.room;
        if (filter === 'owing') return (i?.owing || 0) > 0;
        if (filter === 'vip') return !!g.isVip;
        return true;
      });
  }, [guests, q, filter, info]);

  const varsFor = (g: Guest): Record<string, string> => {
    const i = info.get(g.id);
    return {
      الاسم: g.name,
      الفندق: settings.hotelName,
      الغرفة: i?.room || '—',
      المبلغ: String(i?.owing || 0),
      العملة: settings.currencySymbol,
      ...extraVars,
    };
  };
  const preview = (g: Guest) => fillTemplate(text, varsFor(g));

  const toggle = (id: number) => setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]));
  const pickTemplate = (id: string) => {
    setTemplateId(id);
    setText(SMS_TEMPLATES.find((t) => t.id === id)?.text ?? '');
  };

  const start = () => {
    const chosen = guests.filter((g) => selected.includes(g.id));
    if (chosen.length === 0) return alert('اختر عميلاً واحداً على الأقل.');
    if (!text.trim()) return alert('اكتب نص الرسالة.');
    setQueue(chosen);
    setQi(0);
  };

  const current = queue[qi];
  const sendCurrent = () => {
    if (!current) return;
    const body = preview(current);
    logSms({ guestId: current.id, name: current.name, phone: current.phone, text: body, kind: templateId });
    openSms(current.phone, body);
  };
  const next = () => {
    if (qi + 1 >= queue.length) {
      setQueue([]);
      setSelected([]);
    } else setQi(qi + 1);
  };

  return (
    <div className="space-y-4 animate-fadeIn pb-8" dir="rtl">
      <div>
        <h2 className="font-bold text-lg text-slate-900 dark:text-white flex items-center gap-2">
          <MessageSquare className="w-5 h-5 text-sky-500" /> مراسلة العملاء (SMS)
        </h2>
        <p className="text-xs text-slate-500 dark:text-slate-400">
          يفتح التطبيق رسائل هاتفك ونص الرسالة جاهز، وتضغط إرسال من شريحتك (SIM). كل رسالة تُسجَّل هنا.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-1.5 bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl">
        {([['compose', 'إنشاء رسالة', Users], ['history', `السجل (${smsLog.length})`, History]] as const).map(([id, label, Icon]) => (
          <button
            key={id}
            onClick={() => setTab(id)}
            className={`flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-bold cursor-pointer ${tab === id ? 'bg-white dark:bg-slate-900 text-sky-700 dark:text-sky-300 shadow-sm' : 'text-slate-500'}`}
          >
            <Icon className="w-4 h-4" /> {label}
          </button>
        ))}
      </div>

      {tab === 'compose' && !current && (
        <>
          <Card title="1) اختر المستلمين">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-3" />
              <input className={`${inputCls} pr-9`} placeholder="بحث بالاسم أو الجوال" value={q} onChange={(e) => setQ(e.target.value)} />
            </div>
            <div className="flex flex-wrap gap-1.5">
              {FILTERS.map((f) => (
                <button
                  key={f.id}
                  onClick={() => setFilter(f.id)}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold cursor-pointer ${filter === f.id ? 'bg-sky-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}`}
                >
                  {f.label}
                </button>
              ))}
              <button onClick={() => setSelected(list.map((g) => g.id))} className="px-3 py-1.5 rounded-full text-xs font-semibold bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 cursor-pointer">
                تحديد الكل ({list.length})
              </button>
              {selected.length > 0 && (
                <button onClick={() => setSelected([])} className="px-3 py-1.5 rounded-full text-xs font-semibold bg-rose-50 dark:bg-rose-950/40 text-rose-600 cursor-pointer">
                  إلغاء التحديد
                </button>
              )}
            </div>
            <div className="max-h-64 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-xl">
              {list.length === 0 && <p className="text-center text-xs text-slate-400 py-6">لا يوجد عملاء لديهم رقم جوال مطابق.</p>}
              {list.map((g) => {
                const i = info.get(g.id);
                return (
                  <label key={g.id} className="flex items-center gap-3 p-2.5 cursor-pointer hover:bg-slate-50 dark:hover:bg-slate-800/50">
                    <input type="checkbox" checked={selected.includes(g.id)} onChange={() => toggle(g.id)} className="w-4 h-4 shrink-0" />
                    <span className="min-w-0 flex-1">
                      <span className="block text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{g.name}</span>
                      <span className="block text-[11px] text-slate-500 truncate" dir="ltr" style={{ textAlign: 'right' }}>
                        {g.phone}
                        {i?.room ? ` • غرفة ${i.room}` : ''}
                      </span>
                    </span>
                    {(i?.owing || 0) > 0 && (
                      <span className="text-[11px] font-bold text-rose-600 shrink-0">
                        {i!.owing} {settings.currencySymbol}
                      </span>
                    )}
                  </label>
                );
              })}
            </div>
          </Card>

          <Card title="2) الرسالة">
            <div className="flex flex-wrap gap-1.5">
              {SMS_TEMPLATES.map((t) => (
                <button
                  key={t.id}
                  onClick={() => pickTemplate(t.id)}
                  className={`px-3 py-1.5 rounded-full text-xs font-semibold cursor-pointer ${templateId === t.id ? 'bg-sky-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300'}`}
                >
                  {t.label}
                </button>
              ))}
            </div>
            <textarea className={`${inputCls} min-h-[110px]`} value={text} onChange={(e) => setText(e.target.value)} placeholder="اكتب نص الرسالة…" />
            <p className="text-[11px] text-slate-400">
              المتغيرات: {'{الاسم} {الفندق} {الغرفة} {المبلغ} {العملة}'} تُستبدل تلقائياً لكل عميل.
            </p>
            {selected.length > 0 && guests.find((g) => g.id === selected[0]) && (
              <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 p-3 text-xs text-slate-700 dark:text-slate-200 whitespace-pre-wrap">
                <div className="text-[10px] text-slate-400 mb-1">معاينة ({guests.find((g) => g.id === selected[0])!.name}):</div>
                {preview(guests.find((g) => g.id === selected[0])!)}
              </div>
            )}
            <button onClick={start} className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm cursor-pointer">
              <Send className="w-4 h-4" /> ابدأ الإرسال ({selected.length})
            </button>
          </Card>
        </>
      )}

      {tab === 'compose' && current && (
        <Card title={`الإرسال ${qi + 1} من ${queue.length}`}>
          <div className="text-sm font-bold text-slate-800 dark:text-slate-100">{current.name}</div>
          <div className="text-xs text-slate-500" dir="ltr" style={{ textAlign: 'right' }}>{current.phone}</div>
          <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 p-3 text-sm whitespace-pre-wrap">{preview(current)}</div>
          <div className="grid grid-cols-2 gap-2">
            <button onClick={sendCurrent} className="flex items-center justify-center gap-1.5 py-3 rounded-xl bg-emerald-600 text-white font-bold text-sm cursor-pointer">
              <Send className="w-4 h-4" /> فتح الرسائل
            </button>
            <button onClick={next} className="flex items-center justify-center gap-1.5 py-3 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 font-bold text-sm cursor-pointer">
              <SkipForward className="w-4 h-4" /> {qi + 1 >= queue.length ? 'إنهاء' : 'التالي'}
            </button>
          </div>
          <button onClick={() => setQueue([])} className="w-full text-xs text-slate-400 underline cursor-pointer">إلغاء القائمة</button>
        </Card>
      )}

      {tab === 'history' && (
        <Card title="سجل الرسائل المُجهَّزة">
          {smsLog.length === 0 ? (
            <p className="text-center text-xs text-slate-400 py-6">لا توجد رسائل بعد.</p>
          ) : (
            <>
              <div className="space-y-2">
                {smsLog.slice(0, 200).map((m) => (
                  <div key={m.id} className="border border-slate-200 dark:border-slate-800 rounded-xl p-3 space-y-1">
                    <div className="flex items-center justify-between gap-2 text-xs">
                      <span className="font-bold text-slate-800 dark:text-slate-100 truncate">{m.name}</span>
                      <span className="text-[10px] text-slate-400 shrink-0">{m.at}</span>
                    </div>
                    <div className="text-xs text-slate-600 dark:text-slate-300 whitespace-pre-wrap">{m.text}</div>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] text-slate-400 flex items-center gap-1"><CheckCircle2 className="w-3 h-3" /> بواسطة {m.by}</span>
                      <button onClick={() => openSms(m.phone, m.text)} className="text-[11px] font-semibold text-sky-600 cursor-pointer">إعادة الإرسال</button>
                    </div>
                  </div>
                ))}
              </div>
              <button
                onClick={() => confirm('مسح سجل الرسائل بالكامل؟') && clearSmsLog()}
                className="flex items-center gap-1.5 text-xs font-semibold text-rose-600 cursor-pointer"
              >
                <Trash2 className="w-4 h-4" /> مسح السجل
              </button>
            </>
          )}
        </Card>
      )}
    </div>
  );
};
