import React, { useState, useMemo, useEffect } from 'react';
import { useHotel } from '../context/HotelContext';
import {
  X,
  Plus,
  Minus,
  UtensilsCrossed,
  Coffee,
  ShoppingBag,
  Sparkles,
  Search,
  CheckCircle2,
  Clock,
  Shirt,
  Bed,
  FileText,
  CreditCard,
  Banknote,
  Gift,
  AlertCircle,
  ChefHat,
  Trash2,
} from 'lucide-react';
import {
  RoomServiceCategory,
  RoomServiceItem,
  RoomServiceOrderItem,
  RoomServiceChargeTo,
} from '../types/hotel';

interface CartEntry {
  item: RoomServiceItem;
  quantity: number;
  notes: string;
}

export const NewRoomServiceOrderModal: React.FC = () => {
  const {
    rooms,
    bookings,
    settings,
    roomServiceMenu,
    isNewRoomServiceModalOpen,
    setIsNewRoomServiceModalOpen,
    preselectedRoomForRoomService,
    setPreselectedRoomForRoomService,
    createRoomServiceOrder,
  } = useHotel();

  // Selected Room
  const occupiedRooms = useMemo(() => rooms.filter((r) => r.status === 'occupied'), [rooms]);
  const [selectedRoomId, setSelectedRoomId] = useState<number>(0);

  // Cart state
  const [cart, setCart] = useState<Record<number, CartEntry>>({});

  // Menu filter
  const [selectedCategory, setSelectedCategory] = useState<RoomServiceCategory | 'all'>('all');
  const [searchFilter, setSearchFilter] = useState('');

  // Order Details
  const [chargeTo, setChargeTo] = useState<RoomServiceChargeTo>('room_bill');
  const [orderNotes, setOrderNotes] = useState('');
  const [assignedStaff, setAssignedStaff] = useState('فريق خدمة الغرف والمطبخ');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Initialize room when modal opens or preselected room changes
  useEffect(() => {
    if (isNewRoomServiceModalOpen) {
      if (preselectedRoomForRoomService) {
        setSelectedRoomId(preselectedRoomForRoomService.id);
      } else if (occupiedRooms.length > 0) {
        setSelectedRoomId(occupiedRooms[0].id);
      }
      setCart({});
      setOrderNotes('');
      setErrorMessage('');
    }
  }, [isNewRoomServiceModalOpen, preselectedRoomForRoomService, occupiedRooms]);

  if (!isNewRoomServiceModalOpen) return null;

  const currentRoom = rooms.find((r) => r.id === selectedRoomId);
  const activeBooking = bookings.find((b) => b.roomId === selectedRoomId && b.isActive);

  // Filtered menu items
  const filteredMenuItems = roomServiceMenu.filter((item) => {
    if (selectedCategory !== 'all' && item.category !== selectedCategory) return false;
    if (searchFilter.trim()) {
      const q = searchFilter.toLowerCase();
      const matchName = item.name.toLowerCase().includes(q);
      const matchNameEn = item.nameEn?.toLowerCase().includes(q);
      const matchDesc = item.description?.toLowerCase().includes(q);
      if (!matchName && !matchNameEn && !matchDesc) return false;
    }
    return true;
  });

  // Cart Calculations
  const cartItemsList: CartEntry[] = useMemo(() => {
    const list = Object.values(cart) as CartEntry[];
    return list.filter((entry) => entry && entry.quantity > 0);
  }, [cart]);

  const subtotal: number = useMemo(() => {
    return cartItemsList.reduce(
      (sum: number, entry: CartEntry) => sum + entry.item.price * entry.quantity,
      0
    );
  }, [cartItemsList]);

  const tax: number = chargeTo === 'complimentary' ? 0 : (subtotal * (settings.taxRatePercent || 15)) / 100;
  const totalAmount: number = chargeTo === 'complimentary' ? 0 : subtotal + tax;

  const handleAddToCart = (item: RoomServiceItem) => {
    setCart((prev) => {
      const existing = prev[item.id];
      if (existing) {
        return {
          ...prev,
          [item.id]: { ...existing, quantity: existing.quantity + 1 },
        };
      }
      return {
        ...prev,
        [item.id]: { item, quantity: 1, notes: '' },
      };
    });
  };

  const handleDecreaseQuantity = (itemId: number) => {
    setCart((prev) => {
      const existing = prev[itemId];
      if (!existing) return prev;
      if (existing.quantity <= 1) {
        const copy = { ...prev };
        delete copy[itemId];
        return copy;
      }
      return {
        ...prev,
        [itemId]: { ...existing, quantity: existing.quantity - 1 },
      };
    });
  };

  const handleRemoveFromCart = (itemId: number) => {
    setCart((prev) => {
      const copy = { ...prev };
      delete copy[itemId];
      return copy;
    });
  };

  const handleSubmitOrder = () => {
    if (!currentRoom) {
      setErrorMessage('يرجى اختيار الغرفة المستهدفة للطلب');
      return;
    }

    if (cartItemsList.length === 0) {
      setErrorMessage('يرجى إضافة صنف واحد على الأقل إلى سلة الطلب');
      return;
    }

    setIsSubmitting(true);
    setErrorMessage('');

    const formattedItems: RoomServiceOrderItem[] = cartItemsList.map((c) => ({
      itemId: c.item.id,
      name: c.item.name,
      price: c.item.price,
      quantity: c.quantity,
      notes: c.notes.trim() || undefined,
    }));

    const res = createRoomServiceOrder({
      roomId: currentRoom.id,
      roomNumber: currentRoom.roomNumber,
      bookingId: activeBooking?.id || currentRoom.currentBookingId || null,
      guestId: activeBooking?.guestId || null,
      guestName: currentRoom.currentGuestName || activeBooking?.guestName || 'نزيل الغرفة',
      guestPhone: currentRoom.currentGuestPhone || activeBooking?.guestPhone || undefined,
      items: formattedItems,
      subtotal,
      tax,
      totalAmount,
      chargeTo,
      isPaid: chargeTo === 'complimentary',
      status: 'pending',
      notes: orderNotes.trim() || undefined,
      assignedStaff: assignedStaff.trim() || 'فريق خدمة الغرف',
    });

    setIsSubmitting(false);

    if (res.success && res.order) {
      setIsNewRoomServiceModalOpen(false);
      setPreselectedRoomForRoomService(null);
    } else {
      setErrorMessage(res.error || 'فشل في إنشاء الطلب');
    }
  };

  const categories = [
    { id: 'all', label: 'الكل', icon: Sparkles },
    { id: 'breakfast', label: 'الفطور', icon: UtensilsCrossed },
    { id: 'meals', label: 'وجبات رئيسية', icon: UtensilsCrossed },
    { id: 'beverages', label: 'مشروبات وقهوة', icon: Coffee },
    { id: 'desserts_snacks', label: 'حلويات وسناكات', icon: ShoppingBag },
    { id: 'laundry', label: 'مغسلة وكوي', icon: Shirt },
    { id: 'amenities', label: 'مرافق ولوازم', icon: Bed },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-5xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 px-5 py-3.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <ChefHat className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                <span>طلب خدمة غرف جديد (New Room Service Order)</span>
              </h2>
              <p className="text-xs text-slate-400">
                تسجيل طلب طعام، مشروبات، أو خدمات غسيل وإضافتها للفاتورة أو دفع فوري
              </p>
            </div>
          </div>
          <button
            onClick={() => {
              setIsNewRoomServiceModalOpen(false);
              setPreselectedRoomForRoomService(null);
            }}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body: Two Columns (Left Menu & Right Cart/Details) */}
        <div className="grid grid-cols-1 lg:grid-cols-12 flex-1 overflow-hidden">
          {/* Left Column: Menu Catalog (7 cols) */}
          <div className="lg:col-span-7 border-b lg:border-b-0 lg:border-l border-slate-800 flex flex-col overflow-hidden bg-slate-950/40 p-4">
            {/* Room Selector Bar */}
            <div className="bg-slate-800/80 border border-slate-700/60 rounded-xl p-3 mb-3">
              <label className="block text-xs font-semibold text-slate-300 mb-1.5 flex items-center justify-between">
                <span>اختر الغرفة والنزيل المستهدف:</span>
                {currentRoom?.currentGuestName && (
                  <span className="text-emerald-400 text-[11px] font-normal">
                    النزيل: {currentRoom.currentGuestName}
                  </span>
                )}
              </label>
              <select
                value={selectedRoomId}
                onChange={(e) => setSelectedRoomId(Number(e.target.value))}
                className="w-full bg-slate-900 border border-slate-700 text-white rounded-lg px-3 py-2 text-sm focus:outline-none focus:border-amber-500"
              >
                {occupiedRooms.length === 0 ? (
                  <option value="0">لا توجد غرف مشغولة حالياً</option>
                ) : (
                  occupiedRooms.map((r) => (
                    <option key={r.id} value={r.id}>
                      غرفة {r.roomNumber} (طابق {r.floor}) - {r.currentGuestName || 'مشغولة'}
                    </option>
                  ))
                )}
              </select>
            </div>

            {/* Category Filter Pills & Search */}
            <div className="flex items-center gap-2 mb-3">
              <div className="relative flex-1">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-2.5" />
                <input
                  type="text"
                  value={searchFilter}
                  onChange={(e) => setSearchFilter(e.target.value)}
                  placeholder="بحث في قائمة الطعام والخدمات..."
                  className="w-full bg-slate-900 border border-slate-800 rounded-lg pr-9 pl-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            {/* Categories Scrollable Tabs */}
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-2 mb-3">
              {categories.map((cat) => {
                const Icon = cat.icon;
                const isSelected = selectedCategory === cat.id;
                return (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id as any)}
                    className={`px-2.5 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap transition cursor-pointer flex items-center gap-1.5 ${
                      isSelected
                        ? 'bg-amber-500 text-slate-950 font-bold shadow-sm'
                        : 'bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800'
                    }`}
                  >
                    <Icon className="w-3 h-3" />
                    <span>{cat.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Menu Items Grid */}
            <div className="flex-1 overflow-y-auto pr-1 space-y-2 max-h-[380px] lg:max-h-none">
              {filteredMenuItems.length === 0 ? (
                <div className="text-center py-10 bg-slate-900/40 rounded-xl border border-slate-800 text-slate-400">
                  <UtensilsCrossed className="w-8 h-8 mx-auto text-slate-600 mb-2" />
                  <p className="text-xs">لم يتم العثور على أصناف مطابقة للبحث</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                  {filteredMenuItems.map((item) => {
                    const cartEntry = cart[item.id];
                    const qty = cartEntry?.quantity || 0;
                    return (
                      <div
                        key={item.id}
                        className={`bg-slate-900 border rounded-xl p-3 transition flex flex-col justify-between ${
                          qty > 0
                            ? 'border-amber-500/60 bg-amber-500/5 ring-1 ring-amber-500/20'
                            : 'border-slate-800 hover:border-slate-700'
                        } ${!item.isAvailable ? 'opacity-60 grayscale' : ''}`}
                      >
                        <div>
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <div className="flex items-center gap-2">
                              <span className="text-xl shrink-0">
                                {item.imageIcon || '🍽️'}
                              </span>
                              <div>
                                <h4 className="text-xs sm:text-sm font-bold text-white leading-tight">
                                  {item.name}
                                </h4>
                                {item.nameEn && (
                                  <span className="text-[10px] text-slate-400 block font-mono">
                                    {item.nameEn}
                                  </span>
                                )}
                              </div>
                            </div>
                            <span className="font-bold text-xs sm:text-sm text-emerald-400 shrink-0 font-mono bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                              {item.price} {settings.currency}
                            </span>
                          </div>

                          {item.description && (
                            <p className="text-[11px] text-slate-400 line-clamp-2 mt-1">
                              {item.description}
                            </p>
                          )}
                        </div>

                        <div className="flex items-center justify-between pt-2.5 mt-2 border-t border-slate-800/80">
                          {item.prepTimeMinutes ? (
                            <span className="text-[10px] text-slate-400 flex items-center gap-1">
                              <Clock className="w-2.5 h-2.5 text-amber-400" />
                              <span>{item.prepTimeMinutes} دقيقة</span>
                            </span>
                          ) : (
                            <span />
                          )}

                          {item.isAvailable ? (
                            qty > 0 ? (
                              <div className="flex items-center gap-2 bg-slate-950 px-2 py-1 rounded-lg border border-slate-700">
                                <button
                                  type="button"
                                  onClick={() => handleDecreaseQuantity(item.id)}
                                  className="w-6 h-6 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 flex items-center justify-center cursor-pointer"
                                >
                                  <Minus className="w-3 h-3" />
                                </button>
                                <span className="text-xs font-bold text-amber-400 font-mono w-4 text-center">
                                  {qty}
                                </span>
                                <button
                                  type="button"
                                  onClick={() => handleAddToCart(item)}
                                  className="w-6 h-6 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 flex items-center justify-center cursor-pointer font-bold"
                                >
                                  <Plus className="w-3 h-3" />
                                </button>
                              </div>
                            ) : (
                              <button
                                type="button"
                                onClick={() => handleAddToCart(item)}
                                className="px-3 py-1 rounded-lg bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-slate-200 text-xs font-medium transition cursor-pointer flex items-center gap-1 border border-slate-700 hover:border-amber-500"
                              >
                                <Plus className="w-3 h-3" />
                                <span>إضافة للطلب</span>
                              </button>
                            )
                          ) : (
                            <span className="text-[10px] text-rose-400 bg-rose-500/10 px-2 py-0.5 rounded border border-rose-500/20">
                              غير متوفر حالياً
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Right Column: Order Cart & Checkout Form (5 cols) */}
          <div className="lg:col-span-5 p-4 flex flex-col justify-between bg-slate-900 overflow-y-auto">
            <div>
              <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-4 h-4 text-amber-400" />
                  <h3 className="font-bold text-sm text-white">
                    سلة الطلب ({cartItemsList.length} أصناف)
                  </h3>
                </div>
                {cartItemsList.length > 0 && (
                  <button
                    onClick={() => setCart({})}
                    className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1 cursor-pointer"
                  >
                    <Trash2 className="w-3 h-3" />
                    <span>تفريغ السلة</span>
                  </button>
                )}
              </div>

              {/* Cart Items List */}
              {cartItemsList.length === 0 ? (
                <div className="text-center py-8 bg-slate-950/60 rounded-xl border border-slate-800/80 mb-4">
                  <ShoppingBag className="w-8 h-8 mx-auto text-slate-600 mb-2 opacity-50" />
                  <p className="text-xs text-slate-400 font-medium">السلة فارغة حالياً</p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    اختر الأصناف والخدمات من القائمة يساراً لإضافتها
                  </p>
                </div>
              ) : (
                <div className="space-y-2 mb-4 max-h-48 overflow-y-auto pr-1">
                  {cartItemsList.map(({ item, quantity, notes }) => (
                    <div
                      key={item.id}
                      className="bg-slate-950/70 border border-slate-800 rounded-lg p-2.5 flex flex-col gap-1.5"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-2 overflow-hidden">
                          <span className="text-sm shrink-0">{item.imageIcon || '🍽️'}</span>
                          <span className="text-xs font-semibold text-slate-200 truncate">
                            {item.name}
                          </span>
                        </div>
                        <div className="flex items-center gap-2 shrink-0">
                          <span className="text-xs font-mono font-bold text-emerald-400">
                            {(item.price * quantity).toFixed(2)} {settings.currency}
                          </span>
                          <button
                            onClick={() => handleRemoveFromCart(item.id)}
                            className="text-slate-500 hover:text-rose-400 cursor-pointer p-0.5"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        </div>
                      </div>

                      <div className="flex items-center justify-between gap-2">
                        {/* Notes input for this specific dish/service */}
                        <input
                          type="text"
                          value={notes}
                          onChange={(e) =>
                            setCart((prev) => ({
                              ...prev,
                              [item.id]: { ...prev[item.id], notes: e.target.value },
                            }))
                          }
                          placeholder="ملاحظات خاصة للصنف (مثال: بدون سكر، حار)..."
                          className="bg-slate-900 border border-slate-800 text-[10px] rounded px-2 py-1 text-slate-300 placeholder-slate-600 focus:outline-none focus:border-amber-500 flex-1"
                        />
                        <div className="flex items-center gap-1.5 shrink-0 bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                          <button
                            type="button"
                            onClick={() => handleDecreaseQuantity(item.id)}
                            className="text-slate-400 hover:text-white cursor-pointer"
                          >
                            <Minus className="w-2.5 h-2.5" />
                          </button>
                          <span className="text-xs font-bold text-slate-200 font-mono">
                            {quantity}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleAddToCart(item)}
                            className="text-amber-400 hover:text-amber-300 cursor-pointer"
                          >
                            <Plus className="w-2.5 h-2.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Billing Method Selection */}
              <div className="space-y-3 mb-4">
                <label className="block text-xs font-semibold text-slate-300">
                  طريقة احتساب ومحاسبة الطلب:
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setChargeTo('room_bill')}
                    className={`p-2 rounded-xl border text-right transition cursor-pointer flex flex-col gap-1 ${
                      chargeTo === 'room_bill'
                        ? 'bg-amber-500/15 border-amber-500 text-amber-300 font-semibold'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs">
                      <FileText className="w-3.5 h-3.5 text-amber-400" />
                      <span>فاتورة الغرفة</span>
                    </div>
                    <span className="text-[10px] text-slate-400">إضافة لحساب الحجز</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setChargeTo('card_on_delivery')}
                    className={`p-2 rounded-xl border text-right transition cursor-pointer flex flex-col gap-1 ${
                      chargeTo === 'card_on_delivery'
                        ? 'bg-amber-500/15 border-amber-500 text-amber-300 font-semibold'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs">
                      <CreditCard className="w-3.5 h-3.5 text-indigo-400" />
                      <span>مدى / بطاقة</span>
                    </div>
                    <span className="text-[10px] text-slate-400">دفع فوري عند التسليم</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setChargeTo('cash_on_delivery')}
                    className={`p-2 rounded-xl border text-right transition cursor-pointer flex flex-col gap-1 ${
                      chargeTo === 'cash_on_delivery'
                        ? 'bg-amber-500/15 border-amber-500 text-amber-300 font-semibold'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs">
                      <Banknote className="w-3.5 h-3.5 text-emerald-400" />
                      <span>كاش نقد</span>
                    </div>
                    <span className="text-[10px] text-slate-400">دفع نقدي عند التسليم</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setChargeTo('complimentary')}
                    className={`p-2 rounded-xl border text-right transition cursor-pointer flex flex-col gap-1 ${
                      chargeTo === 'complimentary'
                        ? 'bg-amber-500/15 border-amber-500 text-amber-300 font-semibold'
                        : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 text-xs">
                      <Gift className="w-3.5 h-3.5 text-rose-400" />
                      <span>ضيافة VIP</span>
                    </div>
                    <span className="text-[10px] text-slate-400">مجانية برسم الفندق</span>
                  </button>
                </div>
              </div>

              {/* Delivery Notes & Staff */}
              <div className="space-y-2 mb-4">
                <div>
                  <label className="block text-[11px] font-medium text-slate-400 mb-1">
                    ملاحظات التوصيل والطلب (اختياري):
                  </label>
                  <input
                    type="text"
                    value={orderNotes}
                    onChange={(e) => setOrderNotes(e.target.value)}
                    placeholder="مثال: توصيل الساعة 8:30 م، إحضار ملاعق إضافية..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder-slate-600 focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>

              {/* Price Breakdown Summary */}
              <div className="bg-slate-950 rounded-xl p-3 border border-slate-800 space-y-1.5 mb-4 text-xs font-mono">
                <div className="flex justify-between text-slate-400">
                  <span>المجموع الفرعي:</span>
                  <span>{subtotal.toFixed(2)} {settings.currency}</span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>ضريبة القيمة المضافة ({settings.taxRatePercent}%):</span>
                  <span>{tax.toFixed(2)} {settings.currency}</span>
                </div>
                <div className="flex justify-between text-white font-bold text-sm pt-2 border-t border-slate-800">
                  <span className="text-amber-400">الإجمالي النهائي:</span>
                  <span className="text-amber-400">
                    {totalAmount.toFixed(2)} {settings.currency}
                  </span>
                </div>
              </div>

              {errorMessage && (
                <div className="bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs p-2.5 rounded-lg mb-3 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}
            </div>

            {/* Footer Action Buttons */}
            <div className="pt-3 border-t border-slate-800 flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setIsNewRoomServiceModalOpen(false);
                  setPreselectedRoomForRoomService(null);
                }}
                className="flex-1 py-2.5 px-4 rounded-xl border border-slate-700 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs sm:text-sm font-medium transition cursor-pointer text-center"
              >
                إلغاء
              </button>
              <button
                type="button"
                onClick={handleSubmitOrder}
                disabled={isSubmitting || cartItemsList.length === 0}
                className="flex-2 py-2.5 px-4 rounded-xl bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-slate-950 font-bold text-xs sm:text-sm transition cursor-pointer shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>تأكيد وإرسال الطلب</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
