import { localDate } from '../utils/dates';
import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import {
  ArrowLeftRight,
  Plus,
  DollarSign,
  TrendingDown,
  TrendingUp,
  Users,
  CreditCard,
  Printer,
  Trash2,
  Calendar,
  Search,
  FileSpreadsheet,
  CheckCircle2,
  AlertCircle,
  Building,
  Wrench,
  Zap,
  ShoppingBag,
  Car,
  Briefcase,
  Coins,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';
import { ExpenseRecord, OtherRevenueRecord, StaffMember, StaffSalaryRecord } from '../types/hotel';

export const FinanceView: React.FC = () => {
  const {
    expenses,
    otherRevenues,
    staffMembers,
    staffSalaries,
    payments,
    settings,
    addExpense,
    findClosedPeriod,
    deleteExpense,
    addOtherRevenue,
    deleteOtherRevenue,
    recordSalaryPayment,
    addStaffMember,
    deleteStaffMember,
    generateSalarySlipPdf,
    currentUser,
  } = useHotel();

  const [activeFinanceTab, setActiveFinanceTab] = useState<'salaries' | 'expenses' | 'revenues' | 'register'>('salaries');
  const [searchTerm, setSearchTerm] = useState('');

  // Modals
  const [isNewSalaryModalOpen, setIsNewSalaryModalOpen] = useState(false);
  const [isNewExpenseModalOpen, setIsNewExpenseModalOpen] = useState(false);
  const [isNewRevenueModalOpen, setIsNewRevenueModalOpen] = useState(false);
  const [isNewStaffModalOpen, setIsNewStaffModalOpen] = useState(false);

  // Form states
  const [salaryForm, setSalaryForm] = useState({
    staffId: staffMembers[0]?.id || 1,
    month: '2026-08',
    bonus: 0,
    deductions: 0,
    paymentMethod: 'transfer' as 'cash' | 'transfer' | 'card',
    notes: '',
  });

  const [expenseForm, setExpenseForm] = useState({
    title: '',
    category: 'supplies' as ExpenseRecord['category'],
    amount: 0,
    paymentMethod: 'card' as ExpenseRecord['paymentMethod'],
    recipientName: '',
    invoiceNumber: '',
    notes: '',
  });

  const [revenueForm, setRevenueForm] = useState({
    title: '',
    category: 'hall_rental' as OtherRevenueRecord['category'],
    amount: 0,
    paymentMethod: 'card' as OtherRevenueRecord['paymentMethod'],
    customerName: '',
    roomNumber: '',
    notes: '',
  });

  const [staffForm, setStaffForm] = useState({
    name: '',
    username: '',
    role: 'receptionist' as StaffMember['role'],
    roleTitleAr: 'موظف استقبال',
    phone: '',
    nationalId: '',
    monthlySalary: 5000,
    joinDate: localDate(),
  });

  // Calculate Aggregates
  const totalRoomRevenue = payments.reduce((sum, p) => sum + p.amount, 0);
  const totalOtherRevenue = otherRevenues.reduce((sum, r) => sum + r.amount, 0);
  const totalRevenue = totalRoomRevenue + totalOtherRevenue;

  const totalSalariesPaid = staffSalaries.reduce((sum, s) => sum + s.netSalary, 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const totalExpensesWithSalaries = totalExpenses; // Salaries are logged in expenses
  const netProfit = totalRevenue - totalExpensesWithSalaries;

  // Cash in Drawer calculations
  const cashIn = payments.filter((p) => p.method === 'cash').reduce((sum, p) => sum + p.amount, 0) +
    otherRevenues.filter((r) => r.paymentMethod === 'cash').reduce((sum, r) => sum + r.amount, 0);
  const cashOut = expenses.filter((e) => e.paymentMethod === 'cash').reduce((sum, e) => sum + e.amount, 0);
  const cashBalance = cashIn - cashOut;

  // Handlers
  const handleCreateSalary = (e: React.FormEvent) => {
    e.preventDefault();
    if (findClosedPeriod(localDate())) {
      alert('اليوم ضمن فترة مقفلة. أعد فتح الفترة من «الأرشيف والإقفالات» أولاً.');
      return;
    }
    const staff = staffMembers.find((s) => s.id === Number(salaryForm.staffId));
    if (!staff) return;

    const baseSalary = staff.monthlySalary;
    const netSalary = baseSalary + Number(salaryForm.bonus) - Number(salaryForm.deductions);

    recordSalaryPayment({
      staffId: staff.id,
      staffName: staff.name,
      roleTitleAr: staff.roleTitleAr,
      month: salaryForm.month,
      baseSalary,
      bonus: Number(salaryForm.bonus),
      deductions: Number(salaryForm.deductions),
      netSalary,
      paymentDate: localDate(),
      paymentMethod: salaryForm.paymentMethod,
      status: 'paid',
      notes: salaryForm.notes,
    });

    // Also record an expense
    addExpense({
      title: `صرف راتب شهر ${salaryForm.month} للموظف: ${staff.name}`,
      category: 'salaries',
      amount: netSalary,
      paymentMethod: salaryForm.paymentMethod,
      date: localDate(),
      recipientName: staff.name,
      recordedBy: currentUser.username,
      notes: `مسير رواتب - ${staff.roleTitleAr}`,
    });

    setIsNewSalaryModalOpen(false);
  };

  const handleCreateExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (findClosedPeriod(localDate())) {
      alert('اليوم ضمن فترة مقفلة. أعد فتح الفترة من «الأرشيف والإقفالات» أولاً.');
      return;
    }
    if (!expenseForm.title || expenseForm.amount <= 0) {
      alert('يرجى إدخال بيان المصروف والمبلغ بشكل صحيح.');
      return;
    }

    addExpense({
      title: expenseForm.title,
      category: expenseForm.category,
      amount: Number(expenseForm.amount),
      paymentMethod: expenseForm.paymentMethod,
      date: localDate(),
      recipientName: expenseForm.recipientName || 'غير محدد',
      invoiceNumber: expenseForm.invoiceNumber,
      recordedBy: currentUser.username,
      notes: expenseForm.notes,
    });

    setIsNewExpenseModalOpen(false);
    setExpenseForm({
      title: '',
      category: 'supplies',
      amount: 0,
      paymentMethod: 'card',
      recipientName: '',
      invoiceNumber: '',
      notes: '',
    });
  };

  const handleCreateOtherRevenue = (e: React.FormEvent) => {
    e.preventDefault();
    if (findClosedPeriod(localDate())) {
      alert('اليوم ضمن فترة مقفلة. أعد فتح الفترة من «الأرشيف والإقفالات» أولاً.');
      return;
    }
    if (!revenueForm.title || revenueForm.amount <= 0) {
      alert('يرجى إدخال بيان الإيراد والمبلغ بشكل صحيح.');
      return;
    }

    const receiptNumber = `REC-REV-${Math.floor(100 + Math.random() * 900)}`;

    addOtherRevenue({
      title: revenueForm.title,
      category: revenueForm.category,
      amount: Number(revenueForm.amount),
      paymentMethod: revenueForm.paymentMethod,
      date: localDate(),
      customerName: revenueForm.customerName,
      roomNumber: revenueForm.roomNumber,
      receiptNumber,
      recordedBy: currentUser.username,
      notes: revenueForm.notes,
    });

    setIsNewRevenueModalOpen(false);
    setRevenueForm({
      title: '',
      category: 'hall_rental',
      amount: 0,
      paymentMethod: 'card',
      customerName: '',
      roomNumber: '',
      notes: '',
    });
  };

  const handleCreateStaff = (e: React.FormEvent) => {
    e.preventDefault();
    if (!staffForm.name) {
      alert('يرجى إدخال اسم الموظف.');
      return;
    }

    addStaffMember({
      name: staffForm.name,
      username: staffForm.username || `user_${Date.now().toString().slice(-4)}`,
      role: staffForm.role,
      roleTitleAr: staffForm.roleTitleAr,
      phone: staffForm.phone,
      nationalId: staffForm.nationalId,
      monthlySalary: Number(staffForm.monthlySalary),
      joinDate: staffForm.joinDate,
      status: 'active',
    });

    setIsNewStaffModalOpen(false);
    setStaffForm({
      name: '',
      username: '',
      role: 'receptionist',
      roleTitleAr: 'موظف استقبال',
      phone: '',
      nationalId: '',
      monthlySalary: 5000,
      joinDate: localDate(),
    });
  };

  return (
    <div className="space-y-6 animate-fadeIn" dir="rtl">
      {/* Top Banner & Total Metric Summary */}
      <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 rounded-2xl bg-sky-500/10 text-sky-500 shrink-0">
            <ArrowLeftRight className="w-7 h-7 stroke-[1.75]" />
          </div>
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-800 dark:text-slate-100">
              الإيرادات والمصروفات ورواتب الموظفين (Finance & Payroll)
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
              متابعة مسير رواتب الموظف، المصروفات التشغيلية، الإيرادات الأخرى، ورصيد الصندوق النقدي
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsNewSalaryModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs sm:text-sm shadow-sm transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>صرف راتب موظف</span>
          </button>

          <button
            onClick={() => setIsNewExpenseModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-xs sm:text-sm shadow-sm transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>سند مصروف</span>
          </button>

          <button
            onClick={() => setIsNewRevenueModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs sm:text-sm shadow-sm transition cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>إيراد إضافي</span>
          </button>
        </div>
      </div>

      {/* 4 Essential Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Total Revenues */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-2">
            <span>إجمالي الإيرادات</span>
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-xl sm:text-2xl font-black font-mono text-emerald-600 dark:text-emerald-400">
            {totalRevenue.toLocaleString()} {settings.currencySymbol}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            غرف: {totalRoomRevenue} | أخرى: {totalOtherRevenue}
          </p>
        </div>

        {/* Total Expenses */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-2">
            <span>إجمالي المصروفات</span>
            <TrendingDown className="w-4 h-4 text-rose-500" />
          </div>
          <div className="text-xl sm:text-2xl font-black font-mono text-rose-600 dark:text-rose-400">
            {totalExpensesWithSalaries.toLocaleString()} {settings.currencySymbol}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            رواتب + فواتير وصيانة ومشتريات
          </p>
        </div>

        {/* Net Profit */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-2">
            <span>صافي الأرباح</span>
            <DollarSign className="w-4 h-4 text-sky-500" />
          </div>
          <div
            className={`text-xl sm:text-2xl font-black font-mono ${
              netProfit >= 0 ? 'text-sky-600 dark:text-sky-400' : 'text-rose-500'
            }`}
          >
            {netProfit.toLocaleString()} {settings.currencySymbol}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            هامش ربح {totalRevenue > 0 ? Math.round((netProfit / totalRevenue) * 100) : 0}%
          </p>
        </div>

        {/* Cash in Drawer */}
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-200 dark:border-slate-800 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold mb-2">
            <span>رصيد الصندوق النقدي (Cash)</span>
            <Coins className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-xl sm:text-2xl font-black font-mono text-amber-600 dark:text-amber-400">
            {cashBalance.toLocaleString()} {settings.currencySymbol}
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            مقبوض كاش: {cashIn} | منصرف كاش: {cashOut}
          </p>
        </div>
      </div>

      {/* Sub-Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setActiveFinanceTab('salaries')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap flex items-center gap-2 ${
            activeFinanceTab === 'salaries'
              ? 'bg-sky-600 text-white shadow-sm'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>رواتب الموظفين (Employee Salaries)</span>
          <span className="px-2 py-0.5 rounded-full text-[10px] bg-white/20 text-current font-mono">
            {staffSalaries.length}
          </span>
        </button>

        <button
          onClick={() => setActiveFinanceTab('expenses')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap flex items-center gap-2 ${
            activeFinanceTab === 'expenses'
              ? 'bg-rose-600 text-white shadow-sm'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <TrendingDown className="w-4 h-4" />
          <span>المصروفات الفندقية (Hotel Expenses)</span>
          <span className="px-2 py-0.5 rounded-full text-[10px] bg-white/20 text-current font-mono">
            {expenses.length}
          </span>
        </button>

        <button
          onClick={() => setActiveFinanceTab('revenues')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap flex items-center gap-2 ${
            activeFinanceTab === 'revenues'
              ? 'bg-emerald-600 text-white shadow-sm'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <TrendingUp className="w-4 h-4" />
          <span>الإيرادات الإضافية (Other Revenues)</span>
          <span className="px-2 py-0.5 rounded-full text-[10px] bg-white/20 text-current font-mono">
            {otherRevenues.length}
          </span>
        </button>

        <button
          onClick={() => setActiveFinanceTab('register')}
          className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition cursor-pointer whitespace-nowrap flex items-center gap-2 ${
            activeFinanceTab === 'register'
              ? 'bg-amber-600 text-white shadow-sm'
              : 'bg-white dark:bg-slate-900 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 border border-slate-200 dark:border-slate-800'
          }`}
        >
          <Coins className="w-4 h-4" />
          <span>إقفال اليومية والصندوق (Daily Cash Register)</span>
        </button>
      </div>

      {/* 1. Tab: رواتب الموظفين (Employee Salaries) */}
      {activeFinanceTab === 'salaries' && (
        <div className="space-y-6">
          {/* Staff Roster Cards */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl p-5 border border-slate-200 dark:border-slate-800 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <UserCheck className="w-5 h-5 text-sky-500" />
                <span>كادر موظفي الفندق والرواتب المعتمدة</span>
              </h3>
              <button
                onClick={() => setIsNewStaffModalOpen(true)}
                className="flex items-center gap-1 text-xs font-semibold text-sky-600 hover:text-sky-500 dark:text-sky-400 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>إضافة موظف جديد</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
              {staffMembers.map((staff) => (
                <div
                  key={staff.id}
                  className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-800/30 flex items-center justify-between"
                >
                  <div>
                    <div className="font-bold text-sm text-slate-800 dark:text-slate-100">{staff.name}</div>
                    <div className="text-xs text-sky-600 dark:text-sky-400 font-medium">{staff.roleTitleAr}</div>
                    <div className="text-[11px] text-slate-400 mt-1">هاتف: {staff.phone}</div>
                  </div>
                  <div className="text-left">
                    <div className="font-mono font-bold text-sm text-slate-900 dark:text-slate-100">
                      {staff.monthlySalary} {settings.currencySymbol}
                    </div>
                    <span className="text-[10px] text-slate-400 block">راتب أساسي شهري</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Salary Slips Table */}
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-emerald-500" />
                <span>سجل مسير الرواتب وقسائم الصرف (Payroll History)</span>
              </h3>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs sm:text-sm">
                <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 font-semibold">
                  <tr>
                    <th className="py-3 px-4">رقم القسيمة</th>
                    <th className="py-3 px-4">اسم الموظف</th>
                    <th className="py-3 px-4">المسمى الوظيفي</th>
                    <th className="py-3 px-4">شهر الاستحقاق</th>
                    <th className="py-3 px-4">الأساسي</th>
                    <th className="py-3 px-4">المكافآت</th>
                    <th className="py-3 px-4">الاستقطاعات</th>
                    <th className="py-3 px-4 font-bold">الصافي المنصرف</th>
                    <th className="py-3 px-4">طريقة الصرف</th>
                    <th className="py-3 px-4 text-center">طباعة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {staffSalaries.map((slip) => (
                    <tr key={slip.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                      <td className="py-3.5 px-4 font-mono font-bold text-sky-600 dark:text-sky-400">
                        {slip.slipCode}
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-slate-800 dark:text-slate-100">
                        {slip.staffName}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                        {slip.roleTitleAr}
                      </td>
                      <td className="py-3.5 px-4 font-mono">{slip.month}</td>
                      <td className="py-3.5 px-4 font-mono">{slip.baseSalary} ر.ي</td>
                      <td className="py-3.5 px-4 font-mono text-emerald-600">+{slip.bonus} ر.ي</td>
                      <td className="py-3.5 px-4 font-mono text-rose-500">-{slip.deductions} ر.ي</td>
                      <td className="py-3.5 px-4 font-mono font-black text-slate-900 dark:text-slate-100">
                        {slip.netSalary} {settings.currencySymbol}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="px-2.5 py-1 rounded-full text-xs font-semibold bg-sky-50 dark:bg-sky-950/40 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800/50">
                          {slip.paymentMethod === 'transfer' ? 'تحويل بنكي' : 'نقداً من الصندوق'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-center">
                        <button
                          onClick={() => generateSalarySlipPdf(slip)}
                          title="طباعة قسيمة الراتب PDF"
                          className="p-2 text-slate-500 hover:text-sky-600 bg-slate-100 hover:bg-sky-50 dark:bg-slate-800 rounded-lg transition cursor-pointer"
                        >
                          <Printer className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 2. Tab: المصروفات الفندقية (Hotel Expenses) */}
      {activeFinanceTab === 'expenses' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <TrendingDown className="w-5 h-5 text-rose-500" />
                <span>سجل المصروفات وفواتير التشغيل والصيانة (Expenses Log)</span>
              </h3>
              <button
                onClick={() => setIsNewExpenseModalOpen(true)}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold shadow-sm transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>تسجيل مصروف</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs sm:text-sm">
                <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 font-semibold">
                  <tr>
                    <th className="py-3 px-4">رقم السند</th>
                    <th className="py-3 px-4">البيان والتفاصيل</th>
                    <th className="py-3 px-4">التصنيف</th>
                    <th className="py-3 px-4">المبلغ</th>
                    <th className="py-3 px-4">الجهة / المستلم</th>
                    <th className="py-3 px-4">طريقة الدفع</th>
                    <th className="py-3 px-4">التاريخ</th>
                    <th className="py-3 px-4">بواسطة</th>
                    <th className="py-3 px-4 text-center">حذف</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {expenses.map((exp) => (
                    <tr key={exp.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                      <td className="py-3.5 px-4 font-mono font-bold text-rose-600 dark:text-rose-400">
                        {exp.expenseCode}
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-slate-800 dark:text-slate-100">
                        {exp.title}
                        {exp.invoiceNumber && (
                          <span className="block text-[10px] text-slate-400 font-mono">
                            فاتورة: {exp.invoiceNumber}
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {exp.category === 'salaries'
                            ? 'رواتب موظفين'
                            : exp.category === 'utilities'
                            ? 'كهرباء ومياه'
                            : exp.category === 'maintenance'
                            ? 'صيانة وتكييف'
                            : exp.category === 'supplies'
                            ? 'بوفيه ومشتريات'
                            : 'نثريات عامة'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-mono font-black text-rose-600 dark:text-rose-400">
                        {exp.amount} {settings.currencySymbol}
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300">
                        {exp.recipientName}
                      </td>
                      <td className="py-3.5 px-4 text-xs font-mono">
                        {exp.paymentMethod === 'cash' ? 'نقداً (كاش)' : exp.paymentMethod === 'transfer' ? 'تحويل بنكي' : 'بطاقة مدى'}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-xs text-slate-500">{exp.date}</td>
                      <td className="py-3.5 px-4 text-xs font-mono text-sky-600">{exp.recordedBy}</td>
                      <td className="py-3.5 px-4 text-center">
                        <button
                          onClick={() => {
                            if (window.confirm(`هل أنت متأكد من حذف سند المصروف ${exp.expenseCode}؟`)) {
                              deleteExpense(exp.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded transition cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 3. Tab: الإيرادات الإضافية (Other Revenues) */}
      {activeFinanceTab === 'revenues' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
            <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-500" />
                <span>سجل الإيرادات الأخرى (قاعات، توصيل، مغسلة، ميني بار)</span>
              </h3>
              <button
                onClick={() => setIsNewRevenueModalOpen(true)}
                className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-sm transition cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>إيراد إضافي</span>
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-right text-xs sm:text-sm">
                <thead className="bg-slate-50 dark:bg-slate-950 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800 font-semibold">
                  <tr>
                    <th className="py-3 px-4">رقم الإيراد</th>
                    <th className="py-3 px-4">البيان والخدمة</th>
                    <th className="py-3 px-4">التصنيف</th>
                    <th className="py-3 px-4">المبلغ</th>
                    <th className="py-3 px-4">العميل / الغرفة</th>
                    <th className="py-3 px-4">طريقة الدفع</th>
                    <th className="py-3 px-4">التاريخ</th>
                    <th className="py-3 px-4">سند رقم</th>
                    <th className="py-3 px-4 text-center">حذف</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {otherRevenues.map((rev) => (
                    <tr key={rev.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40 transition">
                      <td className="py-3.5 px-4 font-mono font-bold text-emerald-600 dark:text-emerald-400">
                        {rev.revenueCode}
                      </td>
                      <td className="py-3.5 px-4 font-semibold text-slate-800 dark:text-slate-100">
                        {rev.title}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="px-2 py-0.5 rounded text-[11px] font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300">
                          {rev.category === 'hall_rental'
                            ? 'تأجير قاعات'
                            : rev.category === 'transport'
                            ? 'نقل وتوصيل مطار'
                            : rev.category === 'laundry'
                            ? 'مغسلة وكوي'
                            : 'ميني بار وخدمات'}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-mono font-black text-emerald-600 dark:text-emerald-400">
                        {rev.amount} {settings.currencySymbol}
                      </td>
                      <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300">
                        {rev.customerName || (rev.roomNumber ? `الغرفة ${rev.roomNumber}` : '—')}
                      </td>
                      <td className="py-3.5 px-4 text-xs font-mono">
                        {rev.paymentMethod === 'cash' ? 'نقداً (كاش)' : 'بطاقة مدى / فيزا'}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-xs text-slate-500">{rev.date}</td>
                      <td className="py-3.5 px-4 font-mono text-xs text-sky-600">{rev.receiptNumber}</td>
                      <td className="py-3.5 px-4 text-center">
                        <button
                          onClick={() => {
                            if (window.confirm(`هل أنت متأكد من حذف هذا السجل؟`)) {
                              deleteOtherRevenue(rev.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-600 rounded transition cursor-pointer"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 4. Tab: إقفال اليومية والصندوق (Daily Cash Register) */}
      {activeFinanceTab === 'register' && (
        <div className="bg-white dark:bg-slate-900 rounded-2xl p-6 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-4">
            <div>
              <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <Coins className="w-6 h-6 text-amber-500" />
                <span>إقفال الصندوق واليومية ومطابقة العهدة (Daily Cashier Close)</span>
              </h3>
              <p className="text-xs text-slate-500">
                تسوية ومطابقة المقبوضات النقدية مع المصروفات النقدية لتسليم الشفت
              </p>
            </div>
            <div className="text-left font-mono">
              <span className="text-xs text-slate-400 block">تاريخ التقرير</span>
              <span className="font-bold text-sm text-slate-700 dark:text-slate-200">2026-08-22</span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900/50 space-y-1">
              <span className="text-xs text-emerald-700 dark:text-emerald-300 font-semibold">مقبوضات كاش الصندوق (+)</span>
              <div className="text-2xl font-black font-mono text-emerald-600 dark:text-emerald-400">
                {cashIn.toLocaleString()} {settings.currencySymbol}
              </div>
              <p className="text-[11px] text-emerald-600/80">دفعات نزلاء نقدية + إيرادات كاش</p>
            </div>

            <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/50 space-y-1">
              <span className="text-xs text-rose-700 dark:text-rose-300 font-semibold">منصرفات كاش الصندوق (-)</span>
              <div className="text-2xl font-black font-mono text-rose-600 dark:text-rose-400">
                {cashOut.toLocaleString()} {settings.currencySymbol}
              </div>
              <p className="text-[11px] text-rose-600/80">مشتريات ونثريات ورواتب نقدية</p>
            </div>

            <div className="p-4 rounded-2xl bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-900/50 space-y-1">
              <span className="text-xs text-amber-700 dark:text-amber-300 font-semibold">الرصيد الفعلي بالدرج (=)</span>
              <div className="text-2xl font-black font-mono text-amber-600 dark:text-amber-400">
                {cashBalance.toLocaleString()} {settings.currencySymbol}
              </div>
              <p className="text-[11px] text-amber-600/80">العهدة النقدية الجاهزة للتسليم للبنك</p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 text-xs space-y-2">
            <div className="font-bold text-slate-700 dark:text-slate-300 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>إقرار استلام وتسليم الشفت</span>
            </div>
            <p className="text-slate-600 dark:text-slate-400">
              المستخدم الحالي المسجل بالنظام: <strong>{currentUser.name} ({currentUser.username})</strong> - الشفت: {currentUser.shift}
            </p>
            <div className="pt-2 flex justify-end">
              <button
                onClick={() => {
                  alert(`تم اعتماد وإقفال يومية الصندوق بمبلغ ${cashBalance} ${settings.currencySymbol} بنجاح!`);
                }}
                className="px-5 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-xs shadow-md transition cursor-pointer"
              >
                اعتماد إقفال اليومية وطباعة التقرير
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: New Salary Disburse */}
      {isNewSalaryModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-lg border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 animate-scaleUp">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <Plus className="w-5 h-5 text-emerald-500" />
                <span>صرف راتب موظف جديد (Salary Payment)</span>
              </h3>
              <button
                onClick={() => setIsNewSalaryModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateSalary} className="space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  اختر الموظف:
                </label>
                <select
                  value={salaryForm.staffId}
                  onChange={(e) => setSalaryForm({ ...salaryForm, staffId: Number(e.target.value) })}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-medium"
                >
                  {staffMembers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} - {s.roleTitleAr} (الأساسي: {s.monthlySalary} ر.ي)
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    شهر الاستحقاق:
                  </label>
                  <input
                    type="month"
                    value={salaryForm.month}
                    onChange={(e) => setSalaryForm({ ...salaryForm, month: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    طريقة الصرف:
                  </label>
                  <select
                    value={salaryForm.paymentMethod}
                    onChange={(e) => setSalaryForm({ ...salaryForm, paymentMethod: e.target.value as any })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5"
                  >
                    <option value="transfer">تحويل بنكي</option>
                    <option value="cash">نقداً من الصندوق (كاش)</option>
                    <option value="card">بطاقة</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-emerald-600 dark:text-emerald-400 mb-1.5">
                    مكافأة أو بدل إضافي (+):
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={salaryForm.bonus}
                    onChange={(e) => setSalaryForm({ ...salaryForm, bonus: Number(e.target.value) })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-rose-500 mb-1.5">
                    خصومات أو استقطاعات (-):
                  </label>
                  <input
                    type="number"
                    min="0"
                    value={salaryForm.deductions}
                    onChange={(e) => setSalaryForm({ ...salaryForm, deductions: Number(e.target.value) })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  ملاحظات أو بيان الصرف:
                </label>
                <input
                  type="text"
                  placeholder="مثال: راتب شهر أغسطس مع مكافأة نسبة الإشغال"
                  value={salaryForm.notes}
                  onChange={(e) => setSalaryForm({ ...salaryForm, notes: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5"
                />
              </div>

              <div className="flex items-center gap-3 pt-3">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm shadow-md transition cursor-pointer"
                >
                  اعتماد الصرف وإصدار القسيمة
                </button>
                <button
                  type="button"
                  onClick={() => setIsNewSalaryModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-sm font-medium hover:bg-slate-200 transition cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: New Expense */}
      {isNewExpenseModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-lg border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 animate-scaleUp">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <TrendingDown className="w-5 h-5 text-rose-500" />
                <span>تسجيل سند مصروف فندقي جديد</span>
              </h3>
              <button
                onClick={() => setIsNewExpenseModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateExpense} className="space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  بيان المصروف:
                </label>
                <input
                  type="text"
                  placeholder="مثال: فاتورة صيانة مصاعد / مشتريات مواد نظافة"
                  value={expenseForm.title}
                  onChange={(e) => setExpenseForm({ ...expenseForm, title: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    التصنيف:
                  </label>
                  <select
                    value={expenseForm.category}
                    onChange={(e) => setExpenseForm({ ...expenseForm, category: e.target.value as any })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5"
                  >
                    <option value="supplies">بوفيه ومشتريات</option>
                    <option value="maintenance">صيانة وتكييف</option>
                    <option value="utilities">كهرباء ومياه</option>
                    <option value="petty_cash">نثريات ومصروفات عامة</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    المبلغ ({settings.currencySymbol}):
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={expenseForm.amount || ''}
                    onChange={(e) => setExpenseForm({ ...expenseForm, amount: Number(e.target.value) })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    الجهة المستلمة / المورد:
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: شركة التجهيزات الفندقية"
                    value={expenseForm.recipientName}
                    onChange={(e) => setExpenseForm({ ...expenseForm, recipientName: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    طريقة الدفع:
                  </label>
                  <select
                    value={expenseForm.paymentMethod}
                    onChange={(e) => setExpenseForm({ ...expenseForm, paymentMethod: e.target.value as any })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5"
                  >
                    <option value="card">بطاقة مدى / فيزا</option>
                    <option value="cash">نقداً من الصندوق (كاش)</option>
                    <option value="transfer">تحويل بنكي</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-3">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-semibold text-sm shadow-md transition cursor-pointer"
                >
                  حفظ سند المصروف
                </button>
                <button
                  type="button"
                  onClick={() => setIsNewExpenseModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-sm font-medium hover:bg-slate-200 transition cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: New Other Revenue */}
      {isNewRevenueModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-lg border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 animate-scaleUp">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-emerald-500" />
                <span>تسجيل إيراد إضافي جديد</span>
              </h3>
              <button
                onClick={() => setIsNewRevenueModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateOtherRevenue} className="space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  بيان الإيراد:
                </label>
                <input
                  type="text"
                  placeholder="مثال: تأجير قاعة اجتماعات / خدمة نقل VIP"
                  value={revenueForm.title}
                  onChange={(e) => setRevenueForm({ ...revenueForm, title: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    النوع:
                  </label>
                  <select
                    value={revenueForm.category}
                    onChange={(e) => setRevenueForm({ ...revenueForm, category: e.target.value as any })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5"
                  >
                    <option value="hall_rental">تأجير قاعات</option>
                    <option value="transport">توصيل ومطار</option>
                    <option value="laundry">مغسلة وكوي</option>
                    <option value="minibar">ميني بار وخدمات</option>
                    <option value="other">أخرى</option>
                  </select>
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    المبلغ ({settings.currencySymbol}):
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={revenueForm.amount || ''}
                    onChange={(e) => setRevenueForm({ ...revenueForm, amount: Number(e.target.value) })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    اسم العميل:
                  </label>
                  <input
                    type="text"
                    placeholder="اسم الشركة أو العميل"
                    value={revenueForm.customerName}
                    onChange={(e) => setRevenueForm({ ...revenueForm, customerName: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    طريقة الدفع:
                  </label>
                  <select
                    value={revenueForm.paymentMethod}
                    onChange={(e) => setRevenueForm({ ...revenueForm, paymentMethod: e.target.value as any })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5"
                  >
                    <option value="card">بطاقة مدى / فيزا</option>
                    <option value="cash">نقداً (كاش بالصندوق)</option>
                    <option value="transfer">تحويل بنكي</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center gap-3 pt-3">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-sm shadow-md transition cursor-pointer"
                >
                  تسجيل الإيراد
                </button>
                <button
                  type="button"
                  onClick={() => setIsNewRevenueModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-sm font-medium hover:bg-slate-200 transition cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal: New Staff Member */}
      {isNewStaffModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4" dir="rtl">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-6 w-full max-w-md border border-slate-200 dark:border-slate-800 shadow-2xl space-y-5 animate-scaleUp">
            <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-3">
              <h3 className="text-lg font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                <Users className="w-5 h-5 text-sky-500" />
                <span>إضافة موظف جديد للفندق</span>
              </h3>
              <button
                onClick={() => setIsNewStaffModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 text-lg cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleCreateStaff} className="space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                  اسم الموظف الثلاثي:
                </label>
                <input
                  type="text"
                  placeholder="مثال: يوسف أحمد الغامدي"
                  value={staffForm.name}
                  onChange={(e) => setStaffForm({ ...staffForm, name: e.target.value })}
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    المسمى الوظيفي:
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: موظف استقبال"
                    value={staffForm.roleTitleAr}
                    onChange={(e) => setStaffForm({ ...staffForm, roleTitleAr: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5"
                    required
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    الراتب الأساسي الشهري:
                  </label>
                  <input
                    type="number"
                    min="1000"
                    value={staffForm.monthlySalary}
                    onChange={(e) => setStaffForm({ ...staffForm, monthlySalary: Number(e.target.value) })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    رقم الهاتف:
                  </label>
                  <input
                    type="text"
                    placeholder="05XXXXXXXX"
                    value={staffForm.phone}
                    onChange={(e) => setStaffForm({ ...staffForm, phone: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-slate-700 dark:text-slate-300 mb-1.5">
                    اسم المستخدم للدخول:
                  </label>
                  <input
                    type="text"
                    placeholder="yousef_rec"
                    value={staffForm.username}
                    onChange={(e) => setStaffForm({ ...staffForm, username: e.target.value })}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-2.5 font-mono"
                  />
                </div>
              </div>

              <div className="flex items-center gap-3 pt-3">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm shadow-md transition cursor-pointer"
                >
                  حفظ الموظف
                </button>
                <button
                  type="button"
                  onClick={() => setIsNewStaffModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 text-sm font-medium hover:bg-slate-200 transition cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
