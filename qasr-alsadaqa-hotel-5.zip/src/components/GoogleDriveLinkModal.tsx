import { saveText } from '../utils/saveFile';
import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import {
  X,
  HardDrive,
  Cloud,
  CloudUpload,
  CloudDownload,
  CheckCircle2,
  AlertCircle,
  FolderSync,
  RefreshCw,
  Plus,
  Trash2,
  Lock,
  ExternalLink,
  ShieldCheck,
  FolderCheck,
  Database,
  Calendar,
  Layers,
  ArrowRightLeft,
  Check,
  Sparkles,
} from 'lucide-react';
import { GoogleAccountLink } from '../types/hotel';
import { DriveCloudSyncPanel } from './DriveCloudSyncPanel';

export const GoogleDriveLinkModal: React.FC = () => {
  const {
    isGoogleDriveLinkModalOpen,
    setIsGoogleDriveLinkModalOpen,
    googleAccounts,
    selectedGoogleAccount,
    selectedGoogleAccountId,
    selectActiveGoogleAccount,
    linkGoogleAccountManually,
    unlinkGoogleAccount,
    updateGoogleAccountSyncSettings,
    backupSnapshots,
    createBackupSnapshot,
    restoreBackupSnapshot,
    syncSnapshotToGoogleDrive,
    syncAllToGoogleDriveNow,
    isSyncingToGoogleDrive,
    lastSyncMessage,
    settings,
  } = useHotel();

  // Manual link form state
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [newEmail, setNewEmail] = useState<string>('');
  const [newDisplayName, setNewDisplayName] = useState<string>('');
  const [newFolderName, setNewFolderName] = useState<string>('QasrAlSadaqa_Backups');
  const [formError, setFormError] = useState<string>('');

  // Confirmation for cloud restore
  const [confirmRestoreId, setConfirmRestoreId] = useState<string | null>(null);

  if (!isGoogleDriveLinkModalOpen) return null;

  const handleManualLinkSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newEmail.trim() || !newEmail.includes('@')) {
      setFormError('يرجى إدخال بريد إلكتروني صالح لـ Google (مثل: user@gmail.com)');
      return;
    }

    linkGoogleAccountManually({
      email: newEmail.trim(),
      displayName: newDisplayName.trim() || undefined,
      folderName: newFolderName.trim() || 'QasrAlSadaqa_Backups',
    });

    setFormError('');
    setShowAddForm(false);
  };

  const activeAccount = selectedGoogleAccount;

  // Filter snapshots associated with current selected account or global
  const accountSnapshots = backupSnapshots.filter(
    (s) => !s.googleAccountEmail || (activeAccount && s.googleAccountEmail === activeAccount.email)
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4" dir="rtl">
      {/* Backdrop */}
      <div
        onClick={() => setIsGoogleDriveLinkModalOpen(false)}
        className="fixed inset-0 bg-slate-950/70 backdrop-blur-sm transition-opacity"
      />

      {/* Modal Container */}
      <div className="relative w-full max-w-4xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 flex flex-col max-h-[92vh] overflow-hidden z-10 text-slate-900 dark:text-slate-100 animate-fadeIn">
        {/* Header Bar */}
        <div className="px-5 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between bg-gradient-to-r from-blue-700 via-sky-600 to-sky-700 text-white shrink-0">
          <div className="flex items-center gap-3 min-w-0">
            <div className="w-10 h-10 shrink-0 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white shadow-inner">
              <Cloud className="w-6 h-6 stroke-[2]" />
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                <h2 className="text-base sm:text-lg font-bold">ربط سحابة Google Drive والنسخ الاحتياطي</h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-100 border border-emerald-400/30 text-[11px] font-semibold">
                  ربط يدوي مخصص
                </span>
              </div>
              <p className="text-xs text-sky-100">
                تحديد الحساب يدوياً ومزامنة نسخ قاعدة بيانات SQLite بشكل آمن
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsGoogleDriveLinkModalOpen(false)}
            className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
            aria-label="إغلاق"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Sync Status Banner if active */}
        {lastSyncMessage && (
          <div className="bg-sky-50 dark:bg-sky-950/60 border-b border-sky-200 dark:border-sky-800/60 px-5 py-2 text-xs flex items-center justify-between gap-3 text-sky-800 dark:text-sky-300">
            <div className="flex items-center gap-2">
              <RefreshCw className={`w-4 h-4 text-sky-600 ${isSyncingToGoogleDrive ? 'animate-spin' : ''}`} />
              <span className="font-medium">{lastSyncMessage}</span>
            </div>
            {isSyncingToGoogleDrive && (
              <span className="font-mono text-[11px] bg-sky-100 dark:bg-sky-900 px-2 py-0.5 rounded text-sky-700 dark:text-sky-300">
                جاري المعالجة...
              </span>
            )}
          </div>
        )}

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6">
          <DriveCloudSyncPanel />

          {/* SECTION 1: Account Selection & Management (المطابق لاختيار الحساب يدوياً) */}
          <div className="bg-slate-50 dark:bg-slate-800/50 rounded-2xl p-4 sm:p-5 border border-slate-200 dark:border-slate-700/60 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 dark:border-slate-700/50 pb-3">
              <div>
                <h3 className="text-sm sm:text-base font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                  <ShieldCheck className="w-5 h-5 text-sky-600 dark:text-sky-400" />
                  اختيار وتحديد حساب Google المرتبط (Manual Account Selector)
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  الربط يتم يدويًا بناءً على الحساب الذي تقوم باختياره وتحديده أدناه:
                </p>
              </div>

              <button
                type="button"
                onClick={() => setShowAddForm(!showAddForm)}
                className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-semibold shadow-sm transition cursor-pointer active:scale-95"
              >
                <Plus className="w-4 h-4" />
                {showAddForm ? 'إلغاء النموذج' : 'إضافة / ربط حساب Google جديد'}
              </button>
            </div>

            {/* Inline Add Account Form */}
            {showAddForm && (
              <form onSubmit={handleManualLinkSubmit} className="bg-white dark:bg-slate-900 p-4 rounded-xl border border-sky-200 dark:border-sky-900/60 space-y-3 animate-fadeIn">
                <div className="text-xs font-bold text-sky-700 dark:text-sky-300 flex items-center gap-1.5">
                  <CloudUpload className="w-4 h-4" />
                  بيانات حساب Google المراد ربطه يدويًا:
                </div>

                {formError && (
                  <div className="p-2.5 rounded-lg bg-rose-50 dark:bg-rose-950/40 text-rose-600 dark:text-rose-400 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{formError}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                      بريد حساب Google (Email) *
                    </label>
                    <input
                      type="email"
                      required
                      value={newEmail}
                      onChange={(e) => setNewEmail(e.target.value)}
                      placeholder="example@gmail.com"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 font-mono text-left focus:ring-2 focus:ring-sky-500 focus:outline-none"
                      dir="ltr"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                      اسم الحساب أو المسمى التعريفي
                    </label>
                    <input
                      type="text"
                      value={newDisplayName}
                      onChange={(e) => setNewDisplayName(e.target.value)}
                      placeholder="e.g. حساب الإدارة العليا"
                      className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 focus:ring-2 focus:ring-sky-500 focus:outline-none"
                    />
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-300 mb-1">
                      مجلد الحفظ في Google Drive (Folder Path)
                    </label>
                    <div className="flex items-center gap-2">
                      <FolderCheck className="w-4 h-4 text-slate-400" />
                      <input
                        type="text"
                        value={newFolderName}
                        onChange={(e) => setNewFolderName(e.target.value)}
                        placeholder="QasrAlSadaqa_Backups"
                        className="w-full px-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-100 font-mono text-left focus:ring-2 focus:ring-sky-500 focus:outline-none"
                        dir="ltr"
                      />
                    </div>
                  </div>
                </div>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setShowAddForm(false)}
                    className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                  >
                    إلغاء
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-1.5 rounded-lg bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow transition cursor-pointer"
                  >
                    تأكيد وربط الحساب يدوياً
                  </button>
                </div>
              </form>
            )}

            {/* List of Available Google Accounts */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {googleAccounts.map((account) => {
                const isSelected = selectedGoogleAccountId === account.id;

                return (
                  <div
                    key={account.id}
                    className={`relative p-4 rounded-xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-sky-50/90 dark:bg-sky-950/40 border-sky-500 dark:border-sky-500 ring-2 ring-sky-500/20 shadow-md'
                        : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-700 hover:border-sky-300 dark:hover:border-sky-800'
                    }`}
                    onClick={() => selectActiveGoogleAccount(account.id)}
                  >
                    {/* Top Row: Radio Badge & Account Info */}
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm text-white shrink-0 ${
                            isSelected
                              ? 'bg-gradient-to-tr from-sky-600 to-blue-600 shadow'
                              : 'bg-slate-400 dark:bg-slate-600'
                          }`}
                        >
                          {account.email.substring(0, 1).toUpperCase()}
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-sm text-slate-900 dark:text-slate-100">
                              {account.displayName}
                            </span>
                            {isSelected && (
                              <span className="px-2 py-0.5 rounded-full bg-sky-600 text-white text-[10px] font-bold">
                                الحساب النشط
                              </span>
                            )}
                          </div>
                          <span className="font-mono text-xs text-slate-500 dark:text-slate-400 block" dir="ltr">
                            {account.email}
                          </span>
                        </div>
                      </div>

                      {/* Selection Radio Circle */}
                      <div
                        className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                          isSelected
                            ? 'border-sky-600 bg-sky-600 text-white'
                            : 'border-slate-300 dark:border-slate-600 bg-transparent'
                        }`}
                      >
                        {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                      </div>
                    </div>

                    {/* Account Details & Status */}
                    <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800/80 flex flex-col gap-1.5 text-xs text-slate-600 dark:text-slate-300">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">حالة الربط:</span>
                        {account.isLinked ? (
                          <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            متصل وجاهز للمزامنة
                          </span>
                        ) : (
                          <span className="text-slate-400">غير متصل</span>
                        )}
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">مجلد الحفظ:</span>
                        <span className="font-mono text-[11px] text-sky-700 dark:text-sky-300" dir="ltr">
                          {account.folderName}
                        </span>
                      </div>

                      {account.lastSyncAt && (
                        <div className="flex items-center justify-between">
                          <span className="text-slate-400">آخر مزامنة:</span>
                          <span className="font-mono text-[11px] text-slate-500">
                            {account.lastSyncAt}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Actions for this account */}
                    <div className="mt-3 pt-2 flex items-center justify-between gap-2">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          selectActiveGoogleAccount(account.id);
                        }}
                        className={`text-xs font-semibold px-2.5 py-1 rounded-lg transition ${
                          isSelected
                            ? 'text-sky-700 dark:text-sky-300 bg-sky-100/80 dark:bg-sky-900/60'
                            : 'text-slate-600 hover:text-sky-600 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        {isSelected ? 'تم التعيين كحساب نشط' : 'تعيين كحساب للنسخ'}
                      </button>

                      {googleAccounts.length > 1 && (
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            unlinkGoogleAccount(account.id);
                          }}
                          className="p-1 rounded text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition cursor-pointer"
                          title="إلغاء ربط الحساب"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* SECTION 2: Active Account Operations & Cloud Actions (العمليات بناءً على الحساب المختار) */}
          {activeAccount && (
            <div className="bg-gradient-to-br from-sky-900 to-slate-900 text-white rounded-2xl p-5 shadow-lg border border-sky-800/60 space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-2xl bg-sky-500/20 border border-sky-400/30 flex items-center justify-center text-sky-300">
                    <Cloud className="w-7 h-7" />
                  </div>
                  <div>
                    <span className="text-xs text-sky-300 font-semibold block">الحساب النشط للنسخ الاحتياطي:</span>
                    <h4 className="text-base font-bold text-white flex items-center gap-2">
                      {activeAccount.displayName}
                      <span className="text-xs font-mono font-normal text-sky-200">({activeAccount.email})</span>
                    </h4>
                  </div>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <button
                    type="button"
                    disabled={isSyncingToGoogleDrive}
                    onClick={() => syncAllToGoogleDriveNow()}
                    className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white text-xs font-bold shadow transition cursor-pointer active:scale-95"
                  >
                    <FolderSync className={`w-4 h-4 ${isSyncingToGoogleDrive ? 'animate-spin' : ''}`} />
                    مزامنة كامل قاعدة البيانات الآن
                  </button>

                  <button
                    type="button"
                    onClick={() => createBackupSnapshot('manual')}
                    className="inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl bg-white/15 hover:bg-white/25 text-white text-xs font-semibold backdrop-blur-sm border border-white/20 transition cursor-pointer"
                  >
                    <Plus className="w-4 h-4" />
                    إنشاء نسخة جديدة
                  </button>
                </div>
              </div>

              {/* Cloud Storage Gauge & Folder Status */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
                <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10">
                  <span className="text-[11px] text-slate-300 block mb-1">المجلد السحابي:</span>
                  <span className="font-mono text-xs font-semibold text-sky-200 block truncate" dir="ltr">
                    {activeAccount.folderName}
                  </span>
                </div>

                <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10">
                  <span className="text-[11px] text-slate-300 block mb-1">مساحة السحابة المستخدمة:</span>
                  <div className="flex items-center justify-between text-xs font-semibold text-sky-200">
                    <span>{((activeAccount.storageUsedMb || 1200) / 1024).toFixed(2)} GB</span>
                    <span className="text-slate-400 font-normal">من 15 GB</span>
                  </div>
                  <div className="w-full bg-slate-700/60 rounded-full h-1.5 mt-1.5 overflow-hidden">
                    <div
                      className="bg-sky-400 h-1.5 rounded-full"
                      style={{ width: `${Math.min(100, ((activeAccount.storageUsedMb || 1200) / 15360) * 100)}%` }}
                    />
                  </div>
                </div>

                <div className="bg-white/10 backdrop-blur-md rounded-xl p-3 border border-white/10">
                  <span className="text-[11px] text-slate-300 block mb-1">المزامنة التلقائية مع الحساب:</span>
                  <label className="flex items-center gap-2 cursor-pointer mt-1">
                    <input
                      type="checkbox"
                      checked={activeAccount.autoSyncEnabled}
                      onChange={(e) => updateGoogleAccountSyncSettings(activeAccount.id, e.target.checked)}
                      className="w-4 h-4 rounded text-sky-600 focus:ring-sky-500 bg-slate-800 border-slate-600"
                    />
                    <span className="text-xs font-medium text-white">
                      {activeAccount.autoSyncEnabled ? 'مفعلة تلقائياً' : 'معطلة (يدوي فقط)'}
                    </span>
                  </label>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 3: Google Drive Backups Vault (مستكشف النسخ السحابية) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                  <Database className="w-4 h-4 text-sky-600" />
                  سجل النسخ الاحتياطية المتاحة للحساب ({accountSnapshots.length})
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  النسخ المحفوظة محلياً والمزامنة مع Google Drive بحساب {activeAccount?.email}
                </p>
              </div>

              <span className="text-xs font-medium text-slate-500 dark:text-slate-400">
                إجمالي النسخ: {backupSnapshots.length}
              </span>
            </div>

            {accountSnapshots.length === 0 ? (
              <div className="p-8 rounded-2xl border-2 border-dashed border-slate-200 dark:border-slate-800 text-center space-y-3">
                <Cloud className="w-12 h-12 text-slate-400 mx-auto opacity-50" />
                <p className="text-sm text-slate-600 dark:text-slate-400">
                  لا توجد نسخ احتياطية مسجلة بعد لهذا الحساب.
                </p>
                <button
                  type="button"
                  onClick={() => createBackupSnapshot('manual')}
                  className="px-4 py-2 rounded-xl bg-sky-600 hover:bg-sky-700 text-white text-xs font-bold shadow transition cursor-pointer"
                >
                  إنشاء نسخة احتياطية أولى الآن
                </button>
              </div>
            ) : (
              <div className="divide-y divide-slate-200 dark:divide-slate-800 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden bg-white dark:bg-slate-900 shadow-sm">
                {accountSnapshots.map((snap) => {
                  return (
                    <div
                      key={snap.id}
                      className="p-4 flex flex-col md:flex-row md:items-center justify-between gap-3 hover:bg-slate-50 dark:hover:bg-slate-800/50 transition"
                    >
                      {/* Snapshot Meta */}
                      <div className="space-y-1.5">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-mono font-semibold text-xs text-slate-800 dark:text-slate-100" dir="ltr">
                            {snap.filename}
                          </span>

                          {snap.isSyncedToGoogleDrive ? (
                            <span className="px-2 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-[10px] font-bold flex items-center gap-1">
                              <Cloud className="w-3 h-3" />
                              مزامنة مع Google Drive
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full bg-amber-100 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 text-[10px] font-bold">
                              نسخة محلية فقط
                            </span>
                          )}

                          <span className="px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 text-[10px] font-medium font-mono">
                            {snap.sizeKb} KB
                          </span>
                        </div>

                        <div className="flex items-center gap-4 text-[11px] text-slate-500 dark:text-slate-400 flex-wrap">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3.5 h-3.5" />
                            {snap.createdAt}
                          </span>
                          <span>الغرف: {snap.recordsCount.rooms}</span>
                          <span>النزلاء: {snap.recordsCount.guests}</span>
                          <span>الحجوزات: {snap.recordsCount.bookings}</span>
                          <span>المصروفات والرواتب: {snap.recordsCount.expenses + snap.recordsCount.salaries}</span>
                        </div>
                      </div>

                      {/* Snapshot Action Buttons */}
                      <div className="flex items-center gap-2 shrink-0 pt-2 md:pt-0">
                        {!snap.isSyncedToGoogleDrive && (
                          <button
                            type="button"
                            onClick={() => syncSnapshotToGoogleDrive(snap.id)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-sky-50 dark:bg-sky-950/50 hover:bg-sky-100 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800 text-xs font-semibold transition cursor-pointer"
                          >
                            <CloudUpload className="w-3.5 h-3.5" />
                            رفع إلى Drive
                          </button>
                        )}

                        {confirmRestoreId === snap.id ? (
                          <div className="flex items-center gap-1 animate-fadeIn">
                            <button
                              type="button"
                              onClick={async () => {
                                await restoreBackupSnapshot(snap.id);
                                setConfirmRestoreId(null);
                              }}
                              className="px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold shadow cursor-pointer"
                            >
                              تأكيد الاستعادة
                            </button>
                            <button
                              type="button"
                              onClick={() => setConfirmRestoreId(null)}
                              className="px-2 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs text-slate-600 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
                            >
                              إلغاء
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => setConfirmRestoreId(snap.id)}
                            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 text-xs font-semibold transition cursor-pointer"
                          >
                            <RefreshCw className="w-3.5 h-3.5" />
                            استعادة قاعدة البيانات
                          </button>
                        )}

                        <button
                          type="button"
                          onClick={() => {
                            const data = snap.rawJson || JSON.stringify(snap, null, 2);
                            saveText(snap.filename, data, 'application/json');
                          }}
                          className="p-1.5 rounded-lg border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-600 dark:text-slate-300 transition cursor-pointer"
                          title="تحميل ملف النسخة JSON"
                        >
                          <CloudDownload className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
            <Lock className="w-3.5 h-3.5 text-emerald-500" />
            <span>التشفير والربط السحابي: حساب Google Drive المختار ({activeAccount?.email})</span>
          </div>

          <button
            type="button"
            onClick={() => setIsGoogleDriveLinkModalOpen(false)}
            className="w-full sm:w-auto px-5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition cursor-pointer"
          >
            إغلاق النافذة
          </button>
        </div>
      </div>
    </div>
  );
};
