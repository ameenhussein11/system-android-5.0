import React, { useMemo, useState } from 'react';
import { CalendarPlus, CalendarClock, LogIn, XCircle, UserX, ChevronDown, ChevronUp } from 'lucide-react';
import { useHotel } from '../context/HotelContext';
import { PaymentMethod } from '../types/hotel';
import { localDate, addDaysToDateStr } from '../utils/dates';
import { RESERVATION_DRAFT_KEY } from './RoomExtras';

const inputCls =
  'w-full bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg px-3 py-2 text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500';
const labelCls = 'block text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1';

export const FutureReservationsPanel: React.FC = () => {
  const { rooms, reservations, addReservation, cancelReservation, convertReservationToStay, settings } = useHotel();

  const today = localDate();
  const [open, setOpen] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState('');

  const [roomId, setRoomId] = useState<number>(0);
  const [arrival, setArrival] = useState(today);
  const [nights, setNights] = useState(1);
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [nationalId, setNationalId] = useState('');
  const [price, setPrice] = useState<number>(0);
  const [discount, setDiscount] = useState(0);
  const [deposit, setDeposit] = useState(0);
  const [method, setMethod] = useState<PaymentMethod>('cash');
  const [notes, setNotes] = useState('');

  // opened from a room dialog ("حجز مسبق لهذه الغرفة")
  React.useEffect(() => {
    try {
      const raw = localStorage.getItem(RESERVATION_DRAFT_KEY);
      if (!raw) return;
      localStorage.removeItem(RESERVATION_DRAFT_KEY);
      const id = Number(raw);
      if (!Number.isFinite(id)) return;
      setOpen(true);
      setShowForm(true);
      setRoomId(id);
      const room = rooms.find((r) => r.id === id);
      if (room) setPrice(room.pricePerNight);
    } catch {
      /* ignore */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const bookableRooms = useMemo(() => rooms.filter((r) => r.status !== 'maintenance'), [rooms]);
  const upcoming = useMemo(
    () =>
      reservations
        .filter((r) => r.status === 'confirmed')
        .sort((a, b) => a.arrivalDate.localeCompare(b.arrivalDate)),
    [reservations]
  );

  const total = Math.round(Number(price) * Number(nights) * (1 - (Number(discount) || 0) / 100)) || 0;

  const pickRoom = (id: number) => {
    setRoomId(id);
    const room = rooms.find((r) => r.id === id);
    if (room) setPrice(room.pricePerNight);
  };

  const reset = () => {
    setName(''); setPhone(''); setNationalId(''); setNotes('');
    setNights(1); setDiscount(0); setDeposit(0); setArrival(today); setError('');
  };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const res = addReservation({
      roomId,
      guestName: name,
      guestPhone: phone,
      guestNationalId: nationalId,
      arrivalDate: arrival,
      nights: Number(nights),
      pricePerNight: Number(price),
      discountPercent: Number(discount) || 0,
      depositPaid: Number(deposit) || 0,
      paymentMethod: method,
      notes,
    });
    if (!res.success) {
      setError(res.error || 'تعذّر إنشاء الحجز.');
      return;
    }
    reset();
    setShowForm(false);
  };

  return (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden" dir="rtl">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center justify-between gap-3 p-4 text-right cursor-pointer"
      >
        <span className="flex items-center gap-2.5">
          <span className="p-2 rounded-xl bg-violet-500/10 text-violet-500">
            <CalendarClock className="w-5 h-5" />
          </span>
          <span>
            <span className="block font-bold text-slate-800 dark:text-slate-100 text-sm sm:text-base">
              الحجوزات المسبقة ({upcoming.length})
            </span>
            <span className="block text-xs text-slate-500 dark:text-slate-400">حجز غرفة لتاريخ قادم مع عربون اختياري</span>
          </span>
        </span>
        {open ? <ChevronUp className="w-5 h-5 text-slate-400" /> : <ChevronDown className="w-5 h-5 text-slate-400" />}
      </button>

      {open && (
        <div className="border-t border-slate-100 dark:border-slate-800 p-4 space-y-4">
          {!showForm && (
            <button
              type="button"
              onClick={() => {
                setShowForm(true);
                if (!roomId && bookableRooms[0]) pickRoom(bookableRooms[0].id);
              }}
              className="flex items-center gap-2 bg-violet-600 hover:bg-violet-500 text-white px-4 py-2 rounded-xl font-semibold text-sm cursor-pointer"
            >
              <CalendarPlus className="w-4 h-4" />
              حجز مسبق جديد
            </button>
          )}

          {showForm && (
            <form onSubmit={submit} className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-slate-50 dark:bg-slate-800/40 p-3 rounded-xl">
              <div>
                <label className={labelCls}>الغرفة</label>
                <select className={inputCls} value={roomId} onChange={(e) => pickRoom(Number(e.target.value))}>
                  {bookableRooms.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.roomNumber} — {r.type} — {r.pricePerNight} {settings.currencySymbol || 'ر.ي'}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className={labelCls}>تاريخ الوصول</label>
                <input type="date" min={today} className={inputCls} value={arrival} onChange={(e) => setArrival(e.target.value)} required />
              </div>
              <div>
                <label className={labelCls}>اسم النزيل</label>
                <input className={inputCls} value={name} onChange={(e) => setName(e.target.value)} required />
              </div>
              <div>
                <label className={labelCls}>رقم الجوال</label>
                <input className={inputCls} inputMode="tel" value={phone} onChange={(e) => setPhone(e.target.value)} required />
              </div>
              <div>
                <label className={labelCls}>رقم الهوية (اختياري)</label>
                <input className={inputCls} value={nationalId} onChange={(e) => setNationalId(e.target.value)} />
              </div>
              <div>
                <label className={labelCls}>عدد الليالي</label>
                <input type="number" min={1} max={365} className={inputCls} value={nights} onChange={(e) => setNights(Number(e.target.value))} />
              </div>
              <div>
                <label className={labelCls}>سعر الليلة</label>
                <input type="number" min={1} className={inputCls} value={price} onChange={(e) => setPrice(Number(e.target.value))} />
              </div>
              <div>
                <label className={labelCls}>الخصم %</label>
                <input type="number" min={0} max={100} className={inputCls} value={discount} onChange={(e) => setDiscount(Number(e.target.value))} />
              </div>
              <div>
                <label className={labelCls}>العربون المدفوع (الإجمالي {total})</label>
                <input type="number" min={0} max={total} className={inputCls} value={deposit} onChange={(e) => setDeposit(Number(e.target.value))} />
              </div>
              <div>
                <label className={labelCls}>طريقة دفع العربون</label>
                <select className={inputCls} value={method} onChange={(e) => setMethod(e.target.value as PaymentMethod)}>
                  <option value="cash">💵 نقداً</option>
                  <option value="card">💳 بطاقة</option>
                  <option value="transfer">🏦 تحويل بنكي</option>
                  <option value="unpaid">⏳ بدون عربون</option>
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className={labelCls}>ملاحظات</label>
                <input className={inputCls} value={notes} onChange={(e) => setNotes(e.target.value)} />
              </div>
              <div className="sm:col-span-2 text-xs text-slate-500">
                المغادرة المتوقعة: {arrival && nights > 0 ? addDaysToDateStr(arrival, Number(nights)) : '—'}
              </div>
              {error && (
                <div className="sm:col-span-2 text-xs font-semibold text-rose-600 bg-rose-50 dark:bg-rose-950/40 rounded-lg p-2" role="alert">
                  {error}
                </div>
              )}
              <div className="sm:col-span-2 flex gap-2">
                <button type="submit" className="bg-violet-600 hover:bg-violet-500 text-white px-4 py-2 rounded-xl font-semibold text-sm cursor-pointer">
                  تأكيد الحجز
                </button>
                <button
                  type="button"
                  onClick={() => { setShowForm(false); setError(''); }}
                  className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 text-sm font-semibold cursor-pointer"
                >
                  إلغاء
                </button>
              </div>
            </form>
          )}

          {upcoming.length === 0 ? (
            <p className="text-center text-sm text-slate-400 py-4">لا توجد حجوزات مسبقة قادمة</p>
          ) : (
            <ul className="space-y-2">
              {upcoming.map((r) => {
                const late = r.arrivalDate < today;
                const canCheckIn = r.arrivalDate <= today;
                return (
                  <li
                    key={r.id}
                    className="border border-slate-200 dark:border-slate-700 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                  >
                    <div className="text-sm space-y-0.5">
                      <div className="font-bold text-slate-800 dark:text-slate-100">
                        {r.guestName} <span className="text-xs font-mono text-slate-400">{r.code}</span>
                      </div>
                      <div className="text-xs text-slate-500 dark:text-slate-400">
                        الغرفة {r.roomNumber} • {r.arrivalDate} ← {r.departureDate} ({r.nights} ليالٍ) • الإجمالي {r.totalAmount}
                        {r.depositPaid > 0 ? ` • عربون ${r.depositPaid}` : ''}
                      </div>
                      {late && <div className="text-xs font-bold text-amber-600">⚠️ تجاوز موعد الوصول</div>}
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        disabled={!canCheckIn}
                        title={canCheckIn ? '' : 'لم يحن موعد الوصول بعد'}
                        onClick={() => convertReservationToStay(r.id)}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 disabled:cursor-not-allowed text-white text-xs font-semibold cursor-pointer"
                      >
                        <LogIn className="w-3.5 h-3.5" /> تسكين
                      </button>
                      {late && (
                        <button
                          type="button"
                          onClick={() => cancelReservation(r.id, true)}
                          className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-amber-100 text-amber-800 text-xs font-semibold cursor-pointer"
                        >
                          <UserX className="w-3.5 h-3.5" /> لم يحضر
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`إلغاء الحجز ${r.code}؟`)) cancelReservation(r.id);
                        }}
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-rose-100 text-rose-700 text-xs font-semibold cursor-pointer"
                      >
                        <XCircle className="w-3.5 h-3.5" /> إلغاء
                      </button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}
    </div>
  );
};
