import { isNativeApp } from '../utils/saveFile';
import React, { useState } from 'react';
import { useHotel } from '../context/HotelContext';
import { PaymentMethod } from '../types/hotel';
import {
  X,
  User,
  Phone,
  CreditCard,
  Calendar,
  Sparkles,
  FileText,
  Printer,
  Download,
  Plus,
  CheckCircle2,
  AlertCircle,
  TrendingDown,
  TrendingUp,
  Receipt,
  Bed,
  Shield,
  Layers,
  DollarSign,
  ArrowUpRight,
  ArrowDownLeft,
  Coffee,
} from 'lucide-react';

export const GuestStatementModal: React.FC = () => {
  const {
    selectedGuestForStatement,
    setSelectedGuestForStatement,
    bookings,
    payments,
    settings,
    recordGuestPayment,
    generateGuestStatementPdf,
    setIsLinkGuestModalOpen,
    setPreselectedGuestForLink,
  } = useHotel();

  const [activeTab, setActiveTab] = useState<'all' | 'bookings' | 'payments' | 'charges'>('all');
  const [isAddingPayment, setIsAddingPayment] = useState<boolean>(false);
  const [payAmount, setPayAmount] = useState<string>('');
  const [payMethod, setPayMethod] = useState<PaymentMethod>('card');
  const [payNotes, setPayNotes] = useState<string>('سداد دفعة من الحساب');
  const [selectedBookingId, setSelectedBookingId] = useState<number | undefined>(undefined);

  if (!selectedGuestForStatement) return null;

  const guest = selectedGuestForStatement;
  const guestBookings = bookings.filter((b) => b.guestId === guest.id);
  const guestPayments = payments.filter((p) => p.guestId === guest.id);

  // Financial calculations
  const totalInvoiced = guestBookings.reduce((sum, b) => sum + b.totalAmount, 0);
  const totalPaid = guestPayments.reduce((sum, p) => sum + p.amount, 0);
  const netBalance = totalInvoiced - totalPaid;
  const totalLoyaltySavings = guestBookings.reduce((sum, b) => {
    const raw = b.pricePerNight * b.nights;
    return sum + (raw - b.roomTotal);
  }, 0);

  // Extract all additional service charges
  const allCharges = guestBookings.flatMap((b) =>
    (b.additionalCharges || []).map((ch) => ({
      ...ch,
      bookingCode: b.bookingCode,
      roomNumber: b.roomNumber,
    }))
  );

  // Build Unified Ledger / Transactions Chronological list
  type LedgerItem = {
    id: string;
    date: string;
    type: 'stay' | 'payment' | 'charge';
    title: string;
    description: string;
    debit: number; // Charges (+)
    credit: number; // Payments (-)
    reference: string;
    statusBadge?: string;
  };

  const ledgerItems: LedgerItem[] = [];

  // Add stays
  guestBookings.forEach((b) => {
    ledgerItems.push({
      id: `booking-${b.id}`,
      date: b.checkInDate,
      type: 'stay',
      title: `إقامة غرفة #${b.roomNumber} (${b.nights} ليالي)`,
      description: `حجز رقم ${b.bookingCode} • ${b.pricePerNight} ${settings.currencySymbol}/ليلة ${
        b.discountPercent > 0 ? `(خصم ${b.discountPercent}%)` : ''
      }`,
      debit: b.roomTotal,
      credit: 0,
      reference: b.bookingCode,
      statusBadge: b.isActive ? 'حجز نشط حالياً' : 'مكتمل',
    });

    // Add individual additional charges if any
    (b.additionalCharges || []).forEach((ch) => {
      ledgerItems.push({
        id: `charge-${ch.id}`,
        date: ch.date,
        type: 'charge',
        title: `خدمة إضافية: ${ch.description}`,
        description: `غرفة #${b.roomNumber} (${b.bookingCode})`,
        debit: ch.amount,
        credit: 0,
        reference: ch.id,
      });
    });
  });

  // Add payments
  guestPayments.forEach((p) => {
    ledgerItems.push({
      id: `pay-${p.id}`,
      date: p.date,
      type: 'payment',
      title: `سند قبض مسدد (${p.method === 'card' ? 'بطاقة بنكية' : p.method === 'cash' ? 'نقداً كاش' : p.method === 'transfer' ? 'تحويل بنكي' : 'مدى'})`,
      description: p.notes || 'سداد دفعة مالية',
      debit: 0,
      credit: p.amount,
      reference: p.receiptNumber,
    });
  });

  // Sort by date descending
  ledgerItems.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  const handleRecordPayment = (e: React.FormEvent) => {
    e.preventDefault();
    const amountNum = parseFloat(payAmount);
    if (!amountNum || amountNum <= 0) return;

    recordGuestPayment({
      guestId: guest.id,
      bookingId: selectedBookingId,
      amount: amountNum,
      method: payMethod,
      notes: payNotes,
    });

    setPayAmount('');
    setIsAddingPayment(false);
  };

  const handleLinkToRoom = () => {
    setPreselectedGuestForLink(guest);
    setSelectedGuestForStatement(null);
    setIsLinkGuestModalOpen(true);
  };

  const handlePrint = () => {
    // window.print() does nothing inside the Android WebView — export a PDF instead
    if (isNativeApp()) generateGuestStatementPdf(guest);
    else window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-xs animate-fadeIn">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-4xl max-h-[92vh] overflow-y-auto shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-6 border-b border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/70 sticky top-0 z-20 flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-emerald-600 dark:bg-emerald-500 text-white flex items-center justify-center font-bold shadow-md shadow-emerald-500/20">
              <FileText className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg font-bold text-slate-900 dark:text-white">
                  كشف حساب العميل: {guest.name}
                </h2>
                {guest.isVip && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-600 dark:text-amber-300 text-xs font-bold flex items-center gap-1 border border-amber-500/30">
                    <Sparkles className="w-3 h-3" />
                    عميل مميز VIP
                  </span>
                )}
                {guest.isFrequent && !guest.isVip && (
                  <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-600 dark:text-emerald-300 text-xs font-bold">
                    مستأجر دائم ({guest.loyaltyDiscountPercent}% خصم)
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                رقم الهاتف: <span className="font-mono">{guest.phone}</span> • الهوية: {guest.nationalId || 'غير مسجلة'} • عدد الإقامات: {guest.visitCount}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => generateGuestStatementPdf(guest)}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium rounded-lg flex items-center gap-1.5 transition cursor-pointer"
              title="تصدير ملف PDF رسمي"
            >
              <Download className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden sm:inline">تصدير PDF</span>
            </button>
            <button
              onClick={handlePrint}
              className="p-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
              title="طباعة"
            >
              <Printer className="w-4 h-4" />
            </button>
            <button
              onClick={() => setSelectedGuestForStatement(null)}
              className="p-2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-6 space-y-6">
          {/* Top KPI Financial Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {/* Total Invoiced */}
            <div className="bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/60 p-3.5 rounded-xl">
              <span className="text-slate-500 dark:text-slate-400 text-xs font-medium flex items-center gap-1">
                <ArrowUpRight className="w-3.5 h-3.5 text-slate-400" />
                إجمالي الرسوم (مدين)
              </span>
              <p className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white mt-1">
                {totalInvoiced.toLocaleString()}{' '}
                <span className="text-xs font-normal text-slate-400">{settings.currencySymbol}</span>
              </p>
            </div>

            {/* Total Paid */}
            <div className="bg-emerald-50/60 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-900/40 p-3.5 rounded-xl">
              <span className="text-emerald-700 dark:text-emerald-300 text-xs font-medium flex items-center gap-1">
                <ArrowDownLeft className="w-3.5 h-3.5 text-emerald-500" />
                إجمالي المدفوع (دائن)
              </span>
              <p className="text-lg sm:text-xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">
                {totalPaid.toLocaleString()}{' '}
                <span className="text-xs font-normal text-emerald-500/70">{settings.currencySymbol}</span>
              </p>
            </div>

            {/* Net Outstanding Balance */}
            <div
              className={`p-3.5 rounded-xl border ${
                netBalance > 0
                  ? 'bg-rose-50/60 dark:bg-rose-950/20 border-rose-200 dark:border-rose-900/40'
                  : 'bg-teal-50/60 dark:bg-teal-950/20 border-teal-200 dark:border-teal-900/40'
              }`}
            >
              <span
                className={`text-xs font-medium flex items-center gap-1 ${
                  netBalance > 0 ? 'text-rose-700 dark:text-rose-300' : 'text-teal-700 dark:text-teal-300'
                }`}
              >
                {netBalance > 0 ? (
                  <AlertCircle className="w-3.5 h-3.5 text-rose-500" />
                ) : (
                  <CheckCircle2 className="w-3.5 h-3.5 text-teal-500" />
                )}
                الرصيد المتبقي (الحساب)
              </span>
              <p
                className={`text-lg sm:text-xl font-bold mt-1 ${
                  netBalance > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-teal-600 dark:text-teal-400'
                }`}
              >
                {netBalance > 0 ? `+${netBalance.toLocaleString()}` : netBalance === 0 ? '0.00' : netBalance.toLocaleString()}{' '}
                <span className="text-xs font-normal opacity-75">{settings.currencySymbol}</span>
              </p>
            </div>

            {/* Loyalty Savings */}
            <div className="bg-amber-50/60 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 p-3.5 rounded-xl">
              <span className="text-amber-700 dark:text-amber-300 text-xs font-medium flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                وفورات خصم الولاء
              </span>
              <p className="text-lg sm:text-xl font-bold text-amber-600 dark:text-amber-400 mt-1">
                {totalLoyaltySavings.toLocaleString()}{' '}
                <span className="text-xs font-normal text-amber-500/70">{settings.currencySymbol}</span>
              </p>
            </div>
          </div>

          {/* Quick Action Bar */}
          <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-700/60 rounded-xl">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsAddingPayment(!isAddingPayment)}
                className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>تسجيل سند قبض / دفعة جديدة</span>
              </button>

              <button
                onClick={handleLinkToRoom}
                className="px-3.5 py-2 bg-slate-900 hover:bg-slate-800 dark:bg-slate-700 dark:hover:bg-slate-600 text-white rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-sm cursor-pointer"
              >
                <Bed className="w-4 h-4 text-emerald-400" />
                <span>تسكين وربط بغرفة جديدة</span>
              </button>
            </div>

            {/* Status overview text */}
            <div className="text-xs text-slate-500 dark:text-slate-400 font-mono">
              آخر نشاط: {guest.lastVisitDate || guest.createdAt}
            </div>
          </div>

          {/* Inline Add Payment Form */}
          {isAddingPayment && (
            <form
              onSubmit={handleRecordPayment}
              className="p-4 bg-emerald-50/70 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/50 rounded-xl space-y-3 animate-fadeIn"
            >
              <div className="flex items-center justify-between border-b border-emerald-200 dark:border-emerald-800/50 pb-2">
                <span className="text-xs font-bold text-emerald-900 dark:text-emerald-200 flex items-center gap-1.5">
                  <Receipt className="w-4 h-4 text-emerald-600" />
                  إصدار سند قبض وتحصيل مالي لحساب النزيل
                </span>
                <button
                  type="button"
                  onClick={() => setIsAddingPayment(false)}
                  className="text-xs text-slate-400 hover:text-slate-600"
                >
                  إلغاء
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    المبلغ المستلم ({settings.currencySymbol}) *
                  </label>
                  <input
                    type="number"
                    min="1"
                    step="any"
                    value={payAmount}
                    onChange={(e) => setPayAmount(e.target.value)}
                    placeholder={netBalance > 0 ? netBalance.toString() : '100'}
                    required
                    className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-sm focus:outline-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    طريقة الدفع *
                  </label>
                  <select
                    value={payMethod}
                    onChange={(e) => setPayMethod(e.target.value as PaymentMethod)}
                    className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-emerald-500"
                  >
                    <option value="card">بطاقة بنكية / مدى</option>
                    <option value="cash">نقداً كاش</option>
                    <option value="transfer">تحويل بنكي</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                    تخصيص لحجز معين (اختياري)
                  </label>
                  <select
                    value={selectedBookingId || ''}
                    onChange={(e) => setSelectedBookingId(e.target.value ? parseInt(e.target.value) : undefined)}
                    className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-emerald-500"
                  >
                    <option value="">حساب العميل العام</option>
                    {guestBookings.map((b) => (
                      <option key={b.id} value={b.id}>
                        حجز {b.bookingCode} (غرفة {b.roomNumber})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-slate-700 dark:text-slate-300 block mb-1">
                  ملاحظات أو بيان السند
                </label>
                <input
                  type="text"
                  value={payNotes}
                  onChange={(e) => setPayNotes(e.target.value)}
                  placeholder="دفعة إيجار، تسوية حساب، إيداع..."
                  className="w-full px-3 py-1.5 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg text-xs focus:outline-emerald-500"
                />
              </div>

              <div className="flex justify-end gap-2">
                <button
                  type="submit"
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-bold transition shadow-sm cursor-pointer"
                >
                  حفظ وتسجيل سند القبض
                </button>
              </div>
            </form>
          )}

          {/* Navigation Filter Tabs */}
          <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-2">
            <div className="flex items-center gap-2">
              <button
                onClick={() => setActiveTab('all')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition cursor-pointer ${
                  activeTab === 'all'
                    ? 'bg-slate-900 dark:bg-slate-800 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                جميع الحركات المالية ({ledgerItems.length})
              </button>

              <button
                onClick={() => setActiveTab('bookings')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition cursor-pointer ${
                  activeTab === 'bookings'
                    ? 'bg-slate-900 dark:bg-slate-800 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                الإقامات والحجوزات ({guestBookings.length})
              </button>

              <button
                onClick={() => setActiveTab('payments')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition cursor-pointer ${
                  activeTab === 'payments'
                    ? 'bg-slate-900 dark:bg-slate-800 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                سندات القبض والدفعات ({guestPayments.length})
              </button>

              <button
                onClick={() => setActiveTab('charges')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition cursor-pointer ${
                  activeTab === 'charges'
                    ? 'bg-slate-900 dark:bg-slate-800 text-white shadow-xs'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                الخدمات الإضافية ({allCharges.length})
              </button>
            </div>
          </div>

          {/* Table / List based on selected tab */}
          {activeTab === 'all' && (
            <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="p-3 font-semibold">التاريخ</th>
                    <th className="p-3 font-semibold">البيان والحركة</th>
                    <th className="p-3 font-semibold">رقم المرجع / الكود</th>
                    <th className="p-3 font-semibold text-rose-600 dark:text-rose-400">مدين (رسوم)</th>
                    <th className="p-3 font-semibold text-emerald-600 dark:text-emerald-400">دائن (مسدد)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {ledgerItems.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-8 text-center text-slate-400">
                        لا توجد حركات مالية مسجلة لهذا العميل بعد
                      </td>
                    </tr>
                  ) : (
                    ledgerItems.map((item) => (
                      <tr key={item.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                        <td className="p-3 font-mono text-slate-500 whitespace-nowrap">{item.date}</td>
                        <td className="p-3">
                          <div className="font-bold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                            {item.type === 'stay' ? (
                              <Bed className="w-3.5 h-3.5 text-blue-500 shrink-0" />
                            ) : item.type === 'payment' ? (
                              <Receipt className="w-3.5 h-3.5 text-emerald-500 shrink-0" />
                            ) : (
                              <Coffee className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                            )}
                            <span>{item.title}</span>
                            {item.statusBadge && (
                              <span className="px-1.5 py-0.2 bg-slate-100 dark:bg-slate-800 text-[10px] rounded text-slate-500">
                                {item.statusBadge}
                              </span>
                            )}
                          </div>
                          <p className="text-[11px] text-slate-400 mt-0.5">{item.description}</p>
                        </td>
                        <td className="p-3 font-mono text-slate-600 dark:text-slate-300 whitespace-nowrap">
                          {item.reference}
                        </td>
                        <td className="p-3 font-bold text-rose-600 dark:text-rose-400 whitespace-nowrap">
                          {item.debit > 0 ? `${item.debit.toLocaleString()} ${settings.currencySymbol}` : '—'}
                        </td>
                        <td className="p-3 font-bold text-emerald-600 dark:text-emerald-400 whitespace-nowrap">
                          {item.credit > 0 ? `${item.credit.toLocaleString()} ${settings.currencySymbol}` : '—'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'bookings' && (
            <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="p-3 font-semibold">كود الحجز</th>
                    <th className="p-3 font-semibold">الغرفة</th>
                    <th className="p-3 font-semibold">تاريخ الوصول</th>
                    <th className="p-3 font-semibold">تاريخ المغادرة</th>
                    <th className="p-3 font-semibold">الليالي</th>
                    <th className="p-3 font-semibold">السعر</th>
                    <th className="p-3 font-semibold">الإجمالي</th>
                    <th className="p-3 font-semibold">المسدد</th>
                    <th className="p-3 font-semibold">الحالة</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {guestBookings.length === 0 ? (
                    <tr>
                      <td colSpan={9} className="p-8 text-center text-slate-400">
                        لا توجد إقامات سابقة أو حالية
                      </td>
                    </tr>
                  ) : (
                    guestBookings.map((b) => (
                      <tr key={b.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                        <td className="p-3 font-mono font-bold text-emerald-600 dark:text-emerald-400">{b.bookingCode}</td>
                        <td className="p-3 font-bold text-slate-800 dark:text-slate-200">غرفة #{b.roomNumber}</td>
                        <td className="p-3 font-mono text-slate-500">{b.checkInDate.substring(0, 10)}</td>
                        <td className="p-3 font-mono text-slate-500">{b.expectedCheckOutDate.substring(0, 10)}</td>
                        <td className="p-3">{b.nights} ليالي</td>
                        <td className="p-3">{b.pricePerNight} {settings.currencySymbol}</td>
                        <td className="p-3 font-bold text-slate-900 dark:text-white">{b.totalAmount} {settings.currencySymbol}</td>
                        <td className="p-3 font-bold text-emerald-600">{b.paidAmount} {settings.currencySymbol}</td>
                        <td className="p-3">
                          <span
                            className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              b.isActive
                                ? 'bg-rose-500/20 text-rose-600 dark:text-rose-400'
                                : 'bg-slate-200 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                            }`}
                          >
                            {b.isActive ? 'نزيل حالي' : 'مغادر'}
                          </span>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'payments' && (
            <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="p-3 font-semibold">رقم السند</th>
                    <th className="p-3 font-semibold">التاريخ والوقت</th>
                    <th className="p-3 font-semibold">طريقة الدفع</th>
                    <th className="p-3 font-semibold">المبلغ المسدد</th>
                    <th className="p-3 font-semibold">البيان</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {guestPayments.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="p-8 text-center text-slate-400">
                        لا توجد سندات قبض مسجلة
                      </td>
                    </tr>
                  ) : (
                    guestPayments.map((p) => (
                      <tr key={p.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                        <td className="p-3 font-mono font-bold text-emerald-600 dark:text-emerald-400">{p.receiptNumber}</td>
                        <td className="p-3 font-mono text-slate-500">{p.date}</td>
                        <td className="p-3">
                          <span className="px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded text-[11px] font-medium">
                            {p.method === 'card' ? 'بطاقة بنكية' : p.method === 'cash' ? 'نقداً كاش' : 'تحويل بنكي'}
                          </span>
                        </td>
                        <td className="p-3 font-bold text-emerald-600 dark:text-emerald-400 text-sm">
                          {p.amount.toLocaleString()} {settings.currencySymbol}
                        </td>
                        <td className="p-3 text-slate-600 dark:text-slate-400">{p.notes || '—'}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}

          {activeTab === 'charges' && (
            <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
              <table className="w-full text-right text-xs">
                <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                  <tr>
                    <th className="p-3 font-semibold">التاريخ</th>
                    <th className="p-3 font-semibold">الخدمة / البيان</th>
                    <th className="p-3 font-semibold">الغرفة والحجز</th>
                    <th className="p-3 font-semibold">المبلغ</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {allCharges.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="p-8 text-center text-slate-400">
                        لا توجد خدمات أو رسوم إضافية مسجلة
                      </td>
                    </tr>
                  ) : (
                    allCharges.map((ch) => (
                      <tr key={ch.id} className="hover:bg-slate-50/60 dark:hover:bg-slate-800/40">
                        <td className="p-3 font-mono text-slate-500">{ch.date}</td>
                        <td className="p-3 font-bold text-slate-800 dark:text-slate-200">{ch.description}</td>
                        <td className="p-3 font-mono text-slate-600 dark:text-slate-300">
                          غرفة #{ch.roomNumber} ({ch.bookingCode})
                        </td>
                        <td className="p-3 font-bold text-rose-600 dark:text-rose-400">
                          {ch.amount} {settings.currencySymbol}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
