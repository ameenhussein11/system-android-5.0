import React from 'react';
import { CalendarPlus, MessageSquare } from 'lucide-react';
import { useHotel } from '../context/HotelContext';
import { CompanionsEditor } from './CompanionsEditor';
import type { Room } from '../types/hotel';

export const RESERVATION_DRAFT_KEY = 'qasr_reservation_draft_room';

/** Extras shown inside the room dialog: advance reservation for this room, companions, SMS to the guest. */
export const RoomExtras: React.FC<{ room: Room }> = ({ room }) => {
  const { bookings, addCompanion, removeCompanion, openSmsComposer, setActiveTab, setSelectedRoom } = useHotel();
  const booking = bookings.find((b) => b.id === room.currentBookingId && b.isActive);
  const owing = booking ? Math.max(0, booking.totalAmount - booking.paidAmount) : 0;

  const reserve = () => {
    try {
      localStorage.setItem(RESERVATION_DRAFT_KEY, String(room.id));
    } catch {
      /* ignore */
    }
    setSelectedRoom(null);
    setActiveTab('reservations');
  };

  return (
    <div className="space-y-3 mb-4">
      <div className="flex flex-wrap gap-2">
        {room.status !== 'maintenance' && (
          <button type="button" onClick={reserve} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-violet-600 hover:bg-violet-500 text-white text-xs font-bold cursor-pointer">
            <CalendarPlus className="w-4 h-4" /> حجز مسبق لهذه الغرفة
          </button>
        )}
        {booking && (
          <>
            {owing > 0 && (
              <button
                type="button"
                onClick={() => openSmsComposer({ guestId: booking.guestId, templateId: 'payment_reminder', vars: { المبلغ: String(owing), الغرفة: room.roomNumber } })}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold cursor-pointer"
              >
                <MessageSquare className="w-4 h-4" /> SMS تذكير بالسداد
              </button>
            )}
            <button
              type="button"
              onClick={() => openSmsComposer({ guestId: booking.guestId, templateId: 'thanks', vars: { الغرفة: room.roomNumber } })}
              className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-bold cursor-pointer"
            >
              <MessageSquare className="w-4 h-4" /> SMS شكر
            </button>
          </>
        )}
      </div>

      {booking && (
        <CompanionsEditor
          companions={booking.companions || []}
          capacity={room.capacity}
          onAdd={(c) => addCompanion(booking.id, c)}
          onRemove={(id) => removeCompanion(booking.id, id)}
        />
      )}
    </div>
  );
};
