import React from 'react';
import { ChevronRight, ChevronLeft } from 'lucide-react';

export const CATEGORY_AR: Record<string, string> = {
  salaries: 'رواتب الموظفين',
  utilities: 'كهرباء ومياه وإنترنت',
  maintenance: 'صيانة',
  supplies: 'مشتريات ونظافة',
  government: 'رسوم وتراخيص',
  other: 'نثريات أخرى',
};
export const METHOD_AR: Record<string, string> = { cash: 'نقداً', card: 'بطاقة', transfer: 'تحويل', unpaid: 'آجل' };

export const inputCls =
  'w-full bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-xl px-3 py-2.5 text-sm text-slate-800 dark:text-slate-100 focus:outline-none focus:ring-2 focus:ring-sky-500';

export const Card: React.FC<{ title?: string; children: React.ReactNode; className?: string }> = ({ title, children, className = '' }) => (
  <section className={`bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-sm p-4 space-y-3 ${className}`}>
    {title && <h3 className="font-bold text-sm text-slate-800 dark:text-slate-100">{title}</h3>}
    {children}
  </section>
);

export const Stat: React.FC<{ label: string; value: string | number; tone?: 'default' | 'good' | 'bad' | 'gold'; hint?: string }> = ({ label, value, tone = 'default', hint }) => {
  const color =
    tone === 'good' ? 'text-emerald-600 dark:text-emerald-400' : tone === 'bad' ? 'text-rose-600 dark:text-rose-400' : tone === 'gold' ? 'text-sky-600 dark:text-sky-400' : 'text-slate-800 dark:text-slate-100';
  return (
    <div className="rounded-xl bg-slate-50 dark:bg-slate-800/60 p-3 border border-slate-100 dark:border-slate-800">
      <div className="text-[11px] text-slate-500 dark:text-slate-400">{label}</div>
      <div className={`font-bold text-base sm:text-lg mt-0.5 ${color}`}>{value}</div>
      {hint && <div className="text-[10px] text-slate-400 mt-0.5">{hint}</div>}
    </div>
  );
};

/** ‹ prev | date picker | next › */
export const DateNav: React.FC<{ value: string; onChange: (d: string) => void; onPrev: () => void; onNext: () => void; max?: string }> = ({ value, onChange, onPrev, onNext, max }) => (
  <div className="flex items-center gap-2">
    <button onClick={onPrev} className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 cursor-pointer" aria-label="السابق">
      <ChevronRight className="w-5 h-5" />
    </button>
    <input type="date" value={value} max={max} onChange={(e) => e.target.value && onChange(e.target.value)} className={inputCls} />
    <button onClick={onNext} className="p-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 cursor-pointer" aria-label="التالي">
      <ChevronLeft className="w-5 h-5" />
    </button>
  </div>
);

export const Empty: React.FC<{ text: string }> = ({ text }) => <p className="text-center text-sm text-slate-400 py-6">{text}</p>;
