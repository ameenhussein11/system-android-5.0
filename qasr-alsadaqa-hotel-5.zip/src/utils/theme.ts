export type ThemeMode = 'system' | 'light' | 'dark';
export type PaletteId = 'gold' | 'emerald' | 'sapphire' | 'amethyst' | 'rose';

export const PALETTES: { id: PaletteId; name: string; accent: string; surface: string }[] = [
  { id: 'gold', name: 'الذهبي الملكي', accent: '#b8912b', surface: '#111e33' },
  { id: 'emerald', name: 'الزمرد', accent: '#1f9c92', surface: '#0f2629' },
  { id: 'sapphire', name: 'الياقوت', accent: '#3b7bf6', surface: '#111c3a' },
  { id: 'amethyst', name: 'الجوهرة البنفسجية', accent: '#8660ee', surface: '#181330' },
  { id: 'rose', name: 'الورد الملكي', accent: '#ec4670', surface: '#2a1019' },
];
const PALETTE_KEY = 'qasr_palette_v1';

export const getPalette = (): PaletteId => {
  try {
    const v = localStorage.getItem(PALETTE_KEY) as PaletteId | null;
    if (v && PALETTES.some((p) => p.id === v)) return v;
  } catch {
    /* ignore */
  }
  return 'gold';
};
const KEY = 'qasr_theme_v1';

export const getThemeMode = (): ThemeMode => {
  try {
    const v = localStorage.getItem(KEY);
    if (v === 'light' || v === 'dark' || v === 'system') return v;
  } catch {
    /* ignore */
  }
  return 'system';
};

const systemPrefersDark = () =>
  typeof window !== 'undefined' && !!window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;

export const applyTheme = (mode: ThemeMode = getThemeMode()) => {
  const dark = mode === 'dark' || (mode === 'system' && systemPrefersDark());
  const root = document.documentElement;
  root.classList.toggle('dark', dark);
  root.style.colorScheme = dark ? 'dark' : 'light';
  const palette = getPalette();
  if (palette === 'gold') delete root.dataset.palette;
  else root.dataset.palette = palette;
  const meta = document.querySelector('meta[name="theme-color"]');
  const surface = PALETTES.find((p) => p.id === palette)?.surface || '#111e33';
  if (meta) meta.setAttribute('content', surface);
};

export const setPalette = (id: PaletteId) => {
  try {
    localStorage.setItem(PALETTE_KEY, id);
  } catch {
    /* ignore */
  }
  applyTheme();
  window.dispatchEvent(new CustomEvent('qasr-theme-change', { detail: getThemeMode() }));
};

export const setThemeMode = (mode: ThemeMode) => {
  try {
    localStorage.setItem(KEY, mode);
  } catch {
    /* ignore */
  }
  applyTheme(mode);
  window.dispatchEvent(new CustomEvent('qasr-theme-change', { detail: mode }));
};

/** Call once at startup: applies the saved mode and follows the OS setting while in "system" mode. */
export const initTheme = () => {
  applyTheme();
  if (window.matchMedia) {
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const onChange = () => {
      if (getThemeMode() === 'system') applyTheme('system');
    };
    if (mq.addEventListener) mq.addEventListener('change', onChange);
    else if ((mq as MediaQueryList).addListener) (mq as MediaQueryList).addListener(onChange);
  }
};
