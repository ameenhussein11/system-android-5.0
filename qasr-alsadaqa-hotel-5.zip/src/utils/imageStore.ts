// Guest photos / ID images live in IndexedDB (localStorage's ~5MB limit is too small for images).
// Images are downscaled + JPEG-compressed before saving (~60-120KB each).
const DB_NAME = 'qasr_images_v1';
const STORE = 'images';
let dbPromise: Promise<IDBDatabase> | null = null;

const openDb = (): Promise<IDBDatabase> => {
  if (!dbPromise) {
    dbPromise = new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, 1);
      req.onupgradeneeded = () => req.result.createObjectStore(STORE);
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  return dbPromise;
};

async function run<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T> {
  const db = await openDb();
  return new Promise<T>((resolve, reject) => {
    const rq = fn(db.transaction(STORE, mode).objectStore(STORE));
    rq.onsuccess = () => resolve(rq.result);
    rq.onerror = () => reject(rq.error);
  });
}

export type GuestImageKind = 'photo' | 'idcard';
export const guestImageKey = (guestId: number, kind: GuestImageKind) => `guest-${guestId}-${kind}`;

export const saveImage = async (key: string, dataUrl: string): Promise<void> => {
  await run('readwrite', (s) => s.put(dataUrl, key));
};
export const getImage = async (key: string): Promise<string | null> => {
  try {
    return ((await run<string | undefined>('readonly', (s) => s.get(key))) as string | undefined) ?? null;
  } catch {
    return null;
  }
};
export const deleteImage = async (key: string): Promise<void> => {
  try {
    await run('readwrite', (s) => s.delete(key));
  } catch {
    /* ignore */
  }
};

/** Downscale + compress a picked/captured image file to a JPEG data URL. */
export function compressImage(file: File, maxSide = 900, quality = 0.72): Promise<string> {
  return new Promise((resolve, reject) => {
    const url = URL.createObjectURL(file);
    const img = new Image();
    img.onload = () => {
      const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
      const w = Math.max(1, Math.round(img.width * scale));
      const h = Math.max(1, Math.round(img.height * scale));
      const c = document.createElement('canvas');
      c.width = w;
      c.height = h;
      const cx = c.getContext('2d');
      if (!cx) {
        URL.revokeObjectURL(url);
        reject(new Error('canvas unsupported'));
        return;
      }
      cx.fillStyle = '#ffffff';
      cx.fillRect(0, 0, w, h);
      cx.drawImage(img, 0, 0, w, h);
      URL.revokeObjectURL(url);
      resolve(c.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('image load failed'));
    };
    img.src = url;
  });
}

export const loadImageElement = (dataUrl: string): Promise<HTMLImageElement> =>
  new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
