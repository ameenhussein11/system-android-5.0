import { Capacitor, registerPlugin } from '@capacitor/core';
import type { jsPDF } from 'jspdf';

export const isNativeApp = (): boolean => {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
};

/** Android 5.x: the standard file plugin needs Android 6+ and would crash the app, so it is never called there. */
const isOldAndroid = (): boolean => {
  const m = /Android\s+(\d+)/i.exec(typeof navigator !== 'undefined' ? navigator.userAgent || '' : '');
  return !!m && parseInt(m[1], 10) < 6;
};

/** Tiny native plugin (added only by the Android-5 build workflow): writes a base64 file into the app cache. */
interface FileSaverPlugin {
  saveToCache(options: { filename: string; data: string }): Promise<{ uri: string }>;
}
const FileSaver = registerPlugin<FileSaverPlugin>('FileSaver');

const blobToBase64 = (blob: Blob): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error);
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.readAsDataURL(blob);
  });

/**
 * Save/export a file.
 * - Browser: normal download.
 * - Android app (Capacitor): WebView ignores <a download>, so write the file to the
 *   app cache and open the system share sheet ("Save to Files", WhatsApp, Drive...).
 */
export async function saveBlob(filename: string, blob: Blob): Promise<void> {
  if (isNativeApp()) {
    const cancelled = (e: unknown) => String(e).toLowerCase().includes('cancel');
    try {
      const { Share } = await import('@capacitor/share');
      const data = await blobToBase64(blob);
      let uri: string | undefined;

      if (isOldAndroid()) {
        // Android 5.x: use the small FileSaver plugin instead of @capacitor/filesystem
        try {
          uri = (await FileSaver.saveToCache({ filename, data })).uri;
        } catch (e) {
          console.error('FileSaver unavailable', e);
        }
      } else {
        const { Filesystem, Directory } = await import('@capacitor/filesystem');
        uri = (await Filesystem.writeFile({ path: filename, data, directory: Directory.Cache })).uri;
      }

      if (uri) {
        await Share.share({ title: filename, url: uri, dialogTitle: 'حفظ أو مشاركة الملف' });
        return;
      }
      // no file support at all: share text-based exports as plain text
      if (blob.type.startsWith('text/') || blob.type.includes('json')) {
        await Share.share({ title: filename, text: await blob.text(), dialogTitle: 'مشاركة الملف كنص' });
        return;
      }
      alert('تعذّر حفظ الملف على هذا الجهاز. جرّب التصدير من نسخة الويب أو من جهاز أحدث.');
    } catch (err) {
      if (cancelled(err)) return; // share sheet dismissed by the user
      console.error('saveBlob failed', err);
      alert('تعذّر حفظ الملف.');
    }
    return;
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export const saveText = (filename: string, text: string, mime = 'text/plain;charset=utf-8') =>
  saveBlob(filename, new Blob([text], { type: mime }));

export const savePdf = (doc: jsPDF, filename: string) => saveBlob(filename, doc.output('blob'));
