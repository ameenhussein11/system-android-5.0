import { Capacitor, registerPlugin } from '@capacitor/core';
import type { jsPDF } from 'jspdf';

export const isNativeApp = (): boolean => {
  try {
    return Capacitor.isNativePlatform();
  } catch {
    return false;
  }
};

/** Android 5.x: the standard file plugin needs Android 6+ and would crash the app, so it is never called there. */
const isOldAndroid = (): boolean => {
  const m = /Android\s+(\d+)/i.exec(typeof navigator !== 'undefined' ? navigator.userAgent || '' : '');
  return !!m && parseInt(m[1], 10) < 6;
};

/**
 * Tiny native plugin (added only by the Android-5 build workflow). On Android 5.x the standard
 * filesystem / share / file-chooser code crashes the app, so these methods replace them.
 */
export interface FileSaverPlugin {
  saveToCache(options: { filename: string; data: string }): Promise<{ uri: string; path: string }>;
  shareFile(options: { path: string; mime: string; title: string }): Promise<void>;
  shareText(options: { text: string; title: string }): Promise<void>;
  pickFile(options: { mimes?: string }): Promise<{ name: string; mime: string; data: string }>;
  getLastCrash(): Promise<{ text: string }>;
}
export const FileSaver = registerPlugin<FileSaverPlugin>('FileSaver');
export { isOldAndroid };

const blobToBase64 = (blob: Blob): Promise<string> =>
  new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(reader.error);
    reader.onload = () => resolve(String(reader.result).split(',')[1] || '');
    reader.readAsDataURL(blob);
  });

/**
 * Save/export a file.
 * - Browser: normal download.
 * - Android app (Capacitor): WebView ignores <a download>, so write the file to the
 *   app cache and open the system share sheet ("Save to Files", WhatsApp, Drive...).
 */
export async function saveBlob(filename: string, blob: Blob): Promise<void> {
  if (isNativeApp()) {
    const cancelled = (e: unknown) => String(e).toLowerCase().includes('cancel');
    const textual = blob.type.startsWith('text/') || blob.type.includes('json');
    try {
      const data = await blobToBase64(blob);

      if (isOldAndroid()) {
        // Android 5.x: everything goes through the FileSaver plugin (no filesystem / share plugins)
        try {
          const saved = await FileSaver.saveToCache({ filename, data });
          await FileSaver.shareFile({ path: saved.path, mime: blob.type || 'application/octet-stream', title: filename });
          return;
        } catch (e) {
          if (cancelled(e)) return;
          console.error('FileSaver failed', e);
        }
        if (textual) {
          await FileSaver.shareText({ text: await blob.text(), title: filename });
          return;
        }
        alert('تعذّر حفظ الملف على هذا الجهاز. جرّب التصدير من نسخة الويب أو من جهاز أحدث.');
        return;
      }

      const [{ Filesystem, Directory }, { Share }] = await Promise.all([import('@capacitor/filesystem'), import('@capacitor/share')]);
      const written = await Filesystem.writeFile({ path: filename, data, directory: Directory.Cache });
      await Share.share({ title: filename, url: written.uri, dialogTitle: 'حفظ أو مشاركة الملف' });
    } catch (err) {
      if (cancelled(err)) return; // share sheet dismissed by the user
      console.error('saveBlob failed', err);
      if (textual) {
        try {
          const { Share } = await import('@capacitor/share');
          await Share.share({ title: filename, text: await blob.text(), dialogTitle: 'مشاركة الملف كنص' });
          return;
        } catch (err2) {
          if (cancelled(err2)) return;
        }
      }
      alert('تعذّر حفظ الملف.');
    }
    return;
  }
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export const saveText = (filename: string, text: string, mime = 'text/plain;charset=utf-8') =>
  saveBlob(filename, new Blob([text], { type: mime }));

export const savePdf = (doc: jsPDF, filename: string) => saveBlob(filename, doc.output('blob'));
