import { FileSaver, isNativeApp, isOldAndroid } from './saveFile';

const b64ToBlob = (b64: string, mime: string): Blob => {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new Blob([bytes], { type: mime || 'application/octet-stream' });
};

/**
 * Android 5.x: the WebView file chooser crashes the app. Intercept every <input type="file"> click,
 * open the native picker (FileSaver plugin) and hand the chosen file back to the input as if the
 * normal chooser had been used, so no screen needs to change.
 */
export function installNativeFilePicker() {
  if (!isNativeApp() || !isOldAndroid()) return;
  document.addEventListener(
    'click',
    async (e) => {
      const el = e.target as HTMLInputElement | null;
      if (!el || el.tagName !== 'INPUT' || el.type !== 'file') return;
      e.preventDefault();
      e.stopPropagation();
      try {
        const accept = (el.getAttribute('accept') || '').trim();
        const mimes = accept
          .split(',')
          .map((x) => x.trim())
          .filter((x) => x.includes('/') && !x.includes('*'))
          .join(',');
        const picked = await FileSaver.pickFile({ mimes: mimes || undefined });
        const file = new File([b64ToBlob(picked.data, picked.mime)], picked.name || 'file', { type: picked.mime || '' });
        const dt = new DataTransfer();
        dt.items.add(file);
        el.files = dt.files;
        el.dispatchEvent(new Event('change', { bubbles: true }));
      } catch (err) {
        if (!String(err).toLowerCase().includes('cancel')) console.error('pickFile failed', err);
      }
    },
    true
  );
}
