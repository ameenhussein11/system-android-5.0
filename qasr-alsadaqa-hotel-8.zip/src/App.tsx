import React, { useEffect, useRef, useState } from 'react';
import { HotelProvider, useHotel } from './context/HotelContext';
import { Header } from './components/Header';
import { RoomGrid } from './components/RoomGrid';
import { GuestList } from './components/GuestList';
import { HousekeepingView } from './components/HousekeepingView';
import { ReportsView } from './components/ReportsView';
import { LogsView } from './components/LogsView';
import { ReservationsView } from './components/ReservationsView';
import { FinanceView } from './components/FinanceView';
import { SystemAdminView } from './components/SystemAdminView';
import { NavigationDrawer } from './components/NavigationDrawer';
import { AccountInfoModal } from './components/AccountInfoModal';
import { HelpGuideModal } from './components/HelpGuideModal';
import { LanguageModal } from './components/LanguageModal';
import { LogoutModal } from './components/LogoutModal';
import { FloatingActionButton } from './components/FloatingActionButton';

// Modals
import { RoomDetailModal } from './components/RoomDetailModal';
import { BookingModal } from './components/BookingModal';
import { SqlConsoleModal } from './components/SqlConsoleModal';
import { SettingsModal } from './components/SettingsModal';
import { NotificationsCenter } from './components/NotificationsCenter';
import { AndroidSimulatorFrame } from './components/AndroidSimulatorFrame';
import { GuestStatementModal } from './components/GuestStatementModal';
import { LinkGuestToRoomModal } from './components/LinkGuestToRoomModal';
import { AddRoomModal } from './components/AddRoomModal';
import { RoomServiceView } from './components/RoomServiceView';
import { NewRoomServiceOrderModal } from './components/NewRoomServiceOrderModal';
import { RoomServiceMenuModal } from './components/RoomServiceMenuModal';
import { GoogleDriveLinkModal } from './components/GoogleDriveLinkModal';
import { DriveAutoSync } from './components/DriveAutoSync';
import { DailyArchiver } from './components/DailyArchiver';
import { ArchiveView } from './components/ArchiveView';
import { CustodyView } from './components/CustodyView';
import { MessagingView } from './components/MessagingView';
import { CrashReport } from './components/CrashReport';
import { AutoBackupSettingsModal } from './components/AutoBackupSettingsModal';

function HotelAppContent() {
  const { activeTab, settings, goBack } = useHotel();

  // Android hardware / gesture back button: step back inside the app, exit only from the home screen
  const goBackRef = useRef(goBack);
  goBackRef.current = goBack;
  useEffect(() => {
    let remove: (() => void) | undefined;
    let cancelled = false;
    const cap = (window as unknown as { Capacitor?: { isNativePlatform?: () => boolean } }).Capacitor;
    if (cap?.isNativePlatform?.()) {
      import('@capacitor/app')
        .then(({ App: CapApp }) =>
          CapApp.addListener('backButton', () => {
            if (!goBackRef.current()) CapApp.exitApp();
          })
        )
        .then((handle) => {
          if (cancelled) handle.remove();
          else remove = () => handle.remove();
        })
        .catch(() => {
          /* plugin unavailable: default Android behaviour */
        });
    }
    return () => {
      cancelled = true;
      remove?.();
    };
  }, []);
  const [storageError, setStorageError] = useState(false);

  // Surface localStorage failures (quota exceeded / blocked) instead of losing data silently
  useEffect(() => {
    const onErr = () => setStorageError(true);
    window.addEventListener('qasr-storage-error', onErr);
    return () => window.removeEventListener('qasr-storage-error', onErr);
  }, []);

  return (
    <div className="min-h-screen bg-slate-100 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col font-sans transition-colors relative" dir="rtl">
      {/* Header Bar */}
      <Header />

      {storageError && (
        <div className="bg-rose-600 text-white text-xs sm:text-sm px-4 py-2 flex items-center justify-between gap-3" role="alert">
          <span>⚠️ تعذّر حفظ البيانات في المتصفح (المساحة ممتلئة أو التخزين محجوب). صدّر نسخة احتياطية الآن لتجنّب فقدان التغييرات.</span>
          <button onClick={() => setStorageError(false)} className="underline font-bold cursor-pointer">إغلاق</button>
        </div>
      )}

      {/* Main Content Area */}
      <main className="max-w-7xl mx-auto px-3 sm:px-4 py-5 flex-1 w-full">
        {activeTab === 'rooms' && <RoomGrid />}
        {activeTab === 'reservations' && <ReservationsView />}
        {activeTab === 'room_service' && <RoomServiceView />}
        {activeTab === 'reports' && <ReportsView />}
        {activeTab === 'finance' && <FinanceView />}
        {activeTab === 'guests' && <GuestList />}
        {activeTab === 'housekeeping' && <HousekeepingView />}
        {activeTab === 'system_admin' && <SystemAdminView />}
        {activeTab === 'archive' && <ArchiveView />}
        {activeTab === 'custody' && <CustodyView />}
        {activeTab === 'messages' && <MessagingView />}
        {activeTab === 'logs' && <LogsView />}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900 border-t border-slate-800 text-slate-400 text-xs py-4 px-4 text-center select-none">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>{settings.hotelName} • نظام إدارة وحجز الفنادق المتكامل (PMS)</span>
          <span className="font-mono text-slate-500">SQLite Offline Database Engine • v2.0</span>
        </div>
      </footer>

      {/* Navigation Drawer matching Android screenshot */}
      <NavigationDrawer />

      {/* Floating Action Button */}
      <FloatingActionButton />

      {/* System Modals and Dialogs */}
      <RoomDetailModal />
      <BookingModal />
      <SqlConsoleModal />
      <SettingsModal />
      <NotificationsCenter />
      <GuestStatementModal />
      <LinkGuestToRoomModal />
      <AddRoomModal />
      <NewRoomServiceOrderModal />
      <RoomServiceMenuModal />
      <AccountInfoModal />
      <HelpGuideModal />
      <LanguageModal />
      <LogoutModal />
      <GoogleDriveLinkModal />
      <DriveAutoSync />
      <CrashReport />
      <DailyArchiver />
      <AutoBackupSettingsModal />
    </div>
  );
}

export default function App() {
  return (
    <HotelProvider>
      <AndroidSimulatorFrame>
        <HotelAppContent />
      </AndroidSimulatorFrame>
    </HotelProvider>
  );
}
