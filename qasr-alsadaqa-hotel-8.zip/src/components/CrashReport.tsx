import React, { useEffect, useState } from 'react';
import { FileSaver, isNativeApp } from '../utils/saveFile';

/** Shows the stack trace of the previous native crash (Android build), so it can be copied and reported. */
export const CrashReport: React.FC = () => {
  const [text, setText] = useState('');

  useEffect(() => {
    if (!isNativeApp()) return;
    FileSaver.getLastCrash()
      .then((r) => r?.text && setText(r.text))
      .catch(() => {
        /* plugin not present in this build */
      });
  }, []);

  if (!text) return null;
  return (
    <div className="fixed inset-0 z-[200] bg-black/80 flex items-center justify-center p-3" dir="rtl">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl p-4 space-y-3 max-h-[90vh] flex flex-col">
        <h3 className="font-bold text-rose-600">أُغلق التطبيق في المرة السابقة بسبب خطأ</h3>
        <p className="text-xs text-slate-500">انسخ النص التالي وأرسله للمطوّر لإصلاح المشكلة.</p>
        <textarea readOnly value={text} dir="ltr" className="flex-1 min-h-[200px] text-[10px] font-mono bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg p-2" onFocus={(e) => e.currentTarget.select()} />
        <div className="flex gap-2">
          <button onClick={() => navigator.clipboard?.writeText(text).then(() => alert('تم النسخ'))} className="flex-1 py-2 rounded-xl bg-sky-600 text-white text-sm font-bold cursor-pointer">نسخ</button>
          <button onClick={() => FileSaver.shareText({ text, title: 'تقرير الخطأ' }).catch(() => {})} className="flex-1 py-2 rounded-xl bg-emerald-600 text-white text-sm font-bold cursor-pointer">مشاركة</button>
          <button onClick={() => setText('')} className="px-4 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-sm font-semibold cursor-pointer">إغلاق</button>
        </div>
      </div>
    </div>
  );
};
